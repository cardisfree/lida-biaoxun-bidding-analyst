---
name: jrzb-crawler
description: 控制「招标数据爬虫」程序 xCD.WB.Skill.JRZB.exe，用于启动、查询状态、停止招标网站数据爬取。爬虫的数据源为**立达标讯平台**（www.arrbid.com，全国招投标采购信息大数据平台）。当用户要求启动/运行招标（招投标）数据爬虫、查询爬虫是否在处理中、或停止爬虫时使用。启动前必须先查询状态，若已在处理中则不得重复启动。
agent_created: true
---

# 招标数据爬虫控制

控制 C# 编写的招标数据爬虫 `xCD.WB.Skill.JRZB.exe`（基于 Playwright 采集招标公告）。

**数据源：立达标讯平台（www.arrbid.com）** —— 全国招投标采购信息大数据平台，覆盖工程 / 货物 / 服务全品类。
爬虫登录该平台（配置键 `LoginUrl`）后按关键词翻页采集公告，写入 `buzdata.db`。

## 程序位置

- 默认路径：`<work_root>/xCD.WB.Skill.JRZB.exe`（`work_root` 默认 `~/jrzb_spider`，Windows 专用）。
- **专家包不含爬虫运行包**（约 70MB，超出开放平台 20MB 上限）：首次安装时按
  `crawler/runtime-source.json` 的地址下载并校验 SHA256 后解包，见「安装向导 · 第 0 步」。
- **路径配置**（迁移到别的机器时只需改这一处）：
  - `python scripts/jrzb.py config --work-root "<项目根目录>"`（根目录内含爬虫程序与 `buzdata.db`）
  - 或 `python scripts/jrzb.py config --exe "<xCD.WB.Skill.JRZB.exe 完整路径>"`
  - 也可用环境变量 `ZB_WORK_ROOT` / `JRZB_EXE` 或命令行参数 `--exe` 临时覆盖；
  - 配置文件为 `zb-tender.json`，与 `ztb-analyzer` 技能共用；查找顺序：
    `ZB_CONFIG` 环境变量 → **`<工作区>/.workbuddy/zb-tender.json`（存在才用）** → `~/.workbuddy/zb-tender.json`。
  - **不确定当前生效路径时，先运行 `python scripts/jrzb.py config` 查看。**
- 📁 **工作区锚定（默认值）**：未显式配置时，`work_root` 优先取**工作区内的 `<工作区>/jrzb_spider`**
  （仅当该目录确实存在，避免打断旧布局），`state_root` 优先取**`<工作区>/.workbuddy`**。
  工作区通过环境变量 `WORKBUDDY_PROJECT_DIR` / `CODEBUDDY_PROJECT_DIR` / `CLAUDE_PROJECT_DIR` 识别。
  也就是说：**新机器上装完就落在工作区里，日志与状态也不会跑出工作区**。
  `config` 输出的 `resolved` 里有 `workspace` 与 `package_root` 两个字段可直接查看。

## 安装向导（首次使用必做）

### 第 0 步：拿到爬虫程序

爬虫是 Windows 程序，需要运行环境（自包含 .NET 8 + Playwright 驱动，**不需要另装 .NET**）。

- 📁 **优先用「工作区锚定」安装**（专家包自带 `install.py`）：整套东西（技能 + 爬虫 + 数据库 + 状态）
  都落进**工作区**，并长期在那里运行。先 `jrzb.py config` 读 `resolved.package_root` 与
  `resolved.workspace`，然后 `python "<package_root>/install.py" --workspace "<workspace>"`。
  它会顺带把共享配置的 `work_root` / `state_root` 对齐到工作区内，**不用再手工 config**。
- 也可单独解包（默认落点已改为**工作区里的 `<工作区>/jrzb_spider`**，取不到工作区才退回
  `~/jrzb_spider`）：

  ```bash
  python scripts/jrzb.py setup --install-crawler                  # 获取并解包到当前 work_root
  python scripts/jrzb.py setup --install-crawler "D:\jrzb_spider" # 解包到指定目录
  python scripts/jrzb.py setup --install-crawler --force          # 覆盖已存在的运行文件
  python scripts/jrzb.py setup --install-crawler --no-download     # 只认本机已有文件，不联网
  ```

  运行包（约 70MB）不随专家包分发，脚本会自动按 `crawler/runtime-source.json` 里的地址
  下载并校验 SHA256；临时换地址用 `--runtime-url "<地址>"`，离线时把 zip 放到
  `<专家包>/crawler/` 或用环境变量 `JRZB_RUNTIME_BUNDLE` 指过去。

  解包规则：**已存在的文件默认保留**（不会覆盖你已配好的 `app.config` 或已有 `buzdata.db`）；
  `buzdata.db` 与 `*.dll.config` 属受保护文件，**永远不会被写入**（前者是采集业务数据，
  后者含本机账号密码）；解包后若目录内没有 `app.config`，会自动生成一份空骨架便于填写。
  解包到非当前 `work_root` 的目录后，记得先 `jrzb.py config --work-root "<该目录>"`。

- **若提示「未找到爬虫运行包 / 下载失败」**：按提示依次排查——
  ① 检查能否访问 `crawler/runtime-source.json` 里 `url` 指向的地址（可先手工下载一次验证）；
  ② 地址失效则让维护者更新 `url`，或临时用 `--runtime-url "<地址>"`；
  ③ 完全离线时，把运行包放到 `<专家包>/crawler/jrzb-runtime.zip`，或用环境变量
  `JRZB_RUNTIME_BUNDLE` 指向已下载的 zip；
  ④ 都没有则需自行准备 `xCD.WB.Skill.JRZB.exe` 及其同目录运行文件，再用 `config --work-root` 指向它。

### 第 1 步：确认个性化配置

**爬虫自己还有一份个性化配置**，写在 exe 同目录的 `xCD.WB.Skill.JRZB.dll.config`
（.NET 的 `xCD.WB.Skill.JRZB.exe.config`）。这些键**绑定具体使用者的环境**——Chrome 路径与
用户数据目录、工作目录、翻页数、登录等待上限、企业版接口等，每台机器都不同。

> **安装 / 首次使用本技能时，必须先运行安装向导，并把结果逐项向用户确认后再写回。**
> 绝不能让用户沿用打包作者的示例值——否则会找不到 Chrome、把数据写错目录。

```bash
python scripts/jrzb.py setup            # ① 列出需确认的配置项 + 本机体检结果
python scripts/jrzb.py setup --json     #    同上，JSON（便于程序处理）
```

向导输出要点：

| 字段 | 含义 |
| --- | --- |
| `needs_setup` / `reasons` | 是否仍需配置及原因（如「爬虫工作目录 仍为示例值，需替换」） |
| `fields[]` | 字段清单。`level=core` 为**必问项**，`level=advanced` 为按需项；每项含 `key` / `label` / `hint` / `default` / `current` / `placeholder`（是否仍为示例值）/ `required` |
| `checks[]` | 本机体检：爬虫程序 / Chrome / 用户数据目录 / 工作目录是否存在，CDP 端口与连接地址是否一致 |
| `login_mode` | 登录方式判定（见下节）：`manual`（推荐）/ `configured`（旧配置里还留着账号密码）/ `skip` |

**必问项（core）**：`ChromePath`、`UserDataDir`、`DebuggingPort`、`Playwright_CDP_Endpoint`、
`工作目录`、`分页页面爬取数`、`LoginTimeoutSeconds`。
**按需项（advanced）**：`LoginUrl` / `SkipLogin` / `LaunchWaitSeconds` 以及 `企业版` 系列
（仅启用企业版时才需要）。

> ⚠️ **向导不再询问「登录账号 / 密码」**：爬虫程序并不读取这两个键（已在 exe 内验证），
> 登录改为在浏览器里手动完成。详见「登录方式」一节。

**提问方式**：把 `needs_setup`、`placeholder`、`missing` 为真的 `core` 项整理成一张表格问用户；
能用选项的就用选项问（如「是否启用企业版」「Chrome 是否装在默认路径」），值类的直接问。

拿到答复后写回（**只改 value、保留注释与缩进，改动前自动备份**）：

```bash
python scripts/jrzb.py setup \
  --set "ChromePath=D:\Google\Chrome\Application\chrome.exe" \
  --set "UserDataDir=D:\ChromeProfile" \
  --set "工作目录=D:\你的项目根目录"
# 需要时：--set "DebuggingPort=9225" --set "Playwright_CDP_Endpoint=http://localhost:9225"
#          --set "LoginTimeoutSeconds=600"
# 启用企业版：--set "企业版=true" --set "企业版_corpid=..." --set "企业版_aiapi=..." --set "企业版_aiapi_xkey=..."
# 批量写入：--set-json '{"ChromePath":"...","UserDataDir":"..."}'
```

写回后再跑一次 `python scripts/jrzb.py setup` 复核：`needs_setup=false` 且体检项全绿。

> 若 exe 目录下没有 app.config，向导会明确提示；此时 `--set` 会生成一份含全部键的骨架文件。
> 键名不存在时会自动插入到 `</appSettings>` 之前；`python scripts/jrzb.py config` 也会顺带
> 提示 `crawler_app_config.needs_setup` 与待配置键。

## 登录方式（手动登录，推荐）

**爬虫不读取「登录账号 / 密码」**：它打开登录门户后**等待用户在打开的 Chrome 窗口里手动完成登录**，
再用页面文案判断登录态（出现「退出登录」= 已登录），超过 `LoginTimeoutSeconds` 判失败并停止抓取。

**手动登录模式**（推荐）：账号密码留空，登录凭证只存在于独立的 Chrome 用户数据目录
`UserDataDir` 里，**密码不落盘到配置文件**，观感与实际安全性都更好。

```bash
# 一键切到手动登录模式（清空账号密码 + 保持登录检查 + 给足等待时间）
python scripts/jrzb.py setup --manual-login [--timeout 600]
```

> 若 `setup` 的 `login_mode.mode = configured`，说明旧配置里还留着账号密码（程序并不使用），
> 提示用户执行上面这条命令清空，避免密码明文留在文件里。

### 等待登录：用 wait-login，不要循环轮询

等待人工登录可能持续几分钟。**反复调用 `status` 会白烧 token**，正确姿势是**一次** `wait-login`：

```bash
python scripts/jrzb.py login-state                  # 单次探测当前登录状态（不等待）
python scripts/jrzb.py wait-login [--timeout 600]   # 一次性等到登录完成或超时（服务端等待）
python scripts/jrzb.py wait-login --json            # 结构化输出
```

- 等到「已登录」→ 退出码 `0`；
- 程序自己报「等待登录超时 / 未检测到登录状态」→ 退出码 `1`，`alert: true`；
- **自身等待超时 → 默认自动停掉爬虫**（`stopped: true`），避免空转与白占浏览器；
  需要保留运行时加 `--no-stop-on-timeout`。
- `--timeout` 省略时自动取 `LoginTimeoutSeconds + 30`。
- 只会认「本次调用之前 5 秒内更新过」的日志，**不会把上一轮的旧日志误判成本轮已登录**。

## 原生子命令

程序本身支持三个子命令：

| 子命令 | 作用 |
| --- | --- |
| `start` | 启动爬虫（**前台阻塞**：一直运行到本轮爬取结束才返回） |
| `status` | 查询运行状态（输出 JSON，立即返回） |
| `stop` | 停止爬虫 |

> 判断状态的方式只有一种：运行 `xCD.WB.Skill.JRZB.exe status` 并读取其输出。
> 不读取、也不依赖任何本地文件或进程列表。

`status` 输出示例：

```json
{"Status":"Running","StartTime":null,"EndTime":null,"StartedAt":"2026-10-10T21:10:53.1626356+08:00","FinishedAt":null,"Error":null}
```

`Status` 字段取值：

| 值 | 含义 |
| --- | --- |
| `Idle` | 空闲（未启动） |
| `Running` | 处理中 |
| `Completed` | 已完成 |
| `Stopped` | 已停止 |
| `Failed` | 失败 |

## 核心规则（必须遵守）

**启动前必须先运行 `status` 查询状态；若 `Status` 为 `Running`（处理中），不得重复启动。**

> **陈旧状态（stale Running）**：进程被强制结束（如后台任务被取消/强杀）时，状态文件会残留 `Running`，
> 若不处理会导致之后每次 `start` 都被判定为"运行中"而静默跳过，爬虫再也起不来。
> 脚本已内置**进程存活校验**：`start` 会同时检查系统里是否真存在该 exe 进程，
> 确认不存在才继续启动（打印 `[纠正]`）；**无法判定时保守跳过**，避免双开。
> `status --json` 输出新增 `proc_alive` 字段（true/false/null）可用于判别。

统一使用本技能提供的脚本 `scripts/jrzb.py` 调用，脚本已内置上述防重复逻辑，不要在脚本之外直接拼接 `start` 命令。

## 使用方式

```bash
# 安装向导：查看需向用户确认的个性化配置（首次使用必做）
python scripts/jrzb.py setup
python scripts/jrzb.py setup --json          # JSON 输出

# 查看当前生效的路径配置
python scripts/jrzb.py config

# 查询状态（默认输出中文摘要）
python scripts/jrzb.py status

# 查询状态（输出原始 JSON，便于程序处理）
python scripts/jrzb.py status --json

# 启动爬虫：脚本会先运行 status；若处理中则跳过，不会重复启动。
# 注意：本命令为前台阻塞，会一直运行到本轮爬取结束，
#       必须以后台任务方式执行（见下方「启动方式」）。
python scripts/jrzb.py start

# 停止爬虫
python scripts/jrzb.py stop

# 检查近期下载异常，判断是否需要告警（需要时输出企业微信文案）
python scripts/jrzb.py check-download
python scripts/jrzb.py check-download --json           # JSON 输出，便于程序处理
python scripts/jrzb.py check-download --dry-run        # 只看不记录告警状态
python scripts/jrzb.py check-download --send           # 告警时直接发到推送群（推荐）

# 检查是否异常退出，需要时输出企业微信文案（含异常栈）
python scripts/jrzb.py check-exit
python scripts/jrzb.py check-exit --json               # JSON 输出
python scripts/jrzb.py check-exit --dry-run            # 只看不记录去重状态
python scripts/jrzb.py check-exit --send               # 告警时直接发到推送群（推荐）

# 直接发一段 markdown 到推送群（任意通知/简报）
python scripts/jrzb.py notify --text "……"
python scripts/jrzb.py notify --text-file msg.md       # 长文本用文件
python scripts/jrzb.py notify --text "x" --dry-run     # 只测推送通道是否可达，不发送
```

> **推送群是可选配置**（`ztb.py config --push-group`，与 `ztb-analyzer` 共用）：
> 未配置 / 群不可达 / 企业微信未授权时，`--send` 只返回 `send.error`，**不影响采集与检查本身**。


脚本退出码：

| 退出码 | 含义 |
| --- | --- |
| `0` | 成功 |
| `3` | 已在处理中，已跳过启动（未重复启动） |
| `4` | `stop` 时「当前没有正在运行的程序」（由爬虫程序返回，属正常） |
| `5` | **未提供《投标策略》，拒绝启动采集**（见「策略闸门」，与 `ztb-analyzer` 同码） |
| `1` | 执行出错；`notify` 未送达时也返回 `1`（`check-* --send` 的发送失败**不影响**退出码） |
| `1` | 执行出错 |

## 策略闸门（未提供策略 → 拒绝启动采集）

**未提供《投标策略》时不允许开工**：`start` 会**直接拒绝启动**（退出码 `4`），不启动爬虫、
不写运行日志，只把拒绝原因记进 `last_run.json`（`status: "Refused"`）。

**「已提供」的判定**：与 `ztb-analyzer` 共用同一份配置
（`<state_root>/ztb-analyzer/strategy.json`，可用 `ZTB_STRATEGY` 或共享配置键 `strategy_file` 覆盖），
且四维模型对应的**四个核心字段（`业务范围` / `关系单位` / `硬性否决规则` / `价格分规则`）至少有一个有内容**。

| 命令 | 是否受闸门影响 |
| --- | --- |
| `start` | **受**——未提供策略时拒绝（应急可加 `--allow-without-strategy`） |
| `status` / `login-state` / `check-download` / `check-exit` / `stop` | 不受影响（只读监控与收尾） |
| `config` / `setup` | 不受影响（配置本身必须可用） |

`setup` 报告里含 `strategy_gate` 块（`blocked` / `core_filled` / `core_missing` / `how_to_fix`），
安装向导阶段就能看出「策略还没配、现在启动会被拒绝」。

> ⚠️ 别为了"先攒数据"绕过闸门：策略没配时分析侧只能用包内占位模板初筛，筛出来的是**无效结论**。
> 确需应急先采集，用 `start --allow-without-strategy`，并在策略配好后**重跑一遍初筛**
> （`ztb.py reset --id N` 把项目重新置为待处理）。

## 启动方式（重点）

`start` 是**前台阻塞**命令，会一直运行到本轮爬取结束。因此必须把它作为**后台任务**运行，
让调用方立即拿到控制权、爬虫在后台持续采集：

- **在智能体中**：使用后台任务方式执行（`run_in_background`）。**不要**在普通前台命令里等待它返回，
  否则会阻塞对话，且进程可能在命令结束时被回收。
- **在终端中**：放到独立终端 / `start` 新窗口 / `nohup` 等后台方式运行。

> 实测结论：在本 Agent 沙箱内，「分离进程 / 独立 cmd 窗体 / breakaway」启动的爬虫会在命令返回时
> 被环境连带回收，**只有「后台任务」方式能持续运行**。因此脚本不再尝试自建独立窗体，
> 而是保持前台阻塞、由调用方负责后台化。

**运行日志**：`start` 会把爬虫子进程的 `stdout/stderr` 落盘到
`<run_dir>/logs/run-<时间戳>.log`，并在 `<run_dir>/last_run.json` 记录本轮运行摘要
（开始/结束时间、退出码、错误、日志路径）。`run_dir` 默认 `<state_root>/jrzb-crawler`
（`state_root` 默认 `~/.workbuddy`），实际路径见 `jrzb.py config` 输出的 `resolved.run_dir`。
这是捕获崩溃异常栈的**唯一可靠手段**——程序自身不写日志，且会把真实异常吞成一句
「程序意外退出。」，只有控制台 stderr 上仍会打印 .NET 的完整异常栈。

## 下载异常监控（企业微信提醒）

爬虫长时间运行时，若附件下载频繁失败（如「站点拒绝下载：今日附件下载次数已达上限」「下载错误」等），
需要通过企业微信提醒用户。统一由脚本 `check-download` 判定并生成文案。

```bash
python scripts/jrzb.py check-download                 # 人类可读
python scripts/jrzb.py check-download --json          # JSON
python scripts/jrzb.py check-download --window 60 --threshold 5 --cooldown 30
python scripts/jrzb.py check-download --json --dry-run
```

**判定口径**：

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `--window` | 60 | 观察窗口（分钟）：统计 `lastupdatetime` 落在该窗口内、且 `download_error` 非空的记录 |
| `--threshold` | 5 | 窗口内异常条数 ≥ 该值即触发告警 |
| `--cooldown` | 30 | 告警冷却（分钟）：冷却期内不重复告警 |

去重：脚本把最近一次告警写入状态文件（默认 `<run_dir>/alert_state.json`，即 `jrzb.py config` 里的 `resolved.run_dir`）。
**满足以下任一条件即静默**，避免刷屏：① 距上次告警不足冷却时长；② 自上次告警后没有新增异常记录（最大 ID 未变）。

**输出**：JSON 含 `alert`（是否告警）、`count`、`categories`（按类型计数）、`message`（企业微信文案）。
`alert=true` 时**优先直接加 `--send`**（一条命令完成判定+发送，返回 `send.ok / send.error`），或由智能体把 `message` 原文用企业微信发到**配置的推送群**。推送群是**可选**配置（`ztb-analyzer config --push-group`，两技能共用）；未配置/不可达时只标记 `send.error`，**不影响采集与本检查**。`alert=false` 时不要打扰。

**错误分类**：`附件下载配额已用尽（当日次数达上限）` / `下载错误` / `其他下载异常`。

> 数据源：`buzdata.db` 的 `ztb_rpa_prjs.download_error`（默认 `<work_root>/buzdata.db`，
> 可用 `--db`、环境变量 `JRZB_DB` 或配置文件键 `db` 覆盖）。
> 状态文件路径可用环境变量 `JRZB_STATE` 覆盖。

## 异常退出监控（企业微信提醒）

爬虫长时间运行中若**崩溃 / 意外退出**，需要通过企业微信及时提醒。统一由脚本 `check-exit` 判定。

```bash
python scripts/jrzb.py check-exit            # 人类可读
python scripts/jrzb.py check-exit --json     # JSON
python scripts/jrzb.py check-exit --dry-run  # 只看不写去重状态
```

**判定口径**

- 以 `status` 输出为准：`Status == Failed` 或 `Error` 非空 → 视为异常退出。
- 异常栈来源：优先从最近一次 `start` 落盘的运行日志中提取（匹配 `Unhandled exception`、
  `System.*Exception`、`at …` 等行，取末 14 行）。
- **两级去重，避免刷屏**（状态写入 `…\jrzb-crawler\exit_state.json`）：
  1. **同一轮**（`FinishedAt` 相同）只提醒一次；
  2. **同一崩溃点**（错误文案 + 运行日志末尾特征行相同）在 `EXIT_SIG_COOLDOWN_MIN`
     分钟内只提醒一次——确定性崩溃重启后会反复崩在同一处，无需每次告警。
     冷却默认 60 分钟，可用环境变量 `JRZB_EXIT_SIG_COOLDOWN` 覆盖（设为 `0` 关闭签名去重、每次都报）。
- 被抑制时 JSON 返回 `alert=false`，且带 `suppressed=true` 与 `suppress_reason` 说明原因。

**输出**：JSON 含 `alert`、`abnormal`、`status`、`error`、`exception`（异常栈）、`message`（企业微信文案）、
`signature`、`suppressed`、`suppress_reason`。
`alert=true` 时**优先直接加 `--send`**（同上）；或由智能体把 `message` 原文发到配置的推送群。`alert=false` 时静默。

> 已知程序缺陷：程序的 `UnhandledException` 处理器只写入通用文案「程序意外退出。」，
> **丢弃真实异常**；且不产生任何日志文件。因此异常栈只能靠运行日志捕获。
> 若 `exception` 为空，说明那一轮不是用本脚本启动的（未留日志），提示用户下次用本脚本 `start`。

## 标准工作流

0. **首次使用**：
   - 先确认爬虫程序就位：若目录内没有 `xCD.WB.Skill.JRZB.exe`，运行
     `python scripts/jrzb.py setup --install-crawler ["目标目录"]` 获取运行环境
     （本机没有则按 `crawler/runtime-source.json` 的地址自动下载 + 校验）；
   - 再运行 `python scripts/jrzb.py setup`，把 `core` 项中仍需确认的配置
     （Chrome 路径、用户数据目录、工作目录、翻页数、登录等待上限等）逐项问用户，拿到答复后
     `setup --set` 写回并复核。**向导不问账号密码**（爬虫不读该键）；
     若 `login_mode.mode = configured`，建议顺手执行 `setup --manual-login` 清空。
1. **启动**：以**后台任务方式**运行 `python scripts/jrzb.py start`。脚本内部会先跑**策略闸门**，再运行 `status` 探测：
   - 若返回退出码 `4`，说明**未提供《投标策略》**，采集被拒绝 —— 如实告知用户并把 `how_to_fix`
     里的配置命令给出来，**不要**擅自加 `--allow-without-strategy`；
   - 若返回退出码 `3`，说明已处理中，向用户说明「爬虫正在处理中，未重复启动」，不要重试；
   - 启动后执行一次 `python scripts/jrzb.py status` 复核，确认状态为 `Running` 后再告知用户。
1.5 **等登录**（手动登录模式，必做）：告知用户「请在打开的 Chrome 窗口里输入账号密码」，
   然后**只调用一次** `python scripts/jrzb.py wait-login --timeout <秒>`（服务端等待，别循环轮询 `status`）：
   - 退出码 `0` → 登录完成，继续下一步；
   - 退出码 `1` 且 `alert: true` → 按 `hint` 告知用户（超时未登录 / 进程结束 / 未启动），
     脚本在自身超时时**已自动停掉爬虫**，不要反复重试登录。
2. **查询**：运行 `python scripts/jrzb.py status`，把当前状态（含开始时间/错误信息）如实转述给用户。
   登录态可用 `python scripts/jrzb.py login-state` 单次确认。
3. **监控下载异常**：运行 `python scripts/jrzb.py check-download`：
   - `alert=true` → 用企业微信把返回的 `message` 原文发给用户（标题已含「【爬虫告警】」）；
   - `alert=false` → 静默，不要打扰。
   - 未启用企业微信连接器时跳过发送，并在汇报里注明。
4. **监控异常退出**：运行 `python scripts/jrzb.py check-exit`：
   - `alert=true` → 用企业微信把 `message` 原文发给用户（已含异常栈）；
   - `alert=false` → 静默。
5. **停止**：运行 `python scripts/jrzb.py stop`，随后可再查一次状态确认。

## 定时执行（每小时兜底）

已配置自动化「招标爬虫-每小时启动」（`FREQ=HOURLY;INTERVAL=1`），每小时触发一次：

> ⚠️ 调度器**最小触发粒度是「小时」**：`FREQ=MINUTELY` 不被支持（配置后从不触发）；
> `HOURLY` 下 `BYMINUTE` 被忽略；`DAILY` 下 `BYHOUR` 只接受单个整数。**做不出分钟级定时**。
> 因此本技能由「每小时自动化兜底 + 分析侧长轮询 worker 实时处理」共同驱动。

- 每轮先 `status` 探测：若为 `Running`，本轮**直接跳过**、不重复启动；
- 否则以后台任务方式 `start`，并复核状态；
- **无人值守时不要在自动化里长时间等登录**：`start` 之后最多做**一次** `wait-login`，
  且 `--timeout` 建议不超过 120 秒；本轮等不到就放掉（脚本会自动停止爬虫），下一小时再试。
  登录态平时保存在 `UserDataDir`，只有过期时才需要人工介入；
- **每轮再运行一次 `check-download`**：`alert=true` 时通过企业微信把 `message` 发给用户，否则静默；
- **每轮再运行一次 `check-exit`**：`alert=true`（异常退出）时通过企业微信把 `message` 发给用户，否则静默；
- **无论启动还是跳过，都保持每小时一次的固定频率**，不因「已在运行中」而暂停或延长间隔。

> 之所以能「运行中也照常触发」，是因为跳过逻辑就在脚本里：`start` 检测到 `Running` 会返回退出码 3 并退出，
> 定时器无需关心运行状态，照常按点触发即可。

## 注意事项

- **首次使用先跑安装向导**：
  1. `python scripts/jrzb.py setup --install-crawler` 获取爬虫运行环境
     （本机没有则按 `crawler/runtime-source.json` 下载 + SHA256 校验；离线时手工放包）；
     解包到非 `work_root` 的目录后要 `config --work-root` 指过去。
  2. `python scripts/jrzb.py setup` —— 爬虫个性化配置
     （Chrome 路径、用户数据目录、工作目录、翻页数、登录等待上限等）绑定使用者环境，
     必须先问用户再写回，不要沿用示例值。
  3. `python scripts/jrzb.py setup --manual-login` —— 切到手动登录模式
     （清空账号密码，密码不再明文落盘）。
- **登录靠手动，别写账号密码**：爬虫不读取「登录账号 / 密码」；它在浏览器打开登录门户后
  等待用户手动登录，超时（`LoginTimeoutSeconds`）判失败并停止抓取。**等待登录只调用一次
  `wait-login`，不要循环轮询 `status` 白烧 token。**
- 调用脚本前先确认 exe 存在；若路径不同，通过 `--exe` 传入或在环境变量 `JRZB_EXE` 中设置。
- `start` 为前台阻塞命令，调用方必须以**后台任务**方式执行；脚本不再自行创建独立窗体。
- `stop` 会先跑完当前正在处理的公告再退出，可能需几十秒。
- `stop` 在「当前没有正在运行的程序」时会返回退出码 `4`，属正常情况。
- 程序会把运行结果写成终态（`Stopped` / `Completed` 等），并在异常结束时带上 `Error` 信息；不会残留 `Running`。
- 爬虫运行期间会通过 Playwright 附着到本地 `9224` 端口的浏览器（CDP），这是正常现象。
- **登录态会过期**：凭证保存在 `UserDataDir` 里，过期时程序会重新要求手动登录；
  若长期无人值守，建议把 `LoginTimeoutSeconds` 设成与巡检间隔匹配的值，超时就本轮放弃、下轮再试。
