#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""招标数据爬虫 (xCD.WB.Skill.JRZB.exe) 控制脚本。

统一封装 start / status / stop 三个子命令，并内置「启动前先查状态、
若已在处理中则不重复启动」的保护逻辑。

状态判定完全以运行 `xCD.WB.Skill.JRZB.exe status` 的输出为准，
不读取、也不依赖任何本地文件。

用法:
    python jrzb.py status [--json]
    python jrzb.py start [--force]
    python jrzb.py stop
    python jrzb.py check-download [--window 60] [--threshold 5] [--json]
    python jrzb.py check-exit [--json]
    python jrzb.py login-state [--json]                  查看登录状态（单次探测）
    python jrzb.py wait-login [--timeout 600] [--json]    等待用户在 Chrome 里完成登录（超时自动停爬虫）
    python jrzb.py config [--work-root ...] [--exe ...]   查看/设置路径配置
    python jrzb.py setup                                  安装向导：查看需向用户确认的个性化配置
    python jrzb.py setup --install-crawler ["D:\\jrzb_spider"]  获取并解包爬虫运行环境（缺则按 URL 下载）
    python jrzb.py setup --manual-login [--timeout 600]    切到手动登录模式（清空账号密码）

说明:
    start 为「前台阻塞」：它会一直运行到本轮爬取结束才返回。因此应由调用方以
    「后台任务」方式执行（例如智能体用 run_in_background / nohup / 独立终端），
    启动后调用方立即拿到控制权，爬虫在后台持续采集。

    不要在智能体的普通前台命令里直接等待 start 返回，否则会阻塞对话。

通用参数:
    --exe PATH   指定 xCD.WB.Skill.JRZB.exe 路径

路径配置（优先级：CLI > 环境变量 > 配置文件 > 内置默认）:
    配置文件 ~/.workbuddy/zb-tender.json，常用键：
        work_root   项目根目录（含爬虫程序与 buzdata.db），默认 ~/jrzb_spider
        state_root  状态根目录（运行日志/告警状态），默认 ~/.workbuddy
        crawler_exe / crawler_run_dir / db   可按需单独覆盖
    环境变量：ZB_CONFIG / ZB_WORK_ROOT / ZB_STATE_ROOT / JRZB_EXE / JRZB_DB /
              JRZB_STATE / JRZB_RUN_DIR
    查看或设置：python jrzb.py config [--work-root ...] [--exe ...]

爬虫个性化配置（安装向导）:
    爬虫自身的个性化参数写在 exe 同目录的 xCD.WB.Skill.JRZB.dll.config
    （Chrome 路径与用户数据目录、工作目录、翻页数、登录等待上限、企业版接口等），
    每台机器都不同，安装/首次使用时必须向用户确认：
        python jrzb.py setup --install-crawler            获取并解包爬虫运行环境（本机没有则按 URL 下载）
        python jrzb.py setup --manual-login               切到「手动登录模式」（清空账号密码，推荐）
        python jrzb.py setup                              列出需确认的项 + 本机体检结果
        python jrzb.py setup --set "键=值" ...             写回 app.config（自动备份原文件）
    详见 setup 输出的 fields（level=core 为必问项）。

登录（手动登录模式，推荐）:
    爬虫**不读取**「登录账号 / 密码」两个配置键：它打开登录门户后，会
    **等待用户在打开的 Chrome 窗口里手动完成登录**，用页面文案判断登录态，
    超过 LoginTimeoutSeconds 判失败并停止抓取。因此账号密码留空即可，
    密码不再明文落到配置文件里（登录态保存在 UserDataDir）。
    等待登录可能持续几分钟：
        python jrzb.py login-state                 单次探测当前登录状态
        python jrzb.py wait-login --timeout 600     一次性等待登录完成（服务端等待、不刷屏；
                                                    超时未登录会自动停止爬虫）

退出码:
    0  成功
    3  爬虫已在处理中(Running)，已跳过启动（未重复启动）
    1  执行出错（含 wait-login 超时/登录失败）
"""

import argparse
import datetime
import json
import os
import re
import sqlite3
import subprocess
import sys
import time

# ---------------------------------------------------------------- 路径配置
#
# 路径解析优先级：CLI 参数 > 环境变量 > 配置文件 > 内置默认
#
# 配置文件：~/.workbuddy/zb-tender.json（与 ztb-analyzer 技能共用，可用
# 环境变量 ZB_CONFIG 指向别处）。迁移到别的机器时通常只需两个键：
#     work_root   项目根目录：内含爬虫程序与 buzdata.db，默认 ~/jrzb_spider
#     state_root  状态根目录：运行日志/告警状态，默认 ~/.workbuddy
# 需要时可单独覆盖：
#     crawler_exe      直接指定 xCD.WB.Skill.JRZB.exe
#     crawler_run_dir  直接指定本技能运行目录（默认 <state_root>/jrzb-crawler）
#     db               直接指定 buzdata.db
#
# 查看/写入配置：python jrzb.py config [--work-root ...] [--exe ...]

HOME_DIR = os.path.expanduser("~")
DEFAULT_WORK_ROOT = os.path.join(HOME_DIR, "jrzb_spider")
DEFAULT_STATE_ROOT = os.path.join(HOME_DIR, ".workbuddy")
EXE_NAME = "xCD.WB.Skill.JRZB.exe"

# 「工作区」锚定：WorkBuddy 会把当前工作区目录放进下面这些环境变量。
# 目标是把整套东西（爬虫程序 + buzdata.db + 状态/日志）都落在**工作区**里，
# 而不是用户主目录 —— 装到哪台电脑，就落在那个工作区，长期在那里运行、随工作区一起备份。
WORKSPACE_ENVS = ("WORKBUDDY_PROJECT_DIR", "CODEBUDDY_PROJECT_DIR", "CLAUDE_PROJECT_DIR")
WORKSPACE_CRAWLER_SUBDIR = "jrzb_spider"
WORKSPACE_STATE_SUBDIR = ".workbuddy"

EXE_ENV = "JRZB_EXE"
DB_ENV = "JRZB_DB"
STATE_ENV = "JRZB_STATE"
RUN_DIR_ENV = "JRZB_RUN_DIR"
CONFIG_ENV = "ZB_CONFIG"
_CONFIG_CACHE = None


def config_path():
    """共享配置路径。

    优先级：`ZB_CONFIG` 环境变量 > **工作区内的** `.workbuddy/zb-tender.json`（存在才用）
    > 用户主目录 `~/.workbuddy/zb-tender.json`。

    工作区自包含安装（专家包 `install.py`）会把配置写在工作区内，这里优先认它，
    使整套环境随工作区走；老环境（配置在主目录）行为不变。
    """
    p = os.environ.get(CONFIG_ENV)
    if p:
        return os.path.abspath(os.path.expanduser(p))
    ws = workspace_dir()
    if ws:
        cand = os.path.join(ws, WORKSPACE_STATE_SUBDIR, "zb-tender.json")
        if os.path.isfile(cand):
            return os.path.abspath(cand)
    return os.path.join(HOME_DIR, ".workbuddy", "zb-tender.json")


def load_config():
    """读取共享配置；文件不存在或损坏时返回空 dict（不报错）。"""
    global _CONFIG_CACHE
    if _CONFIG_CACHE is None:
        try:
            with open(config_path(), "r", encoding="utf-8") as f:
                _CONFIG_CACHE = json.load(f) or {}
        except Exception:
            _CONFIG_CACHE = {}
    return _CONFIG_CACHE


def _cfg(key):
    v = load_config().get(key)
    return v.strip() if isinstance(v, str) and v.strip() else None


def _norm(p):
    return os.path.abspath(os.path.expanduser(p))


def _pick(env_key, cfg_key, default):
    return os.environ.get(env_key) or _cfg(cfg_key) or default


def workspace_dir():
    """当前工作区目录；识别不到返回 None。"""
    for k in WORKSPACE_ENVS:
        v = (os.environ.get(k) or "").strip()
        if v and os.path.isdir(v):
            return _norm(v)
    return None


def package_root():
    """专家包根目录（<pkg>/skills/jrzb-crawler/scripts/jrzb.py → <pkg>）。

    用于发现包内的工作区自包含安装器 <pkg>/install.py；不在包内（如开发目录）返回 None。
    """
    here = os.path.dirname(os.path.abspath(__file__))          # .../skills/jrzb-crawler/scripts
    pkg = os.path.dirname(os.path.dirname(os.path.dirname(here)))
    if os.path.isfile(os.path.join(pkg, "install.py")):
        return pkg
    return None


def _default_work_root():
    """默认项目根目录：工作区里已有 jrzb_spider 就优先用它，否则退回 ~/jrzb_spider。

    只在**确实存在**时才优先工作区，避免打断「按旧方式装在主目录」的既有环境。
    """
    ws = workspace_dir()
    if ws:
        cand = os.path.join(ws, WORKSPACE_CRAWLER_SUBDIR)
        if os.path.isdir(cand):
            return cand
    return DEFAULT_WORK_ROOT


def _default_state_root():
    """默认状态根目录：优先工作区内的 .workbuddy，让日志/状态不跑出工作区。"""
    ws = workspace_dir()
    if ws:
        return os.path.join(ws, WORKSPACE_STATE_SUBDIR)
    return DEFAULT_STATE_ROOT


def default_install_dir():
    """`setup --install-crawler` 不指定目录时的落点：**工作区里的 jrzb_spider**。"""
    ws = workspace_dir()
    if ws:
        return os.path.join(ws, WORKSPACE_CRAWLER_SUBDIR)
    return work_root()


def align_config_path():
    """配置**对齐**（新建/更新）时的写入目标。

    与 `config_path()` 的区别：这里是要**建立**工作区配置，所以不要求它已存在。
    - 设置了 `ZB_CONFIG` → 就用它（隔离测试）；
    - 能识别工作区 → `<工作区>/.workbuddy/zb-tender.json`（配置也落进工作区，整套自包含）；
    - 否则 → `config_path()`。
    """
    if os.environ.get(CONFIG_ENV):
        return config_path()
    ws = workspace_dir()
    if ws:
        return os.path.abspath(os.path.join(ws, WORKSPACE_STATE_SUBDIR, "zb-tender.json"))
    return config_path()


def work_root():
    return _norm(_pick("ZB_WORK_ROOT", "work_root", _default_work_root()))


def state_root():
    return _norm(_pick("ZB_STATE_ROOT", "state_root", _default_state_root()))
LAST_RUN_FILE = "last_run.json"      # 最近一次 start 的运行摘要
EXIT_STATE_FILE = "exit_state.json"  # 异常退出告警的去重状态
LOG_SUBDIR = "logs"                  # 运行日志目录（爬虫 stdout/stderr 落盘）

# 异常退出的通用错误文案（程序自身的 UnhandledException 处理器写入）
ABNORMAL_ERRORS = ("程序意外退出", "意外退出", "异常退出")

# 异常退出监控：同一「崩溃点」的告警冷却（分钟）。
# 若程序在某处确定性崩溃，重启后会反复崩在同一处；冷却期内只提醒一次，避免刷屏。
# 可用环境变量 JRZB_EXIT_SIG_COOLDOWN 覆盖（设为 0 表示每次都告警）。
EXIT_SIG_COOLDOWN_MIN = 60
EXIT_SIG_COOLDOWN_ENV = "JRZB_EXIT_SIG_COOLDOWN"

# 下载异常监控默认参数
DL_WINDOW_MIN = 60        # 观察窗口（分钟）：统计该时间窗内更新的记录
DL_THRESHOLD = 5          # 窗口内异常条数达到该值即告警
DL_COOLDOWN_MIN = 30      # 告警冷却（分钟）：冷却期内不重复告警


# 状态枚举 -> 中文说明
STATUS_ZH = {
    "Idle": "空闲（未启动）",
    "Running": "处理中",
    "Completed": "已完成",
    "Stopped": "已停止",
    "Failed": "失败",
}

RUNNING = "Running"
EXIT_OK = 0
EXIT_SKIPPED = 3
EXIT_ERROR = 1
EXIT_STRATEGY_REQUIRED = 5   # 未提供《投标策略》，拒绝启动采集（与 ztb-analyzer 同码）
# 注意：`stop` 会把爬虫程序的返回码透传，其中 4 = 「当前没有正在运行的程序」，与本码无关。


def resolve_exe(cli_path=None):
    """确定要调用的 exe 绝对路径。"""
    path = (cli_path or os.environ.get(EXE_ENV) or _cfg("crawler_exe")
            or os.path.join(work_root(), EXE_NAME))
    return _norm(path)


def _decode(raw):
    """控制台输出可能为 UTF-8 或 GBK（中文 Windows），依次尝试解码。"""
    if not raw:
        return ""
    for enc in ("utf-8", "gbk"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("gbk", "ignore")


def _run(exe, cmd, timeout=None):
    """前台执行一条子命令，返回 (stdout, stderr, returncode)。"""
    proc = subprocess.run(
        [exe, cmd],
        cwd=os.path.dirname(exe) or None,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        stdin=subprocess.DEVNULL,
        timeout=timeout,
    )
    return _decode(proc.stdout), _decode(proc.stderr), proc.returncode


def process_alive_by_name(exe_name):
    """按可执行文件名检测进程是否存活（Windows tasklist）。

    返回 True=确实有该进程；False=确认没有该进程；None=无法判定
    （tasklist 调用失败时返回 None，调用方应保守视为"存活"以免重复启动）。
    """
    if not exe_name:
        return None
    try:
        proc = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq %s" % exe_name, "/NH", "/FO", "CSV"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            timeout=15,
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    text = _decode(proc.stdout)
    if not text.strip():
        return None
    return exe_name.lower() in text.lower()


def parse_status(raw):
    """从命令输出里解析出状态 JSON，失败返回 None。"""
    if not raw:
        return None
    text = raw.strip()
    i, j = text.find("{"), text.rfind("}")
    if i != -1 and j != -1 and j > i:
        try:
            return json.loads(text[i : j + 1])
        except ValueError:
            return None
    return None


def fetch_status(exe, timeout=30):
    """查询一次状态，返回 (data, raw_out, raw_err)。"""
    out, err, _ = _run(exe, "status", timeout=timeout)
    return parse_status(out), out, err


def format_status(data):
    """把状态字典格式化为易读文本。"""
    st = data.get("Status")
    lines = ["当前状态: %s（%s）" % (st, STATUS_ZH.get(st, "未知"))]
    if data.get("StartedAt"):
        lines.append("开始时间: %s" % data["StartedAt"])
    if data.get("FinishedAt"):
        lines.append("结束时间: %s" % data["FinishedAt"])
    if data.get("Error"):
        lines.append("错误信息: %s" % data["Error"])
    return "\n".join(lines)


def cmd_status(exe, as_json=False):
    try:
        data, out, err = fetch_status(exe)
    except subprocess.TimeoutExpired:
        print("[错误] 查询状态超时。", file=sys.stderr)
        return EXIT_ERROR

    if data is None:
        print("[错误] 无法解析状态输出：", file=sys.stderr)
        print((out or err).strip(), file=sys.stderr)
        return EXIT_ERROR

    # 附带进程存活信息：状态文件的 Running 可能是被强杀后残留的陈旧值
    data = dict(data)
    alive = process_alive_by_name(os.path.basename(exe))
    data["proc_alive"] = alive

    if as_json:
        print(json.dumps(data, ensure_ascii=False))
    else:
        print(format_status(data))
        if data.get("Status") == RUNNING and alive is False:
            print("[提示] 状态文件为 Running，但系统中已无该程序进程（陈旧状态）。"
                  "下次 start 会自动纠正并重新启动。")
    return EXIT_OK


def run_dir():
    p = (os.environ.get(RUN_DIR_ENV) or _cfg("crawler_run_dir")
         or os.path.join(state_root(), "jrzb-crawler"))
    p = _norm(p)
    os.makedirs(p, exist_ok=True)
    return p


def log_dir():
    p = os.path.join(run_dir(), LOG_SUBDIR)
    os.makedirs(p, exist_ok=True)
    return p


def last_run_path():
    return os.path.join(run_dir(), LAST_RUN_FILE)


def exit_state_path():
    return os.path.join(run_dir(), EXIT_STATE_FILE)


def _dump_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
    except OSError:
        pass


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh) or {}
    except Exception:
        return {}


def tail_text(path, max_bytes=200000):
    """读取文件尾部（限制大小），返回解码后的文本。"""
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            if size > max_bytes:
                fh.seek(size - max_bytes)
            raw = fh.read()
        return _decode(raw)
    except OSError:
        return ""


# 从运行日志中提取异常/调用栈片段
_EXC_LINE = re.compile(
    r"(Unhandled exception|System\.\w+Exception|\w+Exception:|"
    r"^\s*at\s|--->|StackTrace|IndexOutOfRange|NullReference|"
    r"TimeoutException|Playwright|TargetClosed)",
    re.MULTILINE,
)


def extract_exception_from_log(text):
    """从控制台日志里抽取异常行（.NET 未处理异常会打印到 stderr）。"""
    if not text:
        return ""
    lines = text.splitlines()
    picked = []
    for i, ln in enumerate(lines):
        s = ln.strip()
        if not s:
            continue
        if _EXC_LINE.search(s):
            picked.append(ln.rstrip())
    if not picked:
        return ""
    return "\n".join(picked[-14:])


# ---------------------------------------------------------------- 策略闸门
#
# 未提供《投标策略》时**拒绝启动采集**。理由：采集是整条流水线的入口，
# 策略没配好时，分析侧只能用包内占位模板初筛，结论对客户无效 —— 与其先采一堆
# 再筛错，不如先把策略配好。策略配置/查看、以及只读监控命令不受影响。
#
# ⚠️ STRATEGY_CORE_KEYS 必须与 ztb-analyzer/scripts/ztb.py 中的同名常量保持一致。

STRATEGY_CORE_KEYS = ("业务范围", "关系单位", "硬性否决规则", "价格分规则")
STRATEGY_ENV = "ZTB_STRATEGY"
STRATEGY_STATE_SUBDIR = "ztb-analyzer"
STRATEGY_FILE_NAME = "strategy.json"


def strategy_config_file():
    """与 ztb-analyzer 共用同一份策略配置路径。"""
    p = (os.environ.get(STRATEGY_ENV) or _cfg("strategy_file")
         or os.path.join(state_root(), STRATEGY_STATE_SUBDIR, STRATEGY_FILE_NAME))
    return _norm(p)


def _strategy_has_value(v):
    if v is None:
        return False
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, (list, tuple, set)):
        return len(v) > 0
    if isinstance(v, dict):
        return any(_strategy_has_value(x) for x in v.values())
    return True


# ------------------------------------------------------------------ 企业微信发送
# 与 ztb-analyzer 保持一致（两边各自维护一份，改动需同步）：
# 推送目标以「群名称」配置（wecom_push_group）。平台要求每次发送前重新解析会话，
# 缓存的 chat_id 不可复用，所以固定三步：sessions list → 按 chat_name 精确匹配 → send。
WECOM_GROUP_ENV = "ZB_WECOM_GROUP"     # 临时覆盖推送群（便于测试），优先级高于配置


def wecom_cli():
    """定位 wecom-cli 可执行文件；找不到返回 None。"""
    import shutil
    for name in ("wecom-cli", "wecom-cli.cmd", "wecom-cli.exe"):
        p = shutil.which(name)
        if p:
            return p
    for cand in (r"~\.workbuddy\binaries\node\cli-connector-packages\wecom-cli.cmd",
                 "~/.workbuddy/binaries/node/cli-connector-packages/wecom-cli"):
        c = os.path.expanduser(cand)
        if os.path.isfile(c):
            return c
    return None


def push_group():
    """当前生效的推送群名称：环境变量 > 共享配置。"""
    return ((os.environ.get(WECOM_GROUP_ENV) or "").strip()
            or (load_config().get("wecom_push_group") or "").strip())


def wecom_send(text, group=None, dry_run=False):
    """把 markdown 文本发到推送群。返回 dict（不抛异常）。

    dry_run=True 时只解析目标是否可达，**不实际发送**。
    `error` 取值：cli_missing / group_not_configured / list_failed /
    group_not_in_sessions / send_failed
    """
    grp = (group or "").strip() or push_group()
    res = {"ok": False, "sent": False, "group": grp, "error": "", "detail": ""}
    cli = wecom_cli()
    if not cli:
        res["error"] = "cli_missing"
        res["detail"] = "找不到 wecom-cli（请确认企业微信连接器已安装并授权）"
        return res
    if not grp:
        res["error"] = "group_not_configured"
        res["detail"] = ('未配置推送群，请先 python scripts/ztb.py config --push-group "群名称"')
        return res

    def run(args):
        try:
            p = subprocess.run([cli] + args, capture_output=True, timeout=120)
        except Exception as exc:
            return None, "%s: %s" % (type(exc).__name__, exc)
        o = (p.stdout or b"").decode("utf-8", "replace").strip()
        e = (p.stderr or b"").decode("utf-8", "replace").strip()
        return o, e

    raw, err = run(["message", "aibot", "sessions", "list"])
    if raw is None:
        res["error"], res["detail"] = "list_failed", err
        return res
    try:
        sess = json.loads(raw)
    except Exception as exc:
        res["error"], res["detail"] = "list_failed", "会话列表解析失败: %s（原文 %s）" % (exc, raw[:160])
        return res
    if not isinstance(sess, dict) or sess.get("errcode"):
        res["error"] = "list_failed"
        res["detail"] = ("拉取会话列表失败：%s"
                         % (sess.get("errmsg") if isinstance(sess, dict) else raw[:160]))
        return res

    chat_id = ""
    for x in sess.get("sessions") or []:
        if (x.get("chat_name") or "").strip() == grp:
            chat_id = x.get("chat_id") or ""
            break
    if not chat_id:
        names = "、".join((x.get("chat_name") or "").strip()
                          for x in (sess.get("sessions") or []))
        res["error"] = "group_not_in_sessions"
        res["detail"] = ("目标群「%s」不在机器人最近会话中（当前可发送：%s）。"
                         "请先把机器人拉进该群，并在群里发一条消息（或 @ 机器人）。"
                         % (grp, names or "无"))
        return res

    payload = {"chat_id": chat_id, "msg_type": "markdown", "markdown": {"content": text}}
    if dry_run:
        res["ok"] = True
        res["dry_run"] = True
        res["detail"] = "目标群可达（dry-run，未实际发送）"
        return res
    raw, err = run(["message", "aibot", "send", "--json",
                    json.dumps(payload, ensure_ascii=False)])
    if raw is None:
        res["error"], res["detail"] = "send_failed", err
        return res
    try:
        r = json.loads(raw)
    except Exception:
        res["error"], res["detail"] = "send_failed", raw[:300]
        return res
    if r.get("success"):
        res["ok"] = res["sent"] = True
        return res
    res["error"] = "send_failed"
    res["detail"] = str(r.get("errmsg") or r.get("error") or raw)[:300]
    return res


def cmd_notify(argv):
    """把一段 markdown 直接发到推送群（爬虫告警 / 简报 / 临时通知）。

    非必填、非阻塞：未配置推送群或群不可达时只返回 not_sent，不影响采集流程。
    """
    text = (getattr(argv, "text", None) or "").strip()
    tf = getattr(argv, "text_file", None)
    if not text and tf:
        try:
            with open(tf, "r", encoding="utf-8") as f:
                text = f.read().strip()
        except OSError as exc:
            print("[错误] 读取 --text-file 失败: %s" % exc, file=sys.stderr)
            return EXIT_ERROR
    if not text:
        print("[错误] --text 与 --text-file 至少给一个", file=sys.stderr)
        return EXIT_ERROR
    r = wecom_send(text, group=getattr(argv, "group", None),
                   dry_run=getattr(argv, "dry_run", False))
    if getattr(argv, "json", False):
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        if r["ok"]:
            print("已发送到推送群：%s" % r["group"])
        else:
            print("未发送（%s）：%s" % (r["error"], r["detail"]))
    return EXIT_OK if r["ok"] else EXIT_ERROR


def strategy_gate():
    """判断是否允许开始采集（未提供策略则阻止）。"""
    p = strategy_config_file()
    exists = os.path.isfile(p)
    cfg = None
    if exists:
        try:
            with open(p, "r", encoding="utf-8") as fh:
                cfg = json.load(fh)
        except Exception:
            cfg = None
    filled = [k for k in STRATEGY_CORE_KEYS if isinstance(cfg, dict) and _strategy_has_value(cfg.get(k))]
    missing = [k for k in STRATEGY_CORE_KEYS if k not in filled]
    blocked = not (exists and filled)
    return {
        "require_strategy": True,
        "blocked": blocked,
        "config_file": p,
        "config_exists": exists,
        "core_filled": filled,
        "core_missing": missing,
        "reason": ("未提供《投标策略》：策略配置不存在或核心字段为空。"
                   "未配置时分析侧只能用包内占位模板初筛，结论对客户无效，故阻止采集。"
                   ) if blocked else "",
        "how_to_fix": [
            "python scripts/ztb.py strategy                    # 查看必问项与当前值",
            "python scripts/ztb.py strategy --template         # 取空白模板照着填",
            "python scripts/ztb.py strategy --set-file 我的策略.json   # 整体导入（推荐）",
            "python scripts/ztb.py strategy --render           # 渲染出《投标策略》",
        ],
    }


# ---------------------------------------------------------------- 登录（手动登录模式）
#
# 爬虫程序**不读取**「登录账号 / 密码」两个配置键（已在 exe 内验证：无该键引用）。
# 它的登录流程是：打开 LoginUrl → 点击登录按钮 → **等待用户在浏览器窗口里手动完成登录**
# → 用页面文案判断登录态（出现「退出登录」= 已登录）→ 超过 LoginTimeoutSeconds 则判失败并停止抓取。
#
# 因此推荐「手动登录模式」：账号密码留空，登录凭证只存在于独立的 Chrome 用户数据目录
# （UserDataDir）里，**密码不落盘到配置文件**，观感与实际安全性都更好。
#
# 「等待用户登录」可能持续几分钟，若由智能体反复轮询会白烧 token —— 用 wait-login
# 一条命令等完（服务端 sleep，不产生额外消耗）；超时未登录会自动停掉爬虫。

LOGIN_MARKS = {
    "waiting": ("等待登录中", "程序将等待登录完成", "请在浏览器窗口中完成登录",
                "请在浏览器窗口中手动完成登录", "打开登录门户", "未自动定位到登录按钮"),
    "success": ("检测到已处于登录状态", "继续执行后续抓取",
                "进入订阅板块", "获取到订阅板块数量", "新增项目成功"),
    "timeout": ("等待登录超时", "未检测到登录状态"),
    "skip": ("跳过登录步骤",),
}

LOGIN_STATE_ZH = {
    "logged_in": "已登录（可正常抓取）",
    "waiting_login": "等待你在浏览器中完成登录",
    "login_timeout": "登录超时 / 未检测到登录状态",
    "login_skipped": "配置为跳过登录检查",
    "stale_log": "只有上一轮运行的日志（本轮尚未产生新日志）",
    "not_started": "尚未启动（无运行日志）",
    "exited": "爬虫进程已结束",
    "unknown": "暂无登录相关日志",
}


def login_mode():
    """判断当前登录模式：manual（推荐）/ configured（旧版写了账号密码）/ skip。"""
    cp = app_config_path()
    text = _read_app_config(cp)
    skip = (app_config_get(text, "SkipLogin") or "").strip().lower() in ("true", "1", "yes")
    acc = (app_config_get(text, "登录账号") or "").strip()
    pwd = (app_config_get(text, "密码") or "").strip()
    timeout = app_config_get(text, "LoginTimeoutSeconds") or "180"
    if skip:
        mode = "skip"
        hint = "当前是「跳过登录检查」：不会等待登录，直接尝试抓取；一般不推荐。"
    elif acc or pwd:
        mode = "configured"
        hint = ("配置里仍写着账号/密码，但**爬虫程序并不读取这两个键**，它依然会打开浏览器等你手动登录。"
                "建议执行 `jrzb.py setup --manual-login` 清空，避免密码明文留在配置文件里。")
    else:
        mode = "manual"
        hint = ("手动登录模式：启动后请在打开的 Chrome 窗口里输入账号密码；"
                "登录态保存在 UserDataDir，密码不写入配置文件。")
    return {
        "mode": mode, "hint": hint, "config_file": cp,
        "login_timeout_seconds": timeout,
        "account_configured": bool(acc), "password_configured": bool(pwd),
        "skip_login": skip,
    }


def latest_log_file():
    """最近一次 start 的运行日志路径；找不到返回 None。"""
    p = (_read_json(last_run_path()) or {}).get("log")
    if p and os.path.isfile(p):
        return p
    d = log_dir()
    try:
        cands = sorted((os.path.join(d, f) for f in os.listdir(d)
                        if f.startswith("run-") and f.endswith(".log")),
                       key=os.path.getmtime, reverse=True)
    except OSError:
        return None
    return cands[0] if cands else None


def login_state(fresh_after=None):
    """单次探测当前登录状态（读运行日志 + 查进程存活），不做任何等待。

    fresh_after：只认「该时刻之后更新过的日志」。用于 wait-login —— 否则会读到
    上一轮运行留下的旧日志，把旧的「已登录」误判成本轮结果。
    """
    log = latest_log_file()
    mtime, age = None, None
    if log:
        try:
            mtime = os.path.getmtime(log)
            age = int(max(0, time.time() - mtime))
        except OSError:
            mtime = None

    if log and fresh_after is not None and (mtime is None or mtime < fresh_after):
        return {
            "state": "stale_log", "state_zh": LOGIN_STATE_ZH["stale_log"],
            "evidence": "", "process_alive": process_alive_by_name(EXE_NAME),
            "log_file": log, "log_age_seconds": age, "mode": login_mode()["mode"],
            "stale": True,
        }

    text = tail_text(log, 400000) if log else ""
    mark_state, evidence, pos = None, "", -1
    if text:
        for name, marks in LOGIN_MARKS.items():
            for m in marks:
                i = text.rfind(m)
                if i > pos:
                    pos, mark_state, evidence = i, name, m
    alive = process_alive_by_name(EXE_NAME)

    if mark_state == "success":
        state = "logged_in"
    elif mark_state == "timeout":
        state = "login_timeout"
    elif mark_state == "waiting":
        state = "waiting_login"
    elif mark_state == "skip":
        state = "login_skipped"
    elif log:
        state = "unknown" if alive is not False else "exited"
    else:
        state = "not_started"
    if state == "unknown" and alive is False:
        state = "exited"

    detail = ""
    if text and evidence:
        for ln in reversed(text.splitlines()):
            if evidence in ln:
                detail = ln.strip()[:200]
                break
    return {
        "state": state, "state_zh": LOGIN_STATE_ZH.get(state, state),
        "evidence": detail or evidence, "process_alive": alive,
        "log_file": log, "log_age_seconds": age, "mode": login_mode()["mode"],
        "stale": False,
    }


def cmd_login_state(argv):
    """查询当前登录状态（单次探测，不等待）。"""
    st = login_state()
    if getattr(argv, "json", False):
        print(json.dumps(st, ensure_ascii=False, indent=2))
    else:
        print("登录状态: %s" % st["state_zh"])
        if st["evidence"]:
            print("  依据: %s" % st["evidence"])
        print("  进程存活: %s" % {True: "是", False: "否", None: "未知"}[st["process_alive"]])
        if st["log_file"]:
            print("  运行日志: %s（%s 秒前）" % (st["log_file"], st.get("log_age_seconds")))
        if st["state"] == "logged_in" and st["process_alive"] is False:
            print("  说明: 该结论来自**上一轮**运行日志，当前爬虫并未在运行。")
    return EXIT_OK


def cmd_wait_login(argv):
    """一次性等待登录完成（服务端等待，避免智能体反复轮询白烧 token）。

    - 等到「已登录」→ 退出码 0；
    - 程序自己报「登录超时/未检测到登录状态」或进程结束 → 退出码 1；
    - 自身等待超时 → 默认**自动停掉爬虫**，返回 alert。
    """
    timeout = getattr(argv, "timeout", None)
    if not timeout:
        try:
            timeout = int(float(login_mode()["login_timeout_seconds"])) + 30
        except (TypeError, ValueError):
            timeout = 210
    interval = max(3, int(getattr(argv, "interval", 10) or 10))
    started = time.time()
    deadline = started + timeout

    # 只认本次等待开始之后更新过的日志，避免读上一轮旧日志误判
    st = login_state(fresh_after=started - 5)
    # 已是终态的直接返回；waiting_login / unknown / stale_log 才需要继续等
    while st["state"] not in ("logged_in", "login_skipped",
                              "login_timeout", "exited", "not_started"):
        if time.time() >= deadline:
            break
        time.sleep(min(interval, max(1, deadline - time.time())))
        st = login_state(fresh_after=started - 5)

    waited = int(time.time() - started)
    res = {
        "ok": st["state"] in ("logged_in", "login_skipped"),
        "state": st["state"], "state_zh": st["state_zh"],
        "evidence": st["evidence"], "process_alive": st["process_alive"],
        "waited_seconds": waited, "timeout": timeout,
        "log_file": st["log_file"], "stopped": False, "alert": False,
        "hint": login_mode()["hint"],
    }

    if res["ok"]:
        res["hint"] = "登录已完成，可继续采集/监控。"
    elif res["state"] == "stale_log":
        res["alert"] = True
        res["hint"] = ("只看到上一轮运行的日志，本轮似乎没有真正启动爬虫："
                       "请确认已用后台任务方式执行 start（或直接重跑 start）。")
    elif res["state"] == "login_timeout":
        res["alert"] = True
        res["hint"] = ("程序已判定登录失败（等待超时或未检测到登录状态）。"
                       "请确认账号可正常登录，或调大 LoginTimeoutSeconds 后重试。")
    elif res["state"] == "exited":
        res["alert"] = True
        res["hint"] = "爬虫进程已结束但未检测到登录成功，请查看运行日志。"
    elif res["state"] == "not_started":
        res["alert"] = True
        res["hint"] = "未发现运行日志：请先用后台任务方式执行 start。"
    else:
        # 自身等待超时：默认收工，避免爬虫继续空转 / 白占浏览器
        if not getattr(argv, "no_stop_on_timeout", False):
            try:
                _run(resolve_exe(), "stop", timeout=120)
                res["stopped"] = True
            except Exception:
                res["stopped"] = False
        res["alert"] = True
        res["hint"] = ("等待 %d 秒仍未完成登录，已%s。可调大 login 等待上限，"
                       "或确认 Chrome 窗口是否已打开。" %
                       (timeout, "停止爬虫" if res["stopped"] else "保持运行（未停止）"))

    if getattr(argv, "json", False):
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        print("[登录] %s（等待 %d 秒，上限 %d 秒）" % (res["state_zh"], waited, timeout))
        if res["evidence"]:
            print("  依据: %s" % res["evidence"])
        if res["stopped"]:
            print("  已自动停止爬虫。")
        if res["alert"]:
            print("  ⚠ %s" % res["hint"])
    return EXIT_OK if res["ok"] else EXIT_ERROR


def cmd_start(exe, force=False, allow_without_strategy=False):
    # 策略闸门：未提供《投标策略》时拒绝启动采集（采集是整条流水线的入口，
    # 策略没配就没有可用的初筛口径；详见 SKILL.md「策略闸门」）。
    gate = strategy_gate()
    if gate["blocked"] and not allow_without_strategy:
        print("[拒绝] %s" % gate["reason"])
        print("       目标策略文件: %s%s" % (
            gate["config_file"], "" if gate["config_exists"] else "（不存在）"))
        print("       核心字段状态: 已填 %s / 缺 %s"
              % (gate["core_filled"] or "无", gate["core_missing"] or "无"))
        print("       配置方式:")
        for s in gate["how_to_fix"]:
            print("         %s" % s)
        print("       确需在未配置策略时先采集数据（应急）：start --allow-without-strategy")
        _dump_json(last_run_path(), {
            "started_at": datetime.datetime.now().astimezone().isoformat(),
            "status": "Refused", "exit_code": EXIT_STRATEGY_REQUIRED,
            "error": gate["reason"], "gate": gate,
        })
        return EXIT_STRATEGY_REQUIRED

    # 关键保护：启动前先运行 status，处理中则绝不重复启动
    try:
        data, out, err = fetch_status(exe)
    except subprocess.TimeoutExpired:
        print("[错误] 启动前查询状态超时，已中止以避免重复启动。", file=sys.stderr)
        return EXIT_ERROR

    if data is None:
        print("[错误] 启动前无法获取状态，已中止以避免重复启动。", file=sys.stderr)
        print((out or err).strip(), file=sys.stderr)
        return EXIT_ERROR

    st = data.get("Status")
    if st == RUNNING and not force:
        # 状态文件可能因进程被强杀而滞留在 Running（陈旧状态）。
        # 启动前用进程名复核：确认进程不存在才继续启动，否则照旧跳过。
        exe_name = os.path.basename(exe)
        alive = process_alive_by_name(exe_name)
        if alive is False:
            print("[纠正] 状态为 Running，但系统中已无 %s 进程 —— 判定为陈旧状态，继续启动。" % exe_name)
        else:
            print("[跳过] 爬虫正在处理中(Running)，不重复启动。")
            print(format_status(data))
            return EXIT_SKIPPED
    if st == RUNNING:
        print("[强制] 状态为 Running，但已指定 --force，继续启动。")
    else:
        print("[状态] 启动前状态为 %s（%s），开始启动爬虫..." % (st, STATUS_ZH.get(st, "未知")))

    # 前台阻塞运行，直到本轮爬取结束；调用方应以后台任务方式执行本命令。
    # 把子进程的 stdout/stderr 落盘到运行日志，确保崩溃时的 .NET 异常栈不丢失。
    started_at = datetime.datetime.now().astimezone()
    log_path = os.path.join(log_dir(), "run-%s.log" % started_at.strftime("%Y%m%d-%H%M%S"))
    print("[启动] 爬虫开始运行，采集期间本命令将持续阻塞（请在后台执行）。")
    print("[日志] 运行输出写入: %s" % log_path)
    _lm = login_mode()
    if _lm["mode"] == "manual":
        print("[登录] 手动登录模式：请在打开的 Chrome 窗口里输入账号密码"
              "（密码不写入配置文件，登录态保存在 UserDataDir）。")
        print("[提示] 用 `python scripts/jrzb.py wait-login --timeout %s` 一次性等待登录完成；"
              "超时未登录会自动停止爬虫。" % _lm["login_timeout_seconds"])
    elif _lm["mode"] == "configured":
        print("[提示] 配置里仍有账号/密码，但爬虫并不读取它们；"
              "建议 `python scripts/jrzb.py setup --manual-login` 清空，避免密码明文留存。")
    elif _lm["mode"] == "skip":
        print("[提示] 当前配置为「跳过登录检查」，不会等待手动登录；登录态过期时会抓不到数据。")
    sys.stdout.flush()

    rc = EXIT_ERROR
    try:
        with open(log_path, "wb") as logfh:
            proc = subprocess.Popen(
                [exe, "start"],
                cwd=os.path.dirname(exe) or None,
                stdout=logfh,
                stderr=subprocess.STDOUT,
            )
            rc = proc.wait()
    except OSError as exc:
        print("[错误] 启动失败: %s" % exc, file=sys.stderr)
        _dump_json(last_run_path(), {
            "started_at": started_at.isoformat(),
            "finished_at": datetime.datetime.now().astimezone().isoformat(),
            "exit_code": rc,
            "log": log_path,
            "status": "Failed",
            "error": "启动失败: %s" % exc,
        })
        return EXIT_ERROR
    except KeyboardInterrupt:
        print("\n[中断] 已手动停止。", file=sys.stderr)
        rc = EXIT_ERROR

    finished_at = datetime.datetime.now().astimezone()
    # 复核最终状态，判断是否异常退出
    try:
        final, _, _ = fetch_status(exe, timeout=30)
    except subprocess.TimeoutExpired:
        final = None
    err_msg = (final or {}).get("Error") or ""
    abnormal = rc != 0 or bool(err_msg)
    summary = {
        "started_at": started_at.isoformat(),
        "finished_at": finished_at.isoformat(),
        "exit_code": rc,
        "log": log_path,
        "status": (final or {}).get("Status"),
        "error": err_msg,
        "abnormal": abnormal,
    }
    _dump_json(last_run_path(), summary)

    dur = (finished_at - started_at).total_seconds()
    print("[结束] 退出码=%s，用时=%.1f 秒" % (rc, dur))
    if abnormal:
        print("[警告] 本轮疑似异常退出：%s" % (err_msg or "退出码非 0"))
        exc = extract_exception_from_log(tail_text(log_path))
        if exc:
            print("[异常栈]\n%s" % exc)
    return rc


def cmd_stop(exe):
    try:
        out, err, rc = _run(exe, "stop", timeout=60)
    except subprocess.TimeoutExpired:
        print("[错误] 停止命令超时。", file=sys.stderr)
        return EXIT_ERROR

    msg = (out or err).strip()
    if rc == 0:
        print(msg or "[已停止] 已发送停止指令。")
        return EXIT_OK
    # 退出码 4：当前没有正在运行的程序
    print(msg or ("[提示] 停止命令返回码 %s。" % rc))
    return rc


# ---------------------------------------------------------------- 下载异常监控

# 错误分类：按关键词归入可读类别（顺序敏感，先匹配先归类）
DL_CATEGORIES = (
    ("附件下载配额已用尽（当日次数达上限）", ("次数已达上限", "已达上限", "次数上限")),
    ("下载错误", ("下载错误", "下载失败", "失败")),
)


def resolve_db(cli_path=None):
    path = (cli_path or os.environ.get(DB_ENV) or _cfg("db")
            or os.path.join(work_root(), "buzdata.db"))
    return _norm(path)


def state_file():
    p = (os.environ.get(STATE_ENV) or _cfg("crawler_state_file")
         or os.path.join(run_dir(), "alert_state.json"))
    p = _norm(p)
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    return p


def load_state():
    p = state_file()
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as fh:
            return json.load(fh) or {}
    except Exception:
        return {}


def save_state(data):
    with open(state_file(), "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def parse_dt(s):
    """解析 '2026-10-12T13:19:54.4629503+08:00' 这类时间，失败返回 None。"""
    s = (s or "").strip()
    if not s or s.startswith("0001"):
        return None
    m = re.match(r"(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})(?:\.(\d+))?(.*)$", s)
    if not m:
        return None
    frac = (m.group(3) or "0")[:6].ljust(6, "0")
    tz = m.group(4) or ""
    try:
        return datetime.datetime.fromisoformat(
            "%sT%s.%s%s" % (m.group(1), m.group(2), frac, tz)
        )
    except Exception:
        return None


def classify_error(msg):
    for label, keys in DL_CATEGORIES:
        if any(k in msg for k in keys):
            return label
    return "其他下载异常"


def fmt_window(minutes):
    if minutes >= 120:
        return "%.0f 小时" % (minutes / 60.0) if minutes % 60 == 0 else "%.1f 小时" % (minutes / 60.0)
    return "%d 分钟" % minutes


def collect_download_errors(db, window_min, now):
    """返回窗口内的下载异常记录列表（按 id 升序）。"""
    con = sqlite3.connect(db, timeout=30)
    con.row_factory = sqlite3.Row
    try:
        rows = con.execute(
            "SELECT ztb_rpa_prjs_id, xmmc, download_error, lastupdatetime, make_date "
            "FROM ztb_rpa_prjs WHERE download_error IS NOT NULL AND download_error<>''"
        ).fetchall()
    finally:
        con.close()

    since = now - datetime.timedelta(minutes=window_min)
    hit = []
    for r in rows:
        msg = (r["download_error"] or "").strip()
        if not msg:
            continue
        ts = parse_dt(r["lastupdatetime"]) or parse_dt(r["make_date"])
        if ts is None:
            continue
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=now.tzinfo)
        if ts >= since:
            hit.append({
                "id": r["ztb_rpa_prjs_id"],
                "name": (r["xmmc"] or "").strip(),
                "error": msg,
                "time": ts.isoformat(),
                "category": classify_error(msg),
            })
    hit.sort(key=lambda x: x["id"])
    return hit


def cmd_check_download(db, window_min, threshold, cooldown_min, as_json=False, dry_run=False,
                        send=False, group=None):
    now = datetime.datetime.now().astimezone()
    now_ts = time.time()

    try:
        hits = collect_download_errors(db, window_min, now)
    except sqlite3.Error as exc:
        print("[错误] 读取数据库失败: %s" % exc, file=sys.stderr)
        return EXIT_ERROR

    # 分类计数
    cats = {}
    for h in hits:
        cats[h["category"]] = cats.get(h["category"], 0) + 1
    count = len(hits)
    max_id = max((h["id"] for h in hits), default=0)

    st = load_state()
    last_ts = float(st.get("last_alert_ts") or 0)
    last_max_id = int(st.get("last_max_id") or 0)
    in_cooldown = (now_ts - last_ts) < cooldown_min * 60

    alert = count >= threshold
    reason = ""
    if not alert:
        reason = "窗口内异常 %d 条，未达阈值 %d" % (count, threshold)
    elif last_max_id and max_id <= last_max_id:
        alert = False
        reason = "无新增异常（自上次提醒后最大 ID 仍为 %d）" % max_id
    elif in_cooldown:
        alert = False
        reason = "处于告警冷却期（%.0f 分钟内已提醒过）" % cooldown_min

    # 生成告警文案
    message = ""
    if alert:
        top = sorted(cats.items(), key=lambda kv: -kv[1])
        sample = hits[-1]
        lines = ["【爬虫告警】附件下载异常频繁"]
        lines.append("近 %s内发现 %d 条下载异常（阈值 %d）" % (fmt_window(window_min), count, threshold))
        lines.append("类型分布：" + "；".join("%s %d条" % (k, v) for k, v in top))
        lines.append("最近异常：ID %s %s" % (sample["id"], (sample["name"] or "")[:30]))
        if "附件下载配额已用尽（当日次数达上限）" in cats:
            lines.append("提示：附件下载配额已用尽，当日无法继续下载附件，可次日重跑或调整下载策略。")
        lines.append("时间：%s" % now.strftime("%Y-%m-%d %H:%M"))
        message = "\n".join(lines)

    result = {
        "ok": True,
        "alert": alert,
        "count": count,
        "threshold": threshold,
        "window_minutes": window_min,
        "cooldown_minutes": cooldown_min,
        "categories": cats,
        "max_id": max_id,
        "reason": reason,
        "message": message,
        "checked_at": now.isoformat(),
    }

    # 记录告警状态（dry_run 不写），用于冷却与「无新增」判重
    if alert and not dry_run:
        save_state({
            "last_alert_ts": now_ts,
            "last_alert_iso": now.isoformat(),
            "last_max_id": max_id,
            "count": count,
            "categories": cats,
        })
        result["state_written"] = state_file()

    # --send：告警时直接发到推送群（未配置群 / 群不可达不算失败，只标记 not_sent）
    if alert and send and not dry_run:
        result["send"] = wecom_send(message, group=group)

    if as_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if alert:
            print("[告警] " + message.replace("\n", "\n       "))
            if result.get("send"):
                s = result["send"]
                print("        推送: %s" % ("已发送到「%s」" % s["group"] if s["ok"]
                                          else "未发送（%s）%s" % (s["error"], s["detail"])))
        else:
            print("[正常] 未触发下载异常告警（%s）。" % (reason or "窗口内异常 %d 条" % count))
    return EXIT_OK


# ---------------------------------------------------------------- 异常退出监控


def _looks_abnormal(err_msg):
    m = (err_msg or "").strip()
    return bool(m) and any(k in m for k in ABNORMAL_ERRORS)


def cmd_check_exit(exe, as_json=False, dry_run=False, tail_lines=20, send=False, group=None):
    """检测爬虫是否异常退出，并给出可直接推送的告警文案。

    - 状态以 `status` 输出为准：Status=Failed 或 Error 非空 即视为异常退出。
    - 异常栈优先从最近一次 start 捕获的运行日志中提取（.NET 未处理异常会打印到 stderr）。
    - 两级去重，避免刷屏：
      ① 同一轮（FinishedAt 相同）只提醒一次；
      ② 同一「崩溃点」（错误文案 + 日志末尾特征行相同）在 EXIT_SIG_COOLDOWN_MIN 分钟内
         只提醒一次（确定性崩溃重启后会反复崩在同一处，无需每次告警）。
    """
    now = datetime.datetime.now().astimezone()
    now_ts = time.time()

    try:
        data, out, err = fetch_status(exe, timeout=30)
    except subprocess.TimeoutExpired:
        print("[错误] 查询状态超时。", file=sys.stderr)
        return EXIT_ERROR
    if data is None:
        print("[错误] 无法解析状态输出：", file=sys.stderr)
        print((out or err).strip(), file=sys.stderr)
        return EXIT_ERROR

    status = data.get("Status")
    err_msg = (data.get("Error") or "").strip()
    started_at = data.get("StartedAt")
    finished_at = data.get("FinishedAt")
    abnormal = bool(err_msg) or status in ("Failed",)

    # 收集证据：最近一次 start 的运行日志
    last = _read_json(last_run_path())
    log_path = last.get("log") or ""
    log_text = tail_text(log_path) if (log_path and os.path.isfile(log_path)) else ""
    exc = extract_exception_from_log(log_text)
    tail_lines_list = [ln.rstrip() for ln in log_text.splitlines() if ln.strip()]

    prev = _read_json(exit_state_path())
    dedup = bool(finished_at) and finished_at == prev.get("last_finished_at")

    # 「同一崩溃点」签名去重：错误文案 + 日志末尾特征行（抹掉易变数字）。
    # 确定性崩溃重启后会反复崩在同一处，冷却期内只提醒一次，避免刷屏；
    # 冷却到期后会自动再次提醒（可设 0 关闭）。
    sig_cooldown = int(os.environ.get(EXIT_SIG_COOLDOWN_ENV) or EXIT_SIG_COOLDOWN_MIN)
    # 取最后一条「有意义」的日志行（跳过 '-----' 这类纯分隔线）作为崩溃点特征
    meaningful = [ln for ln in tail_lines_list if set(ln.strip()) - set("-")]
    lastline = re.sub(r"\d+", "#", meaningful[-1])[:80] if meaningful else ""
    signature = "%s || %s" % (err_msg, lastline)
    prev_sig = prev.get("last_signature") or ""
    prev_ts = float(prev.get("last_alert_ts") or 0)
    same_crash = bool(err_msg) and signature == prev_sig
    in_sig_cooldown = same_crash and sig_cooldown > 0 and (now_ts - prev_ts) < sig_cooldown * 60

    alert = abnormal and not dedup and not in_sig_cooldown
    suppress_reason = ""
    if abnormal and not alert:
        if dedup:
            suppress_reason = "同一轮已提醒过（已去重）"
        elif in_sig_cooldown:
            suppress_reason = "同一崩溃点 %d 分钟内已提醒过（已抑制重复告警）" % sig_cooldown

    message = ""
    if alert:
        lines = ["【爬虫告警】爬虫异常退出"]
        if started_at and finished_at:
            dur = ""
            a, b = parse_dt(started_at), parse_dt(finished_at)
            if a and b:
                dur = "（约 %.1f 分钟）" % ((b - a).total_seconds() / 60.0)
            lines.append("运行区间：%s → %s%s" % (started_at[11:19], finished_at[11:19], dur))
        lines.append("最终状态：%s" % (status or "未知"))
        lines.append("错误信息：%s" % (err_msg or "退出码异常"))
        if exc:
            lines.append("异常详情（程序打印的异常栈）：")
            lines.append(exc)
        elif tail_lines_list:
            lines.append("异常详情：程序内部捕获后静默退出（未打印异常栈），崩溃前最后输出：")
            lines.append("\n".join(tail_lines_list[-8:]))
        else:
            lines.append("异常详情：未捕获到运行日志（可能为旧版启动方式启动）。")
        # 最近采集情况，便于判断崩在哪个阶段
        try:
            con = sqlite3.connect(resolve_db(None), timeout=30)
            con.row_factory = sqlite3.Row
            row = con.execute(
                "SELECT ztb_rpa_prjs_id, xmmc FROM ztb_rpa_prjs ORDER BY ztb_rpa_prjs_id DESC LIMIT 1"
            ).fetchone()
            tot = con.execute("SELECT COUNT(*) FROM ztb_rpa_prjs").fetchone()[0]
            con.close()
            if row:
                lines.append("最近采集：ID %s %s（库内共 %s 条）"
                             % (row["ztb_rpa_prjs_id"], (row["xmmc"] or "")[:30], tot))
        except sqlite3.Error:
            pass
        if log_path:
            lines.append("运行日志：%s" % log_path)
        lines.append("时间：%s" % now.strftime("%Y-%m-%d %H:%M"))
        message = "\n".join(lines)

    result = {
        "ok": True,
        "alert": alert,
        "abnormal": abnormal,
        "status": status,
        "error": err_msg,
        "started_at": started_at,
        "finished_at": finished_at,
        "dedup": dedup,
        "same_crash": same_crash,
        "suppressed": bool(abnormal and not alert),
        "suppress_reason": suppress_reason,
        "signature": signature,
        "log": log_path,
        "exception": exc,
        "message": message,
        "checked_at": now.isoformat(),
    }

    if alert and not dry_run:
        _dump_json(exit_state_path(), {
            "last_finished_at": finished_at,
            "last_alert_ts": now_ts,
            "last_alert_iso": now.isoformat(),
            "error": err_msg,
            "last_signature": signature,
        })
        result["state_written"] = exit_state_path()

    # --send：异常退出告警直接发到推送群（未配置群 / 群不可达不算失败，只标记）
    if alert and send and not dry_run:
        result["send"] = wecom_send(message, group=group)

    if as_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if alert:
            print("[告警] " + message.replace("\n", "\n       "))
            if result.get("send"):
                s = result["send"]
                print("        推送: %s" % ("已发送到「%s」" % s["group"] if s["ok"]
                                          else "未发送（%s）%s" % (s["error"], s["detail"])))
        elif abnormal:
            print("[正常] 已抑制重复告警：%s。" % (suppress_reason or "同上"))
        else:
            print("[正常] 未检测到异常退出（当前状态 %s）。" % (status or "未知"))
    return EXIT_OK


# ---------------------------------------------------------------- 安装向导
#
# 爬虫程序的个性化配置写在 exe 同目录的 xCD.WB.Skill.JRZB.dll.config
# （.NET 的 <程序名>.exe.config）。这些键绑定具体使用者的环境——招标网站账号密码、
# Chrome 路径与用户数据目录、工作目录、翻页数、企业版接口等——每台机器都不同，
# 因此**安装/首次使用时必须逐项向用户确认**，不能沿用打包作者的示例值。
#
#   python jrzb.py setup
#       → 输出「安装向导」报告：字段清单（分组/必填/当前值/是否仍为示例值/提示）
#         + 本机体检结果 + 是否需要配置。智能体据此向用户提问。
#
#   python jrzb.py setup --set "登录账号=13800000000" --set "密码=xxxx" --set "ChromePath=D:\Chrome\chrome.exe"
#       → 写回 app.config（只改 value，保留注释与缩进；改动前自动备份）。
#
#   python jrzb.py setup --set "企业版=true" --set "企业版_aiapi=http://..." --set "企业版_aiapi_xkey=..."
#       → 启用企业版时才需要填企业版_* 各项。
#
# 也支持 --set-json '{"登录账号":"138...","密码":"..."}'，便于程序化调用。

APP_CONFIG_NAMES = ("xCD.WB.Skill.JRZB.dll.config", "xCD.WB.Skill.JRZB.exe.config")

# 说明：不再硬编码「作者本人的账号/密码/用户名」——本脚本随专家包分发，
# 硬编码会把作者凭据散播出去。识别逻辑见 _is_author_placeholder()。

# 向导字段表。level：core=必问（每台机器都不同）；advanced=按需（企业版等）。
SETUP_FIELDS = [
    dict(key="ChromePath", label="Chrome 可执行文件路径", group="浏览器", level="core",
         default=r"C:\Program Files\Google\Chrome\Application\chrome.exe",
         required=False, sensitive=False, kind="path",
         hint="本机 Google Chrome 的 chrome.exe 完整路径；装在别处需改",
         placeholders=[]),
    dict(key="UserDataDir", label="Chrome 用户数据目录", group="浏览器", level="core",
         default="", required=False, sensitive=False, kind="path",
         hint="独立的 Chrome 配置文件目录（保留登录态），不要与日常使用的浏览器混用；"
              "留空则由程序按默认方式处理",
         placeholders=["D:\\ChromeProfile"]),
    dict(key="DebuggingPort", label="CDP 调试端口", group="浏览器", level="core",
         default="9224", required=False, sensitive=False, kind="int",
         hint="Chrome 远程调试端口，需与下方「CDP 连接地址」的端口一致；"
              "若与本机其它程序冲突可改（如 9225）",
         placeholders=[]),
    dict(key="Playwright_CDP_Endpoint", label="CDP 连接地址", group="浏览器", level="core",
         default="http://localhost:9224", required=False, sensitive=False, kind="text",
         hint="Playwright 连接 Chrome 的地址，格式 http://localhost:<调试端口>",
         placeholders=[]),
    dict(key="工作目录", label="爬虫工作目录", group="采集", level="core",
         default="", required=True, sensitive=False, kind="path",
         hint="爬虫写入的根目录（存放采集库/中间文件），通常与本专家配置的 work_root 一致",
         placeholders=["D:\\你的项目根目录"]),
    dict(key="分页页面爬取数", label="每个关键词翻页数", group="采集", level="core",
         default="5", required=False, sensitive=False, kind="int",
         hint="每个关键词列表翻页抓取的页数：越大抓得越多、单轮耗时越长",
         placeholders=[]),
    dict(key="LaunchWaitSeconds", label="Chrome 启动等待秒数", group="浏览器", level="advanced",
         default="30", required=False, sensitive=False, kind="int",
         hint="启动 Chrome 后等待调试端口就绪的最长秒数，机器慢可调大",
         placeholders=[]),
    dict(key="LoginUrl", label="登录门户地址", group="登录", level="advanced",
         default="https://www.arrbid.com/", required=False, sensitive=False, kind="text",
         hint="招标网站首页地址，一般无需修改",
         placeholders=[]),
    dict(key="LoginTimeoutSeconds", label="手动登录等待上限（秒）", group="登录", level="core",
         default="600", required=False, sensitive=False, kind="int",
         hint="程序打开 Chrome 后的等待时间：你在浏览器里完成登录的最长秒数；"
              "超时视为登录失败并停止抓取。手动登录模式建议 600（10 分钟）",
         placeholders=[]),
    dict(key="SkipLogin", label="跳过登录检查", group="登录", level="advanced",
         default="false", required=False, sensitive=False, kind="bool",
         hint="true=不检查登录直接抓取（不推荐，登录态过期时会抓不到数据）；手动登录模式请保持 false",
         placeholders=[]),
    dict(key="企业版", label="是否启用企业版", group="企业版", level="advanced",
         default="false", required=False, sensitive=False, kind="bool",
         hint="true=接入企业版（BPM）能力，需同时填下方企业版_* 各项；不使用保持 false 即可",
         placeholders=[]),
    dict(key="企业版_corpid", label="企业版租户 ID", group="企业版", level="advanced",
         default="1", required=False, sensitive=False, kind="text",
         hint="仅启用企业版时需要",
         placeholders=[]),
    dict(key="企业版_aiapi", label="企业版 AI 接口地址", group="企业版", level="advanced",
         default="http://localhost/aiapi", required=False, sensitive=False, kind="text",
         hint="仅启用企业版时需要",
         placeholders=[]),
    dict(key="企业版_aiapi_xkey", label="企业版 AI 接口密钥", group="企业版", level="advanced",
         default="", required=False, sensitive=True, kind="password",
         hint="仅启用企业版时需要",
         placeholders=[]),
    dict(key="企业版_拷贝到AppData的路径", label="企业版拷贝目标目录", group="企业版", level="advanced",
         default="", required=False, sensitive=False, kind="path",
         hint="企业版运行时把文件拷贝到的 App_Data 目录；仅启用企业版时需要",
         placeholders=[]),
    dict(key="企业版_附件的读取路径", label="企业版附件读取目录", group="企业版", level="advanced",
         default="", required=False, sensitive=False, kind="path",
         hint="企业版读取附件的目录；仅启用企业版时需要",
         placeholders=[]),
]

# 当 exe 目录下完全没有 app.config 时，用这份骨架生成一份（含程序需要的全部键）。
BASE_APP_CONFIG = """<?xml version="1.0" encoding="utf-8" ?>
<configuration>
  <appSettings>
    <add key="分页页面爬取数" value="5"/>
    <add key="登录账号" value=""/>
    <add key="密码" value=""/>
    <add key="Playwright_CDP_Endpoint" value="http://localhost:9224"/>
    <add key="操作系统名称" value="Windows"/>
    <add key="工作目录" value=""/>
    <add key="企业版" value="false"/>
    <add key="企业版_corpid" value="1"/>
    <add key="企业版_aiapi" value="http://localhost/aiapi"/>
    <add key="企业版_aiapi_xkey" value=""/>
    <add key="企业版_拷贝到AppData的路径" value=""/>
    <add key="企业版_附件的读取路径" value=""/>
    <add key="ChromePath" value="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"/>
    <add key="UserDataDir" value=""/>
    <add key="DebuggingPort" value="9224"/>
    <add key="DebuggingAddress" value="0.0.0.0"/>
    <add key="LaunchWaitSeconds" value="30"/>
    <add key="LoginUrl" value="https://www.arrbid.com/"/>
    <add key="LoginTimeoutSeconds" value="600"/>
    <add key="SkipLogin" value="false"/>
  </appSettings>
</configuration>
"""


def app_config_path():
    """爬虫 app.config 路径：优先 exe 同目录下真实存在的那个文件名。"""
    d = os.path.dirname(resolve_exe())
    for name in APP_CONFIG_NAMES:
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return p
    return os.path.join(d, APP_CONFIG_NAMES[0])


def _read_app_config(path):
    """读取 app.config 原文（保留 BOM 与 CRLF）；失败返回 None。"""
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            return f.read()
    except Exception:
        return None


def _xml_escape(v):
    return (str(v).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _xml_unescape(v):
    return (v.replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", '"').replace("&amp;", "&"))


def app_config_get(text, key):
    """取出某个 <add key="..."> 的 value；不存在返回 None。"""
    if not text:
        return None
    m = re.search(r'<add\s+key="%s"\s+value="([^"]*)"' % re.escape(key), text)
    return _xml_unescape(m.group(1)) if m else None


def app_config_set(text, key, value):
    """只改 value，保留注释/缩进/其余内容；键不存在则插入 </appSettings> 之前。

    返回 (新文本, 是否成功)。
    """
    esc = _xml_escape(value)
    pat = re.compile(r'(<add\s+key="%s"\s+value=")[^"]*(")' % re.escape(key))
    if pat.search(text):
        return pat.sub(lambda m: m.group(1) + esc + m.group(2), text), True
    anchor = re.search(r'([ \t]*)</appSettings>', text)
    if not anchor:
        return text, False
    indent = anchor.group(1)
    line = '%s<add key="%s" value="%s"/>' % (indent, key, esc)
    eol = "\r\n" if "\r\n" in text else "\n"
    return text[:anchor.start()] + line + eol + text[anchor.start():], True


# 判定「值看起来仍来自别人的机器 / 别人的配置」。
# 注意：这里**不能**硬编码某个人自己的账号、密码、用户名——本脚本会随专家包分发，
# 硬编码等于把作者凭据散播出去。改为按**模式**识别：
#   1) C:\Users\<别人的用户名>\...   —— 指到别的 Windows 用户目录；
#   2) 另外可通过环境变量 ZB_AUTHOR_MARKERS 临时补充本机要忽略的标记（用 ; 分隔），
#      只影响本机行为，不会写进分发文件。
_FOREIGN_USER_PATH = re.compile(r"[\\/]users[\\/]([^\\/]+)", re.IGNORECASE)


def _author_markers():
    raw = os.environ.get("ZB_AUTHOR_MARKERS", "")
    return tuple(x.strip() for x in raw.split(";") if x.strip())


def _is_author_placeholder(value, field):
    v = (value or "").strip()
    if not v:
        return False
    for p in field.get("placeholders", ()):
        if p and v.lower() == p.lower():
            return True
    for m in _author_markers():
        if m.lower() in v.lower():
            return True
    # 指向「别的 Windows 用户」的路径 = 明显来自别人的机器
    m = _FOREIGN_USER_PATH.search(v)
    if m:
        try:
            me = os.path.basename(os.path.expanduser("~")).lower()
        except Exception:
            me = ""
        if me and m.group(1).lower() != me:
            return True
    return False


def app_config_checks(text):
    """对已填配置做本机体检，返回 [{name, ok, detail}]。"""
    out = []

    def add(name, ok, detail):
        out.append({"name": name, "ok": bool(ok), "detail": str(detail)})

    exe = resolve_exe()
    add("爬虫程序存在", os.path.isfile(exe), exe)
    if text:
        chrome = app_config_get(text, "ChromePath")
        if chrome:
            add("Chrome 可执行文件存在", os.path.isfile(chrome), chrome)
        udd = app_config_get(text, "UserDataDir")
        if udd:
            add("Chrome 用户数据目录可用",
                os.path.isdir(udd) or os.path.isdir(os.path.dirname(udd)), udd)
        wd = app_config_get(text, "工作目录")
        if wd:
            add("工作目录存在", os.path.isdir(wd), wd)
        port = app_config_get(text, "DebuggingPort")
        ep = app_config_get(text, "Playwright_CDP_Endpoint")
        if port and ep:
            add("CDP 端口与连接地址一致", (":%s" % port) in ep,
                "DebuggingPort=%s / Playwright_CDP_Endpoint=%s" % (port, ep))
    return out


def build_setup_report():
    """构建安装向导报告（字段清单 + 体检 + 是否需要配置）。"""
    cp = app_config_path()
    exists = os.path.isfile(cp)
    text = _read_app_config(cp) if exists else None

    fields, reasons = [], []
    for f in SETUP_FIELDS:
        cur = app_config_get(text, f["key"]) if text else None
        ph = _is_author_placeholder(cur, f)
        missing = bool(f.get("required")) and not (cur and cur.strip())
        if f["sensitive"] and cur:
            shown = "******（已填写）" if not ph else "******（仍为示例值）"
        else:
            shown = cur
        fields.append({
            "key": f["key"], "label": f["label"], "group": f["group"],
            "level": f["level"], "sensitive": f["sensitive"], "kind": f["kind"],
            "hint": f["hint"], "default": f["default"], "required": bool(f.get("required")),
            "current": shown, "placeholder": ph, "missing": missing,
        })
        if f["level"] == "core":
            if ph:
                reasons.append("%s 仍为示例值，需替换" % f["label"])
            elif missing and exists:
                reasons.append("%s 未填写" % f["label"])

    if not exists:
        reasons.insert(0, "未找到爬虫配置文件（缺少 app.config，或爬虫程序尚未放到工作目录）")

    return {
        "config_file": cp,
        "config_exists": exists,
        "needs_setup": bool(reasons),
        "reasons": reasons,
        "fields": fields,
        "checks": app_config_checks(text) if exists else [],
        "login_mode": login_mode(),
        "strategy_gate": strategy_gate(),
        "how_to_write": ('python scripts/jrzb.py setup --set "键=值" --set "键=值" ...'
                         '  （或 --set-json \'{"键":"值"}\'）'),
    }


def parse_set_items(items):
    out = {}
    for it in items or []:
        if "=" not in it:
            raise ValueError("--set 需要 KEY=VALUE 形式，收到: %s" % it)
        k, v = it.split("=", 1)
        out[k.strip()] = v
    return out


# ---------------------------------------------------------------- 爬虫运行包（本机 / 远程）
#
# 运行包（xCD.WB.Skill.JRZB.exe + .NET 运行时 + Playwright 驱动）体积约 70MB，
# **不随专家包分发**（开放平台上传上限 20MB），改为安装时按需获取：
# 优先用本机已有文件，找不到再按 HTTPS 地址下载并校验 SHA256。
#
# 该 zip **不含** buzdata.db（业务数据）与本机 xCD.WB.Skill.JRZB.dll.config（含账号密码）。
#
# 获取顺序：
#   1) JRZB_RUNTIME_BUNDLE 指定的本地文件
#   2) <pkg>/crawler/jrzb-runtime.zip       （离线自备：手工放进来也能用）
#   3) <state_root>/jrzb-runtime.zip        （下载缓存，已存在则直接复用）
#   4) 按 JRZB_RUNTIME_URL / <pkg>/crawler/runtime-source.json 里的 URL 下载
#
# 下载配置（crawler/runtime-source.json，字段可被环境变量覆盖）：
#   {"runtime": {"url": "https://.../jrzb-runtime-2.9.0.zip",
#                "sha256": "<下载包的 SHA256>", "version": "2.9.0", "size": 72670000}}
#   环境变量：JRZB_RUNTIME_URL / JRZB_RUNTIME_SHA256

RUNTIME_BUNDLE_ENV = "JRZB_RUNTIME_BUNDLE"
RUNTIME_URL_ENV = "JRZB_RUNTIME_URL"
RUNTIME_SHA256_ENV = "JRZB_RUNTIME_SHA256"
RUNTIME_BUNDLE_NAME = "jrzb-runtime.zip"
RUNTIME_SOURCE_NAME = "runtime-source.json"
RUNTIME_DOWNLOAD_TIMEOUT = 300          # 单次下载超时（秒）


def _pkg_root():
    """专家包根目录：<pkg>/skills/jrzb-crawler/scripts/jrzb.py -> <pkg>"""
    here = os.path.dirname(os.path.abspath(__file__))               # .../scripts
    return os.path.dirname(os.path.dirname(os.path.dirname(here)))  # .../<pkg>


def _sha256_file(path, chunk=1 << 20):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for blk in iter(lambda: fh.read(chunk), b""):
            h.update(blk)
    return h.hexdigest()


def runtime_source():
    """运行包获取配置：包内 runtime-source.json > state_root 同名文件 > 环境变量覆盖。"""
    info = {"url": "", "sha256": "", "version": "", "size": 0}
    for p in (os.path.join(_pkg_root(), "crawler", RUNTIME_SOURCE_NAME),
              os.path.join(state_root(), RUNTIME_SOURCE_NAME)):
        try:
            with open(p, "r", encoding="utf-8") as fh:
                data = json.load(fh) or {}
        except (OSError, ValueError):
            continue
        if isinstance(data, dict):
            if isinstance(data.get("runtime"), dict):
                data = data["runtime"]
            for k in ("url", "sha256", "version", "size"):
                if data.get(k) not in (None, ""):
                    info[k] = data[k]
            break
    if (os.environ.get(RUNTIME_URL_ENV) or "").strip():
        info["url"] = os.environ[RUNTIME_URL_ENV].strip()
    if (os.environ.get(RUNTIME_SHA256_ENV) or "").strip():
        info["sha256"] = os.environ[RUNTIME_SHA256_ENV].strip().lower()
    return info


def runtime_bundle_path():
    """定位**本机已有**的爬虫运行包；找不到返回 None（不联网）。"""
    cands = []
    envp = os.environ.get(RUNTIME_BUNDLE_ENV)
    if envp:
        cands.append(envp)
    cands.append(os.path.join(_pkg_root(), "crawler", RUNTIME_BUNDLE_NAME))
    cands.append(os.path.join(state_root(), RUNTIME_BUNDLE_NAME))
    for p in cands:
        if os.path.isfile(p):
            return p
    return None


def download_runtime_bundle(url="", sha256="", dest="", force=False, quiet=False):
    """按 URL 下载运行包到本地缓存（默认 <state_root>/jrzb-runtime.zip）。

    带 sha256 时**强制校验**，不匹配即删除并报错（防止下到残缺包或被替换的文件）。
    返回 dict：{ok, url, path, bytes, sha256, from_cache, error}
    """
    import urllib.error
    import urllib.request

    src = runtime_source()
    url = (url or src["url"] or "").strip()
    sha256 = (sha256 or src["sha256"] or "").strip().lower()
    res = {"ok": False, "url": url, "path": "", "bytes": 0, "sha256": "",
           "from_cache": False}
    if not url:
        res["error"] = ("未配置运行包下载地址。请在 crawler/%s 里填写 url，"
                        "或设置环境变量 %s。" % (RUNTIME_SOURCE_NAME, RUNTIME_URL_ENV))
        return res
    if not re.match(r"^(https?|file)://", url):
        res["error"] = "下载地址必须以 http:// 或 https:// 开头：%s" % url
        return res

    dest = dest or os.path.join(state_root(), RUNTIME_BUNDLE_NAME)
    if os.path.isfile(dest) and not force:
        if not sha256 or _sha256_file(dest) == sha256:
            res.update(ok=True, path=dest, bytes=os.path.getsize(dest), from_cache=True)
            return res

    try:
        os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    except OSError as exc:
        res["error"] = "无法创建缓存目录：%s" % exc
        return res

    part = dest + ".part"
    try:
        if not quiet:
            print("  运行包下载中: %s" % url)
        req = urllib.request.Request(url, headers={"User-Agent": "jrzb-crawler/1.0"})
        with urllib.request.urlopen(req, timeout=RUNTIME_DOWNLOAD_TIMEOUT) as resp, \
                open(part, "wb") as out:
            total = 0
            while True:
                blk = resp.read(1 << 20)
                if not blk:
                    break
                out.write(blk)
                total += len(blk)
        got = _sha256_file(part)
        if sha256 and got != sha256:
            os.remove(part)
            res["error"] = ("运行包 SHA256 校验失败：期望 %s，实际 %s。"
                            "可能是下载不完整或服务器上的文件已被替换。" % (sha256, got))
            res["sha256"] = got
            return res
        os.replace(part, dest)
        res.update(ok=True, path=dest, bytes=total, sha256=got)
        if not quiet:
            print("  已下载并缓存: %s（%.1f MB）" % (dest, total / 1048576.0))
        return res
    except (urllib.error.URLError, OSError, ValueError) as exc:
        try:
            if os.path.isfile(part):
                os.remove(part)
        except OSError:
            pass
        res["error"] = "下载失败：%s" % exc
        return res


def runtime_bundle_acquire(url="", sha256="", auto_download=True, quiet=False):
    """拿到可用运行包：本机已有 → 复用缓存 → 按 URL 下载。

    返回 (path|None, source_note, error|None)
    """
    p = runtime_bundle_path()
    if p:
        return p, "本机已有: %s" % p, None
    if not auto_download:
        return None, "", ("已禁用联网下载（--no-download），且本机未找到 %s。"
                          % RUNTIME_BUNDLE_NAME)
    dl = download_runtime_bundle(url=url, sha256=sha256, quiet=quiet)
    if dl.get("ok"):
        note = "复用下载缓存: %s" % dl["path"] if dl.get("from_cache") else \
               "已从 %s 下载" % dl["url"]
        return dl["path"], note, None
    return None, "", dl.get("error") or "下载失败"


def install_crawler(target, force=False, url="", sha256="", auto_download=True):
    """把爬虫运行包解压到 target（运行包缺失时可按 URL 自动下载）。

    - 已存在的文件默认**保留**（不覆盖用户已配好的 config / 已有数据库），除非 force。
    - buzdata.db 与 *.dll.config 永不写入（属业务数据 / 本机个性化配置）。
    - 解压后若仍无 app.config，用内置骨架生成一份，便于随后跑 setup 逐项填写。
    """
    import shutil
    import zipfile

    bundle, source_note, err = runtime_bundle_acquire(
        url=url, sha256=sha256, auto_download=auto_download)
    res = {
        "ok": False, "target": target, "bundle": bundle, "bundle_source": source_note,
        "extracted": 0, "kept": 0, "skipped_protected": [], "config_created": False,
        "force": bool(force), "next_steps": [],
    }
    if not bundle:
        res["error"] = (
            "%s\n"
            "  运行包（约 70MB）不随专家包分发，安装时需要联网获取。请任选一种方式：\n"
            "    ① 在 crawler/%s 里填好 url（推荐，一次填好长期可用）；\n"
            "    ② 临时指定：python jrzb.py setup --install-crawler --runtime-url \"https://...\"\n"
            "    ③ 离线：把 jrzb-runtime.zip 放到 <专家包>/crawler/ 或 %s 下，"
            "或用 %s 指向它。"
            % (err or "未找到爬虫运行包。", RUNTIME_SOURCE_NAME,
               os.path.join(state_root(), RUNTIME_BUNDLE_NAME), RUNTIME_BUNDLE_ENV))
        return res

    try:
        os.makedirs(target, exist_ok=True)
    except OSError as exc:
        res["error"] = "无法创建目标目录 %s：%s" % (target, exc)
        return res

    protected = {"buzdata.db"}
    protected_cfg = set(APP_CONFIG_NAMES)

    try:
        with zipfile.ZipFile(bundle) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                name = info.filename
                # 防目录穿越
                if name.startswith("/") or ".." in name.replace("\\", "/").split("/"):
                    continue
                base = os.path.basename(name)
                if base in protected or base in protected_cfg:
                    res["skipped_protected"].append(name)
                    continue
                dst = os.path.join(target, *name.replace("\\", "/").split("/"))
                if os.path.exists(dst) and not force:
                    res["kept"] += 1
                    continue
                os.makedirs(os.path.dirname(dst) or target, exist_ok=True)
                with z.open(info) as src, open(dst, "wb") as out:
                    shutil.copyfileobj(src, out)
                res["extracted"] += 1
    except (zipfile.BadZipFile, OSError) as exc:
        res["error"] = "解压失败（%s）：%s" % (bundle, exc)
        return res

    # 兜底：没有 app.config 时生成骨架，便于直接跑 setup
    cfg = os.path.join(target, APP_CONFIG_NAMES[0])
    if not any(os.path.isfile(os.path.join(target, n)) for n in APP_CONFIG_NAMES):
        try:
            with open(cfg, "w", encoding="utf-8-sig", newline="") as f:
                f.write(BASE_APP_CONFIG)
            res["config_created"] = True
        except OSError:
            pass

    res["ok"] = True
    res["exe"] = os.path.join(target, EXE_NAME)
    res["exe_exists"] = os.path.isfile(res["exe"])
    res["next_steps"] = [
        'python jrzb.py config --work-root "%s"' % target,
        "python jrzb.py setup",
    ]
    return res


def format_install_result(res):
    lines = ["爬虫运行包解包", "运行包: %s" % (res.get("bundle") or "（未找到）")]
    if res.get("bundle_source"):
        lines.append("来源  : %s" % res["bundle_source"])
    if res.get("error"):
        lines.append("状态: 失败")
        lines.append("  " + res["error"])
        return "\n".join(lines)
    lines.append("目标目录: %s" % res["target"])
    if res.get("workspace"):
        lines.append("工作区锚定: %s（爬虫程序/数据库/状态日志都在工作区内）" % res["workspace"])
    lines.append("状态: 完成 —— 释放 %d 个文件，保留已存在 %d 个%s"
                 % (res["extracted"], res["kept"], "（--force 覆盖模式）" if res["force"] else ""))
    if res["skipped_protected"]:
        lines.append("已跳过（受保护，不随包分发）: %s" % "、".join(res["skipped_protected"]))
    if res["config_created"]:
        lines.append("已生成 app.config 骨架（空值，待 setup 填写）")
    if res.get("config_aligned"):
        lines.append("已对齐共享配置: %s" % json.dumps(res["config_aligned"], ensure_ascii=False))
    if not res.get("exe_exists"):
        lines.append("⚠ 目标目录内未找到 %s，请确认运行包完整性" % EXE_NAME)
    lines.append("")
    lines.append("下一步:")
    for s in res["next_steps"]:
        lines.append("  " + s)
    lines.append("  然后 python jrzb.py setup --set \"登录账号=...\" ... 写入个性化配置")
    return "\n".join(lines)


def _align_shared_config(target):
    """把共享配置对齐到刚安装的位置：work_root=目标目录，state_root=工作区内的 .workbuddy。

    目的：装完就"保持在工作区运行"，不需要用户再手动 config 一次。
    返回实际改动的键值（没变则为空）。

    写入目标用 `align_config_path()`：能识别工作区时**写进工作区**
    （`<工作区>/.workbuddy/zb-tender.json`），避免落到主目录、破坏"文件都在工作区"。
    读取仍走 `config_path()`，以便继承已有配置里的其它键。
    """
    global _CONFIG_CACHE
    read_from = config_path()
    cp = align_config_path()
    try:
        with open(read_from, "r", encoding="utf-8") as f:
            cfg = json.load(f) or {}
    except Exception:
        cfg = {}
    changes = {}
    cur_wr = (cfg.get("work_root") or "").strip()
    if not cur_wr or _norm(cur_wr) != _norm(target):
        cfg["work_root"] = _norm(target)
        changes["work_root"] = cfg["work_root"]
    ws = workspace_dir()
    if ws:
        want_state = os.path.join(ws, WORKSPACE_STATE_SUBDIR)
        cur_sr = (cfg.get("state_root") or "").strip()
        if not cur_sr or _norm(cur_sr) != _norm(want_state):
            cfg["state_root"] = _norm(want_state)
            changes["state_root"] = cfg["state_root"]
    if changes:
        try:
            os.makedirs(os.path.dirname(cp) or ".", exist_ok=True)
            with open(cp, "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            _CONFIG_CACHE = None
        except OSError:
            return {}
    return changes


def cmd_setup(argv):
    """安装向导：获取并解包爬虫运行包 / 查看需确认的配置 / 写回 app.config。"""
    # 1) 解包运行包（本机已有则直接用；没有则按 URL 下载，见 runtime-source.json）
    if getattr(argv, "install_crawler", None) is not None:
        arg = (getattr(argv, "install_crawler", "") or "").strip()
        target = arg or default_install_dir()
        res = install_crawler(
            target,
            force=getattr(argv, "force", False),
            url=getattr(argv, "runtime_url", None) or "",
            sha256=getattr(argv, "runtime_sha256", None) or "",
            auto_download=not getattr(argv, "no_download", False),
        )
        if res["ok"]:
            res["workspace"] = workspace_dir()
            res["config_aligned"] = _align_shared_config(target)
            # 目录变了则重新给出下一步
            if os.path.isdir(target):
                res["next_steps"] = [
                    'python jrzb.py config --work-root "%s"' % target,
                    "python jrzb.py setup",
                ]
        if getattr(argv, "json", False):
            print(json.dumps(res, ensure_ascii=False, indent=2))
        else:
            print(format_install_result(res))
        return EXIT_OK if res["ok"] else EXIT_ERROR

    updates = {}
    try:
        # 预设：一键切到「手动登录模式」——清空账号密码 + 打开登录检查 + 给足等待时间
        if getattr(argv, "manual_login", False):
            updates.update({
                "登录账号": "", "密码": "",
                "SkipLogin": "false",
                "LoginTimeoutSeconds": str(getattr(argv, "timeout", None) or 600),
            })
        updates.update(parse_set_items(getattr(argv, "set", None)))
        raw = getattr(argv, "set_json", None)
        if raw:
            updates.update(json.loads(raw))
    except (ValueError, json.JSONDecodeError) as exc:
        print("[错误] 解析 --set 失败: %s" % exc, file=sys.stderr)
        return EXIT_ERROR

    if not updates:
        report = build_setup_report()
        if getattr(argv, "json", False):
            print(json.dumps(report, ensure_ascii=False, indent=2))
        else:
            print(format_setup_report(report))
        return EXIT_OK

    cp = app_config_path()
    exists = os.path.isfile(cp)
    text = _read_app_config(cp) if exists else None
    created = False
    if text is None:
        text = BASE_APP_CONFIG
        created = True

    backup = None
    if exists:
        try:
            import shutil
            stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
            backup = "%s.bak-%s" % (cp, stamp)
            seq = 2
            while os.path.exists(backup):   # 同一秒内多次写入不覆盖上次备份
                backup = "%s.bak-%s-%d" % (cp, stamp, seq)
                seq += 1
            shutil.copy2(cp, backup)
        except OSError:
            backup = None

    known = {f["key"] for f in SETUP_FIELDS}
    changed, unknown, not_found = [], [], []
    for k, v in updates.items():
        if k not in known:
            unknown.append(k)
        text, ok = app_config_set(text, k, v)
        (changed if ok else not_found).append(k)

    try:
        os.makedirs(os.path.dirname(cp) or ".", exist_ok=True)
        with open(cp, "w", encoding="utf-8-sig", newline="") as f:
            f.write(text)
    except OSError as exc:
        print("[错误] 写入配置失败: %s" % exc, file=sys.stderr)
        return EXIT_ERROR

    report = build_setup_report()
    report["written"] = {
        "config_file": cp,
        "created": created,
        "backup": backup,
        "changed": changed,
        "unknown_keys": unknown,
        "not_found": not_found,
    }
    if getattr(argv, "json", False):
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print("[写入] %s%s" % (cp, "（新建）" if created else ""))
        if backup:
            print("[备份] 原配置已备份为: %s" % backup)
        if changed:
            print("[已更新] " + "、".join(changed))
        if unknown:
            print("[提示] 以下键不在向导清单中，已按原样写入: " + "、".join(unknown))
        if not_found:
            print("[警告] 未能写入（配置中无 appSettings 节点）: " + "、".join(not_found))
        print()
        print(format_setup_report(report))
    return EXIT_OK if not not_found else EXIT_ERROR


def format_setup_report(report):
    lines = ["爬虫个性化配置（安装向导）", "配置文件: %s%s" % (
        report["config_file"], "" if report["config_exists"] else "（不存在）")]
    if report["needs_setup"]:
        lines.append("状态: 需要配置 —— " + "；".join(report["reasons"]))
    else:
        lines.append("状态: 已配置完成")

    lm = report.get("login_mode") or {}
    if lm:
        lines.append("登录方式: %s —— %s" % (
            {"manual": "手动登录（推荐）", "configured": "配置了账号密码（程序未使用）",
             "skip": "跳过登录检查"}.get(lm.get("mode"), lm.get("mode")), lm.get("hint", "")))
        lines.append("  登录等待上限: %s 秒（LoginTimeoutSeconds）"
                     % lm.get("login_timeout_seconds"))

    sg = report.get("strategy_gate") or {}
    if sg:
        if sg.get("blocked"):
            lines.append("策略闸门: ⛔ 未提供《投标策略》—— **采集会被拒绝**（退出码 5）")
            lines.append("  核心字段缺失: %s" % "、".join(sg.get("core_missing") or []))
            lines.append("  配置方式: %s" % (sg.get("how_to_fix") or [""])[0])
            lines.append("  应急放行: start --allow-without-strategy（不建议）")
        else:
            lines.append("策略闸门: ✓ 已提供《投标策略》，可正常采集")

    lines.append("")
    for level, title in (("core", "必问项（每台机器都不同）"), ("advanced", "按需项（一般保持默认）")):
        rows = [f for f in report["fields"] if f["level"] == level]
        if not rows:
            continue
        lines.append("【%s】" % title)
        for f in rows:
            if f["current"] not in (None, ""):
                cur = f["current"]
            elif f["default"]:
                cur = "（未配置，将用默认 %s）" % f["default"]
            else:
                cur = "（空）"
            flag = "⚠ 需替换" if f["placeholder"] else ("✗ 未填" if f["missing"] else "✓")
            need = "必填" if f["required"] else "可选"
            lines.append("  - %s（%s，%s）[%s] %s" % (f["label"], f["key"], need, flag, cur))
            lines.append("      说明: %s；默认: %s" % (f["hint"], f["default"] or "（无）"))
        lines.append("")

    checks = report.get("checks") or []
    if checks:
        lines.append("【本机体检】")
        for c in checks:
            lines.append("  %s %s —— %s" % ("✓" if c["ok"] else "✗", c["name"], c["detail"]))
        lines.append("")

    if report["needs_setup"]:
        lines.append("写入方式: %s" % report["how_to_write"])
    lines.append("一键切换手动登录模式: python scripts/jrzb.py setup --manual-login [--timeout 600]")
    lines.append("（向导不再询问「登录账号 / 密码」：爬虫不读取这两个键，登录在浏览器里手动完成）")
    return "\n".join(lines)


def cmd_config(argv):
    """查看 / 写入共享路径配置（~/.workbuddy/zb-tender.json）。"""
    cp = config_path()
    updates = {}
    for attr, key in (("work_root", "work_root"), ("state_root", "state_root"),
                      ("exe", "crawler_exe"), ("db", "db"),
                      ("run_dir", "crawler_run_dir"), ("chat_id", "wecom_chat_id")):
        val = getattr(argv, attr, None)
        if val:
            updates[key] = val.strip() if key == "wecom_chat_id" else _norm(val)

    if updates:
        try:
            with open(cp, "r", encoding="utf-8") as f:
                cfg = json.load(f) or {}
        except Exception:
            cfg = {}
        cfg.update(updates)
        os.makedirs(os.path.dirname(cp) or ".", exist_ok=True)
        with open(cp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)

    exe = resolve_exe()
    db = resolve_db()
    info = {
        "config_file": cp,
        "config_exists": os.path.isfile(cp),
        "config": load_config(),
        "resolved": {
            "work_root": work_root(),
            "state_root": state_root(),
            "workspace": workspace_dir(),
            "package_root": package_root(),
            "crawler_exe": exe,
            "crawler_exe_exists": os.path.isfile(exe),
            "db": db,
            "db_exists": os.path.isfile(db),
            "run_dir": run_dir(),
        },
        "env_overrides": {k: os.environ[k] for k in
                          ("ZB_CONFIG", "ZB_WORK_ROOT", "ZB_STATE_ROOT",
                           "JRZB_EXE", "JRZB_DB", "JRZB_STATE", "JRZB_RUN_DIR")
                          if os.environ.get(k)},
    }
    # 顺带提示爬虫个性化配置（app.config）是否完成，便于首次安装时发现问题
    try:
        acp = app_config_path()
        acp_exists = os.path.isfile(acp)
        text = _read_app_config(acp) if acp_exists else None
        pending = []
        for f in SETUP_FIELDS:
            if f["level"] != "core":
                continue
            cur = app_config_get(text, f["key"]) if text else None
            if _is_author_placeholder(cur, f) or (f.get("required") and not (cur and cur.strip())):
                pending.append(f["key"])
        info["crawler_app_config"] = {
            "file": acp,
            "exists": acp_exists,
            "needs_setup": bool(pending) or not acp_exists,
            "pending_keys": pending,
            "hint": '运行 python scripts/jrzb.py setup 查看安装向导',
        }
    except Exception:
        pass
    if updates:
        info["updated"] = updates
    print(json.dumps(info, ensure_ascii=False, indent=2))
    return EXIT_OK


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="招标数据爬虫 (xCD.WB.Skill.JRZB.exe) 控制脚本"
    )
    parser.add_argument("action",
                        choices=["status", "start", "stop", "check-download",
                                 "check-exit", "config", "setup",
                                 "login-state", "wait-login", "notify"],
                        help="要执行的操作")
    parser.add_argument("--exe", help="xCD.WB.Skill.JRZB.exe 的完整路径")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出（status / check-download）")
    parser.add_argument("--force", action="store_true",
                        help="状态为 Running 时也强制启动（start）；安装向导里表示覆盖已存在的运行文件（setup --install-crawler）")
    parser.add_argument("--db", help="buzdata.db 路径（仅 check-download）")
    parser.add_argument("--work-root", dest="work_root", help="项目根目录（config：含爬虫程序与 buzdata.db）")
    parser.add_argument("--state-root", dest="state_root", help="状态根目录（config：运行日志/告警状态）")
    parser.add_argument("--run-dir", dest="run_dir", help="本技能运行目录（config）")
    parser.add_argument("--chat-id", dest="chat_id", help="企业微信推送目标 chat_id（config，供文档参考）")
    parser.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                        help="安装向导：写入 app.config 的键值，可重复（setup）")
    parser.add_argument("--set-json", dest="set_json", metavar="JSON",
                        help='安装向导：以 JSON 对象批量写入 app.config（setup），如 {"登录账号":"138..."}')
    parser.add_argument("--install-crawler", dest="install_crawler", nargs="?",
                        const="", default=None, metavar="DIR",
                        help="安装向导：把爬虫运行包解压到 DIR（省略 DIR 则解压到 work_root）；"
                             "本机没有运行包时会按 runtime-source.json 的 url 下载")
    parser.add_argument("--runtime-url", dest="runtime_url", metavar="URL",
                        help="安装向导：临时指定运行包下载地址（优先于 runtime-source.json）")
    parser.add_argument("--runtime-sha256", dest="runtime_sha256", metavar="HASH",
                        help="安装向导：运行包 SHA256 校验值（填写后强制校验）")
    parser.add_argument("--no-download", dest="no_download", action="store_true",
                        help="安装向导：禁止联网下载运行包，只用本机已有文件")
    parser.add_argument("--manual-login", dest="manual_login", action="store_true",
                        help="安装向导：一键切到手动登录模式（清空账号密码 + 打开登录检查 + 给足等待时间）（setup）")
    parser.add_argument("--timeout", type=int,
                        help="等待登录上限秒数（wait-login；setup --manual-login 时用于设置 LoginTimeoutSeconds）")
    parser.add_argument("--interval", type=int, default=10,
                        help="wait-login 轮询间隔秒数（默认 10）")
    parser.add_argument("--no-stop-on-timeout", dest="no_stop_on_timeout", action="store_true",
                        help="wait-login 等待超时后不自动停止爬虫（默认会停止）")
    parser.add_argument("--allow-without-strategy", dest="allow_without_strategy", action="store_true",
                        help="应急：未配置《投标策略》时也允许启动采集（默认拒绝）")
    parser.add_argument("--window", type=int, default=DL_WINDOW_MIN,
                        help="观察窗口分钟数（仅 check-download，默认 %d）" % DL_WINDOW_MIN)
    parser.add_argument("--threshold", type=int, default=DL_THRESHOLD,
                        help="告警阈值条数（仅 check-download，默认 %d）" % DL_THRESHOLD)
    parser.add_argument("--cooldown", type=int, default=DL_COOLDOWN_MIN,
                        help="告警冷却分钟数（仅 check-download，默认 %d）" % DL_COOLDOWN_MIN)
    parser.add_argument("--dry-run", action="store_true",
                        help="仅检查不记录告警状态（check-download）；notify 时表示只测通道不发送")
    parser.add_argument("--send", action="store_true",
                        help="告警时直接发到推送群（check-download / check-exit）")
    parser.add_argument("--group", help="临时覆盖推送群名称（默认取配置 wecom_push_group）")
    parser.add_argument("--text", help="要发送的 markdown 正文（notify）")
    parser.add_argument("--text-file", dest="text_file", help="从文件读取正文（notify，长文本推荐）")
    args = parser.parse_args(argv)

    # config / setup 用于查看/写入配置，不依赖 exe 是否存在
    if args.action == "config":
        return cmd_config(args)
    if args.action == "setup":
        return cmd_setup(args)

    # 登录状态探测 / 等待登录：只读运行日志，不依赖 exe 存在
    if args.action == "login-state":
        return cmd_login_state(args)
    if args.action == "wait-login":
        return cmd_wait_login(args)

    # notify 只发消息，不依赖 exe
    if args.action == "notify":
        return cmd_notify(args)

    # check-download 不依赖 exe，单独处理
    if args.action == "check-download":
        return cmd_check_download(
            resolve_db(args.db), args.window, args.threshold, args.cooldown,
            as_json=args.json, dry_run=args.dry_run,
            send=args.send, group=args.group,
        )

    exe = resolve_exe(args.exe)
    if not os.path.isfile(exe):
        print("[错误] 未找到爬虫程序: %s" % exe, file=sys.stderr)
        print("       请先配置路径，例如：", file=sys.stderr)
        print('         python jrzb.py config --work-root "<项目根目录>"', file=sys.stderr)
        print('         或：python jrzb.py config --exe "<xCD.WB.Skill.JRZB.exe 完整路径>"', file=sys.stderr)
        return EXIT_ERROR

    if args.action == "status":
        return cmd_status(exe, as_json=args.json)
    if args.action == "start":
        return cmd_start(exe, force=args.force,
                         allow_without_strategy=args.allow_without_strategy)
    if args.action == "stop":
        return cmd_stop(exe)
    if args.action == "check-exit":
        return cmd_check_exit(exe, as_json=args.json, dry_run=args.dry_run,
                              send=args.send, group=args.group)
    return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
