#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""招投标情报专家包 · 工作区自包含安装器

把整套东西**锚定到工作区**里，做到「装到哪台电脑，就落在那个工作区，并长期在那里运行」：

    ① 技能 →   <工作区>/.workbuddy/skills/{jrzb-crawler,ztb-analyzer}   （项目级技能）
    ② 爬虫 →   <工作区>/jrzb_spider/                                   （程序 + 后续自建 buzdata.db）
               —— 运行包（约 70MB）不随专家包分发，本机没有时按
                  crawler/runtime-source.json 里的地址下载并校验 SHA256
    ③ 配置 →   <工作区>/.workbuddy/zb-tender.json（work_root / state_root 都指向工作区内）
               —— 状态、日志、锁、素材包、策略、共享配置**都不出工作区**

装完后，工作区是**自包含**的：技能、爬虫、数据库、状态、配置全在里面，可整体搬走。

用法::

    python install.py                          # 用环境变量自动识别工作区
    python install.py --workspace "D:\\我的工作区"
    python install.py --no-skills              # 不把技能复制到工作区（避免与专家包内的技能重复）
    python install.py --no-crawler             # 只做技能与配置，不装爬虫运行环境
    python install.py --force                  # 覆盖工作区里已存在的技能文件
    python install.py --dry-run                # 只打印计划，不落盘

注意：
    - **不覆盖**已存在的技能文件与爬虫文件（除非 --force）；`buzdata.db` 与
      `xCD.WB.Skill.JRZB.dll.config`（含账号密码）永远不写。
    - 本脚本**不会**创建定时任务 —— 定时任务只能由 WorkBuddy 平台能力创建，
      脚本/文件操作一律禁止。装完请让 WorkBuddy 的专家按 README 的
      《⏰ 定时任务》一节创建。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

PKG_ROOT = os.path.dirname(os.path.abspath(__file__))
SKILLS_SRC = os.path.join(PKG_ROOT, "skills")
CRAWLER_SCRIPT = os.path.join(PKG_ROOT, "skills", "jrzb-crawler", "scripts", "jrzb.py")

WORKSPACE_ENVS = ("WORKBUDDY_PROJECT_DIR", "CODEBUDDY_PROJECT_DIR", "CLAUDE_PROJECT_DIR")
SKILL_NAMES = ("jrzb-crawler", "ztb-analyzer")
CRAWLER_SUBDIR = "jrzb_spider"
STATE_SUBDIR = ".workbuddy"


def shared_config_path(ws=None):
    """共享配置文件路径。

    优先级：`ZB_CONFIG` 环境变量（隔离测试用） > **工作区内的** `.workbuddy/zb-tender.json`
    > 用户主目录。默认写进工作区，让整套东西自包含、可整体搬走。
    """
    p = (os.environ.get("ZB_CONFIG") or "").strip()
    if p:
        return os.path.abspath(os.path.expanduser(p))
    if ws:
        return os.path.join(ws, STATE_SUBDIR, "zb-tender.json")
    return os.path.join(os.path.expanduser("~"), ".workbuddy", "zb-tender.json")


def workspace_dir(cli_value=None):
    if cli_value:
        p = os.path.abspath(os.path.expanduser(cli_value))
        return p, "参数 --workspace"
    for k in WORKSPACE_ENVS:
        v = (os.environ.get(k) or "").strip()
        if v and os.path.isdir(v):
            return os.path.abspath(v), "环境变量 %s" % k
    return None, None


def copy_tree(src, dst, force=False, dry_run=False):
    """把 src 目录复制到 dst；已存在文件默认保留。返回 (added, kept)。"""
    added = kept = 0
    for root, _dirs, files in os.walk(src):
        for f in files:
            sp = os.path.join(root, f)
            rel = os.path.relpath(sp, src)
            dp = os.path.join(dst, rel)
            if os.path.exists(dp) and not force:
                kept += 1
                continue
            if dry_run:
                added += 1
                continue
            os.makedirs(os.path.dirname(dp) or ".", exist_ok=True)
            shutil.copy2(sp, dp)
            added += 1
    return added, kept


def read_config_for_merge(ws):
    """读取用于合并的配置：优先工作区内，其次用户主目录（继承已有键，避免丢配置）。"""
    for p in (shared_config_path(ws),
              os.path.join(os.path.expanduser("~"), ".workbuddy", "zb-tender.json")):
        try:
            with open(p, "r", encoding="utf-8") as fh:
                return json.load(fh) or {}
        except Exception:
            continue
    return {}


def align_config(ws, work_root_path, dry_run=False):
    """把共享配置写到工作区内，并让 work_root / state_root 都指向工作区。"""
    cfg_path = shared_config_path(ws)
    cfg = read_config_for_merge(ws)
    want = {"work_root": work_root_path,
            "state_root": os.path.join(ws, STATE_SUBDIR)}
    changed = {}
    for k, v in want.items():
        if os.path.normcase(cfg.get(k) or "") != os.path.normcase(v):
            cfg[k] = v
            changed[k] = v
    if changed and not dry_run:
        os.makedirs(os.path.dirname(cfg_path) or ".", exist_ok=True)
        with open(cfg_path, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, ensure_ascii=False, indent=2)
    return changed


def main():
    ap = argparse.ArgumentParser(description="招投标情报专家包 · 工作区自包含安装器")
    ap.add_argument("--workspace", help="工作区目录（省略则从环境变量识别）")
    ap.add_argument("--no-skills", dest="skills", action="store_false", help="不复制技能到工作区")
    ap.add_argument("--no-crawler", dest="crawler", action="store_false", help="不安装爬虫运行环境")
    ap.add_argument("--force", action="store_true", help="覆盖已存在的技能文件")
    ap.add_argument("--dry-run", action="store_true", help="只打印计划，不落盘")
    a = ap.parse_args()

    ws, how = workspace_dir(a.workspace)
    print("=" * 68)
    print("招投标情报专家包 · 工作区自包含安装")
    print("  专家包  : %s" % PKG_ROOT)
    if not ws:
        print("  ✗ 未能识别工作区。请显式指定：")
        print('      python install.py --workspace "D:\\我的工作区"')
        print("    或在 WorkBuddy 里以「工作区」方式打开目标目录后重试。")
        return 1
    print("  工作区  : %s   （来源：%s）" % (ws, how))

    crawl_dir = os.path.join(ws, CRAWLER_SUBDIR)
    skills_dst = os.path.join(ws, STATE_SUBDIR, "skills")
    print("  技能落点: %s" % skills_dst)
    print("  爬虫落点: %s" % crawl_dir)
    print("  配置对齐: %s" % shared_config_path(ws))
    if a.dry_run:
        print("  （--dry-run：只打印，不落盘）")
    print("=" * 68)

    rc = 0

    # ① 技能 → 项目级
    if a.skills:
        print("\n[1/3] 复制技能到工作区（项目级）")
        for name in SKILL_NAMES:
            src = os.path.join(SKILLS_SRC, name)
            if not os.path.isdir(src):
                print("  ⚠ 包内缺少技能: %s" % name)
                rc = 1
                continue
            dst = os.path.join(skills_dst, name)
            added, kept = copy_tree(src, dst, force=a.force, dry_run=a.dry_run)
            print("  %-14s 新增 %d 个文件，保留已存在 %d 个" % (name, added, kept))
        print("  ⚠ 提示：若专家包同时处于启用状态，同名技能会存在两份快照；"
              "改脚本后注意同步，或加 --no-skills 只保留一份。")
    else:
        print("\n[1/3] 跳过技能复制（--no-skills）")

    # ② 爬虫 → 工作区内
    if a.crawler:
        print("\n[2/3] 安装爬虫运行环境到工作区（运行包约 70MB，本机没有时会联网下载）")
        if a.dry_run:
            print("  （dry-run）将执行: %s setup --install-crawler \"%s\""
                  % (CRAWLER_SCRIPT, crawl_dir))
        elif not os.path.isfile(CRAWLER_SCRIPT):
            print("  ⚠ 包内缺少 jrzb.py，无法安装爬虫")
            rc = 1
        else:
            proc = subprocess.run(
                [sys.executable, CRAWLER_SCRIPT, "setup", "--install-crawler", crawl_dir],
                capture_output=True,
            )
            out = (proc.stdout or b"").decode("utf-8", "replace")
            err = (proc.stderr or b"").decode("utf-8", "replace")
            print("  " + (out or err).strip().replace("\n", "\n  "))
            if proc.returncode != 0:
                print("  ⚠ 爬虫安装返回码 %d" % proc.returncode)
                rc = 1
    else:
        print("\n[2/3] 跳过爬虫安装（--no-crawler）")

    # ③ 配置对齐
    print("\n[3/3] 对齐共享配置（work_root / state_root → 工作区内）")
    changed = align_config(ws, crawl_dir, dry_run=a.dry_run)
    if changed:
        for k, v in changed.items():
            print("  %s → %s" % (k, v))
    else:
        print("  无需改动（已指向工作区）")

    print("\n" + "=" * 68)
    print("完成。接下来（在 WorkBuddy 里让专家接着做）：")
    print("  1) 爬虫个性化配置向导：jrzb.py setup   （Chrome 路径/用户数据目录/工作目录等；不问账号密码）")
    print("  2) 投标策略向导：      ztb.py strategy （业务范围/关系单位/一票否决/价格分规则）")
    print("  3) 运行前自检：        jrzb.py setup / ztb.py check-io / ztb.py status")
    print("  4) 定时任务：由 WorkBuddy 平台能力创建（见 README《⏰ 定时任务》一节），")
    print("     本脚本不会也不允许创建定时任务。")
    print("=" * 68)
    return rc


if __name__ == "__main__":
    sys.exit(main())
