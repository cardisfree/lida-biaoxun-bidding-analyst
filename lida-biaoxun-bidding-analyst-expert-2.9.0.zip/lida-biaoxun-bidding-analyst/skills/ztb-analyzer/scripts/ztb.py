#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""招投标项目分析助手（ztb-analyzer）辅助脚本。

配合 SKILL.md 使用：从 buzdata.db 的 ztb_rpa_prjs 表取出「待分析」项目
（pre_add=1 且 summary_json 为空），生成分析素材包，供智能体阅读后按
《投标策略》产出分析结论；最后把结论同时写入数据库 summary_json 字段
与项目目录下的 summary.json，并把该行 pre_add 置为 0。

子命令:
    status                          查看待处理/已完成统计与锁状态
    next [--id N]                   取出一条待处理项目（默认最早一条）并加锁，输出 JSON
    bundle --id N [--out PATH]      生成该项目的分析素材包（正文/附件文本/图片清单）
    save --id N --summary PATH      校验并落库：写 summary_json + 项目目录 summary.json + pre_add=0，释放锁
    push --id N                     判断该条结论是否需要推送（是否参加∈推荐参加/考虑/关注），并输出推送文案
    abort                           释放锁（本次分析放弃/失败时用）
    reset --id N                    把某行 pre_add 重新置 1（需要重新分析时用）
    check-io                        体检关键写入路径（网络映射盘）的可写性与耗时
    resync [--id N] [--all]         把数据库里的结论补写成项目目录 summary.json（写入故障恢复用）
    strategy                        投标策略配置向导：查看/写入/渲染客户自己的《投标策略》
                                    （--template / --set / --add / --set-json / --set-file
                                     / --render / --print / --reset）

写入健康（重要）:
    项目目录（openclaw_file_path）与数据库有可能位于网络映射盘 / UNC 共享上。
    所有关键写入都会 flush+fsync 后读回校验；失败时不会崩溃、不会卡住锁，
    而是输出 alert=true 的结构化 JSON（含 stage/path/error），由智能体推送告警：
      * 数据库写入失败 → 整体判失败，pre_add 保持 1，修复后自动重试；
      * 项目目录 summary.json 失败 → 结论仍落库（按完成处理），记入待补写清单，
        磁盘恢复后运行 `resync` 补写。

配置（优先级：CLI > 环境变量 > 配置文件 > 内置默认）:
    配置文件 ~/.workbuddy/zb-tender.json，常用键：
        work_root     项目根目录（含 buzdata.db 与爬虫程序），默认 ~/jrzb_spider
        state_root    状态根目录（锁/素材包/日志），默认 ~/.workbuddy
        db / state_dir / site_packages / strategy_file   可按需单独覆盖
    环境变量：ZB_CONFIG / ZB_WORK_ROOT / ZB_STATE_ROOT / ZTB_DB / ZTB_STATE / ZTB_STRATEGY
    查看或设置：python ztb.py config [--work-root ...] [--db ...]

《投标策略》说明:
    策略是**客户自己的**业务规则，通过 `strategy` 子命令配置为 JSON
    （默认 <state_dir>/strategy.json），再渲染成 markdown 供研判使用；
    未配置时回退到包内 references/投标策略.txt。

退出码:
    0   成功
    4   已有另一轮分析在进行中（锁被占用）
    1   出错
"""

import argparse
import datetime
import io
import json
import os
import re
import sqlite3
import sys
import time
import zipfile

# ---------------------------------------------------------------- 基础配置
#
# 路径解析优先级：CLI 参数 > 环境变量 > 配置文件 > 内置默认
#
# 配置文件：~/.workbuddy/zb-tender.json（可用环境变量 ZB_CONFIG 指向别处）。
# 迁移到别的机器时，通常只需设置两个键即可推导出全部路径：
#     work_root   项目根目录：内含 buzdata.db 与爬虫程序，默认 ~/jrzb_spider
#     state_root  状态根目录：锁/素材包/日志，默认 ~/.workbuddy
# 需要时也可单独覆盖某一路径：
#     db            直接指定 buzdata.db
#     state_dir     直接指定本技能状态目录（默认 <state_root>/ztb-analyzer）
#     site_packages 额外的 site-packages（如托管 venv，PDF 解析用）
#
# 查看/写入配置：python ztb.py config [--work-root ...] [--state-root ...] ...

HOME_DIR = os.path.expanduser("~")
DEFAULT_WORK_ROOT = os.path.join(HOME_DIR, "jrzb_spider")
DEFAULT_STATE_ROOT = os.path.join(HOME_DIR, ".workbuddy")

# 「工作区」锚定：WorkBuddy 会把当前工作区目录放进下面这些环境变量。
# 目标是把数据库、锁、素材包、策略都落在**工作区**里，而不是用户主目录 ——
# 装到哪台电脑就落在那个工作区，随工作区一起备份。
WORKSPACE_ENVS = ("WORKBUDDY_PROJECT_DIR", "CODEBUDDY_PROJECT_DIR", "CLAUDE_PROJECT_DIR")
WORKSPACE_CRAWLER_SUBDIR = "jrzb_spider"
WORKSPACE_STATE_SUBDIR = ".workbuddy"

LOCK_STALE_SECONDS = 20 * 60      # 锁超过该时长视为失效，可强制接管
MAX_ATTACH_CHARS = 24000          # 单个附件抽取文本上限
MAX_BUNDLE_CHARS = 160000         # 素材包总上限

EXIT_OK = 0
EXIT_LOCKED = 4
EXIT_ERROR = 1
EXIT_STRATEGY_REQUIRED = 5   # 未提供《投标策略》，拒绝发放待处理项目

# 「符合公司要求」的结论取值（落库后需要主动推送给用户）
PUSH_STATES = ("推荐参加", "考虑", "关注（后续参加）", "关注")

# 推送里的「公告摘要」截断长度：原文可能很长，提醒场景只放一小段
PUSH_SNIPPET_CHARS = int(os.environ.get("ZTB_PUSH_SNIPPET") or 160)
# 推送总长度上限（超出则进一步压缩摘要；企业微信 markdown 上限 20480 字节）
PUSH_MAX_CHARS = int(os.environ.get("ZTB_PUSH_MAX") or 1200)

STATE_SUBDIR = "state"
TABLE = "ztb_rpa_prjs"

CONFIG_ENV = "ZB_CONFIG"
_CONFIG_CACHE = None


def config_path():
    """共享配置路径。

    优先级：`ZB_CONFIG` 环境变量 > **工作区内的** `.workbuddy/zb-tender.json`（存在才用）
    > 用户主目录 `~/.workbuddy/zb-tender.json`。
    """
    p = os.environ.get(CONFIG_ENV)
    if p:
        return os.path.abspath(os.path.expanduser(p))
    ws = workspace_dir()
    if ws:
        cand = os.path.join(ws, WORKSPACE_STATE_SUBDIR, "zb-tender.json")
        if os.path.isfile(cand):
            return os.path.abspath(cand)
    return os.path.join(HOME_DIR, ".workbuddy", "zb-tender.json")


def load_config():
    """读取共享配置；文件不存在或损坏时返回空 dict（不报错）。"""
    global _CONFIG_CACHE
    if _CONFIG_CACHE is None:
        try:
            with open(config_path(), "r", encoding="utf-8") as f:
                _CONFIG_CACHE = json.load(f) or {}
        except Exception:
            _CONFIG_CACHE = {}
    return _CONFIG_CACHE


def _cfg(key):
    v = load_config().get(key)
    return v.strip() if isinstance(v, str) and v.strip() else None


def _norm(p):
    return os.path.abspath(os.path.expanduser(p))


def _pick(env_key, cfg_key, default):
    return os.environ.get(env_key) or _cfg(cfg_key) or default


def workspace_dir():
    """当前工作区目录；识别不到返回 None。"""
    for k in WORKSPACE_ENVS:
        v = (os.environ.get(k) or "").strip()
        if v and os.path.isdir(v):
            return _norm(v)
    return None


def package_root():
    """专家包根目录（用于发现包内的工作区自包含安装器 install.py）。"""
    here = os.path.dirname(os.path.abspath(__file__))
    pkg = os.path.dirname(os.path.dirname(os.path.dirname(here)))
    if os.path.isfile(os.path.join(pkg, "install.py")):
        return pkg
    return None


def _default_work_root():
    """默认项目根目录：工作区里已有 jrzb_spider 就优先用它，否则退回 ~/jrzb_spider。"""
    ws = workspace_dir()
    if ws:
        cand = os.path.join(ws, WORKSPACE_CRAWLER_SUBDIR)
        if os.path.isdir(cand):
            return cand
    return DEFAULT_WORK_ROOT


def _default_state_root():
    """默认状态根目录：优先工作区内的 .workbuddy，让锁/素材包/策略不跑出工作区。"""
    ws = workspace_dir()
    if ws:
        return os.path.join(ws, WORKSPACE_STATE_SUBDIR)
    return DEFAULT_STATE_ROOT


def work_root():
    return _norm(_pick("ZB_WORK_ROOT", "work_root", _default_work_root()))


def state_root():
    return _norm(_pick("ZB_STATE_ROOT", "state_root", _default_state_root()))


def db_path():
    explicit = os.environ.get("ZTB_DB") or _cfg("db")
    if explicit:
        return _norm(explicit)
    return _norm(os.path.join(work_root(), "buzdata.db"))


def state_dir():
    explicit = os.environ.get("ZTB_STATE") or _cfg("state_dir")
    d = _norm(explicit) if explicit else _norm(os.path.join(state_root(), "ztb-analyzer"))
    os.makedirs(d, exist_ok=True)
    return d


def extra_site_packages():
    """PDF 解析（PyMuPDF）所在的 site-packages；一般无需手动设置。"""
    v = os.environ.get("ZTB_SITE_PACKAGES") or _cfg("site_packages")
    if v:
        return _norm(v)
    try:
        import site as _site
        for p in _site.getsitepackages():
            if os.path.isdir(p):
                return p
    except Exception:
        pass
    return os.path.join(sys.prefix, "Lib", "site-packages")


def lock_file():
    return os.path.join(state_dir(), "lock.json")


def bundle_file(pid):
    return os.path.join(state_dir(), "bundle_%s.txt" % pid)


def out(s=""):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(s)


def err(s):
    try:
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print(s, file=sys.stderr)


# ---------------------------------------------------------------- 数据库

def connect():
    p = db_path()
    if not os.path.isfile(p):
        err("未找到数据库文件: %s" % p)
        err("请先配置项目路径，例如：")
        err('  python ztb.py config --work-root "<项目根目录>"')
        err('  或：python ztb.py config --db "<buzdata.db 完整路径>"')
        sys.exit(EXIT_ERROR)
    con = sqlite3.connect(p, timeout=30)
    con.row_factory = sqlite3.Row
    return con


def row_to_dict(row):
    return {k: row[k] for k in row.keys()}


def fetch_one(con, sql, args=()):
    cur = con.execute(sql, args)
    r = cur.fetchone()
    return row_to_dict(r) if r else None


def pending_count(con):
    return con.execute(
        "SELECT COUNT(*) FROM %s WHERE pre_add=1 AND (summary_json IS NULL OR summary_json='')" % TABLE
    ).fetchone()[0]


def done_count(con):
    return con.execute(
        "SELECT COUNT(*) FROM %s WHERE summary_json IS NOT NULL AND summary_json<>''" % TABLE
    ).fetchone()[0]


# ---------------------------------------------------------------- 锁

def read_lock():
    lf = lock_file()
    if not os.path.isfile(lf):
        return None
    try:
        with io.open(lf, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return None
    if time.time() - float(data.get("ts", 0)) > LOCK_STALE_SECONDS:
        return None
    return data


def acquire_lock(pid):
    cur = read_lock()
    if cur and str(cur.get("id")) != str(pid):
        return cur
    data = {"id": pid, "pid": os.getpid(), "ts": time.time(),
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
    # 状态目录也可能在网络盘上：写锁失败即无法保证串行，交由调用方告警
    safe_write_text(lock_file(), json.dumps(data, ensure_ascii=False), "写分析锁")
    return None


def release_lock():
    try:
        if os.path.isfile(lock_file()):
            os.remove(lock_file())
    except Exception:
        pass


# ------------------------------------------------------- 写入健康（网络盘容错）
#
# 项目目录（openclaw_file_path）与数据库有可能位于网络映射盘 / UNC 共享上，
# 这类介质会在掉线、休眠、权限变化、盘符未映射时「写入失败」，甚至「写入假成功」
# （数据只在本地缓存里）。因此：
#   * 关键写入统一走 safe_write_text()：写 → flush+fsync → 读回比对；
#   * 失败抛 WriteFailure，由调用方转成结构化告警（并且必须释放锁，避免死锁）；
#   * check-io 子命令主动体检各关键路径的真实可写性（含网络盘识别与耗时）；
#   * resync 子命令在磁盘恢复后，把数据库里的结论补写成项目目录 summary.json。

IO_ALERT_FILE = "io_alert.json"          # 写入故障告警的去重状态
IO_RESYNC_FILE = "pending_resync.json"   # 项目目录 summary.json 待补写的 id 列表
IO_ALERT_COOLDOWN_SECONDS = 30 * 60      # 同一故障 30 分钟内不重复告警
IO_SLOW_MS = 1500                        # 单次写入超过该耗时视为「慢」（网络盘预警）


class WriteFailure(Exception):
    """一次写入失败（或被写后校验判定为不完整）。"""

    def __init__(self, stage, path, error, verify=False):
        self.stage = stage
        self.path = path
        self.error = str(error)
        self.verify = bool(verify)
        super().__init__("%s 失败: %s（%s）" % (stage, self.error, path))

    def as_dict(self):
        return {
            "stage": self.stage, "path": self.path, "error": self.error,
            "kind": "写后校验不一致" if self.verify else "写入失败",
            "drive_kind": _drive_kind(self.path),
            "is_network": _is_network_path(self.path),
        }


_DRIVE_TYPES = {0: "unknown", 1: "missing", 2: "removable", 3: "fixed",
                4: "network", 5: "cdrom", 6: "ramdisk"}


def _drive_kind(path):
    """路径所在盘的类型：fixed / network / removable / missing / unknown。

    `missing` 表示盘符当前不存在 —— 映射盘掉线后最常见的就是这种。
    """
    try:
        p = os.path.abspath(path)
    except Exception:
        p = str(path)
    if p.startswith("\\\\"):
        return "network"            # UNC 共享
    if os.name != "nt":
        return "posix"
    drive = os.path.splitdrive(p)[0]
    if not drive:
        return "unknown"
    try:
        import ctypes
        # GetDriveTypeW: 0未知 1无根目录 2可移动 3固定 4网络 5光驱 6内存盘
        return _DRIVE_TYPES.get(ctypes.windll.kernel32.GetDriveTypeW(drive + "\\"), "unknown")
    except Exception:
        return "unknown"


def _is_network_path(path):
    return _drive_kind(path) == "network"


def _read_json(path):
    try:
        with io.open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def _dump_json(path, data):
    d = os.path.dirname(path) or "."
    if not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
    with io.open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def io_alert_file():
    return os.path.join(state_dir(), IO_ALERT_FILE)


def io_resync_file():
    return os.path.join(state_dir(), IO_RESYNC_FILE)


def safe_write_text(path, text, stage="写文件"):
    """写文本并做写后校验；失败抛 WriteFailure。

    flush + fsync 让数据真正落盘（网络盘上能尽早暴露掉线/无权限），
    再读回比对，避免「写成功但内容不完整 / 未真正同步」的假成功。
    """
    d = os.path.dirname(path) or "."
    try:
        if not os.path.isdir(d):
            os.makedirs(d, exist_ok=True)
        with io.open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass          # 个别网络盘不支持 fsync，不因此判失败
    except Exception as exc:
        raise WriteFailure(stage, path, exc)

    try:
        with io.open(path, "r", encoding="utf-8") as fh:
            back = fh.read()
    except Exception as exc:
        raise WriteFailure(stage, path, exc, verify=True)
    if back != text:
        raise WriteFailure(
            stage, path,
            "写后校验不一致（读回 %d 字符，期望 %d 字符）" % (len(back), len(text)),
            verify=True)
    return path


def probe_writable(path, label, kind="dir", create=False):
    """体检某个目录/文件所在处是否真的可写。

    真实写入临时文件 → flush+fsync → 读回比对 → 删除，并记录耗时。
    """
    parent = path if kind == "dir" else (os.path.dirname(path) or ".")
    info = {"name": label, "path": path, "kind": kind,
            "drive_kind": _drive_kind(path),
            "is_network": _is_network_path(path),
            "parent_exists": os.path.isdir(parent),
            "writable": False, "latency_ms": None, "slow": False, "error": None}
    if not info["parent_exists"] and create:
        try:
            os.makedirs(parent, exist_ok=True)
            info["parent_exists"] = True
        except Exception as exc:
            info["error"] = "目录不存在且无法创建: %s" % exc
            return info
    if not info["parent_exists"]:
        info["error"] = "目录不存在（驱动器可能未连接/未映射）: %s" % parent
        return info

    marker = "ztb-io-probe %s %s" % (time.time(), os.getpid())
    tmp = os.path.join(parent, ".ztb_io_probe_%d.tmp" % os.getpid())
    t0 = time.time()
    try:
        with io.open(tmp, "w", encoding="utf-8") as fh:
            fh.write(marker)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        with io.open(tmp, "r", encoding="utf-8") as fh:
            back = fh.read()
        if back != marker:
            info["error"] = "写后校验不一致（读回 %d 字符）" % len(back)
            return info
        info["writable"] = True
    except Exception as exc:
        info["error"] = "%s: %s" % (type(exc).__name__, exc)
        return info
    finally:
        info["latency_ms"] = int((time.time() - t0) * 1000)
        info["slow"] = bool(info["latency_ms"] and info["latency_ms"] > IO_SLOW_MS)
        try:
            if os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return info


def note_io_alert(signature, detail, cooldown=IO_ALERT_COOLDOWN_SECONDS, dry_run=False):
    """记录写入故障；返回 True 表示「被去重抑制」（同一故障冷却期内已告过警）。"""
    now = time.time()
    prev = _read_json(io_alert_file()) or {}
    suppressed = (prev.get("last_sig") == signature
                  and (now - float(prev.get("last_alert_ts") or 0)) < cooldown)
    if not suppressed and not dry_run:
        try:
            _dump_json(io_alert_file(), {
                "last_alert_ts": now,
                "last_alert_iso": datetime.datetime.now().isoformat(timespec="seconds"),
                "last_sig": signature,
                "last_detail": detail,
            })
        except Exception:
            pass
    return suppressed


def add_pending_resync(pid, detail):
    """把「项目目录 summary.json 需补写」的 id 记入待办（去重）。"""
    data = _read_json(io_resync_file()) or {}
    items = data.get("items") or []
    if not any(str(i.get("id")) == str(pid) for i in items):
        items.append({"id": pid,
                      "at": datetime.datetime.now().isoformat(timespec="seconds"),
                      "detail": detail})
    data["items"] = items
    try:
        _dump_json(io_resync_file(), data)
    except Exception:
        pass
    return items


def clear_pending_resync(pid):
    data = _read_json(io_resync_file()) or {}
    items = [i for i in (data.get("items") or []) if str(i.get("id")) != str(pid)]
    data["items"] = items
    try:
        _dump_json(io_resync_file(), data)
    except Exception:
        pass
    return items


def pending_resync_items():
    return (_read_json(io_resync_file()) or {}).get("items") or []


def emit_write_failure(failure, extra=None):
    """统一的写入故障输出：结构化 JSON（alert=true）+ 告警去重状态。"""
    sig = "%s|%s" % (failure.stage, failure.path)
    suppressed = note_io_alert(sig, failure.error)
    payload = {
        "ok": False, "alert": True, "alert_level": "error",
        "kind": "io_write_failure",
        "stage": failure.stage, "path": failure.path, "error": failure.error,
        "verify_mismatch": failure.verify,
        "is_network": _is_network_path(failure.path),
        "suppressed": suppressed,
        "hint": ("写入失败（常见原因：网络映射盘掉线/未映射、无写权限、磁盘已满、"
                 "文件被占用）。请检查该路径所在磁盘/共享后重试。"),
    }
    if extra:
        payload.update(extra)
    out(json.dumps(payload, ensure_ascii=False, indent=2))
    return EXIT_ERROR


# ---------------------------------------------------------------- 目录扫描

def scan_project(pdir):
    """扫描项目目录，返回文件清单。"""
    info = {"exists": os.path.isdir(pdir), "announcements": None,
            "markdown": [], "basic_info": [], "attachments": [], "images": [],
            "attachments_meta": []}

    def j(*a):
        return os.path.join(pdir, *a)

    if not info["exists"]:
        return info

    p = j("announcements.json")
    if os.path.isfile(p):
        info["announcements"] = p

    for name, key in (("markdown", "markdown"), ("basic_info", "basic_info")):
        d = j(name)
        if os.path.isdir(d):
            info[key] = sorted(os.path.join(d, f) for f in os.listdir(d))

    d = j("attachments")
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if not os.path.isfile(p):
                continue
            if f.endswith("_attachments.json"):
                info["attachments_meta"].append(p)
            else:
                info["attachments"].append(p)

    d = j("images")
    if os.path.isdir(d):
        info["images"] = sorted(os.path.join(d, f) for f in os.listdir(d)
                                if os.path.isfile(os.path.join(d, f)))
    return info


# ---------------------------------------------------------------- 截止时间判定

def _parse_dt(s):
    """把各种写法的日期时间解析为 datetime，失败返回 None。"""
    if s is None:
        return None
    t = str(s).strip()
    if not t or t.startswith("0001"):
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S",
                "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S",
                "%Y/%m/%d %H:%M", "%Y/%m/%d", "%Y.%m.%d", "%Y年%m月%d日"):
        try:
            return datetime.datetime.strptime(t, fmt)
        except ValueError:
            pass
    m = re.search(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[T ](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?", t)
    if m:
        try:
            return datetime.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                                     int(m.group(4) or 0), int(m.group(5) or 0),
                                     int(m.group(6) or 0))
        except ValueError:
            return None
    return None


def deadline_info(row, now=None):
    """按**可得的最晚截止时间**判断项目是否已过期。

    优先「投标截止时间」(tbjzsj)，为空则退回「报名截止时间」(bmjzsj)；
    两者都拿不到时 expired=None（无法判定 → 正常分析）。
    返回 dict: expired / basis / field / raw / deadline / days_left
    """
    now = now or datetime.datetime.now()
    for field, label in (("tbjzsj", "投标截止时间"), ("bmjzsj", "报名截止时间")):
        dt = _parse_dt(row.get(field))
        if dt is not None:
            return {
                "expired": dt < now,
                "basis": label,
                "field": field,
                "raw": str(row.get(field)).strip(),
                "deadline": dt.strftime("%Y-%m-%d %H:%M"),
                "days_left": round((dt - now).total_seconds() / 86400.0, 1),
            }
    return {"expired": None, "basis": None, "field": None, "raw": None,
            "deadline": None, "days_left": None}


# ---------------------------------------------------------------- 附件文本抽取

def _strip_xml(xml_text):
    xml_text = re.sub(r"<w:tab[^>]*/>", "\t", xml_text)
    xml_text = re.sub(r"<w:br[^>]*/>", "\n", xml_text)
    xml_text = re.sub(r"</w:p>", "\n", xml_text)
    xml_text = re.sub(r"</a:p>", "\n", xml_text)
    xml_text = re.sub(r"<[^>]+>", "", xml_text)
    xml_text = (xml_text.replace("&amp;", "&").replace("&lt;", "<")
                .replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'"))
    return xml_text


def extract_docx(path):
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n in ("word/document.xml",)
                 or re.match(r"word/(header|footer)\d*\.xml$", n)]
        text = []
        for n in sorted(names):
            if n != "word/document.xml":
                continue
            text.append(_strip_xml(z.read(n).decode("utf-8", "ignore")))
    return "\n".join(text)


def extract_xlsx(path):
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            sx = z.read("xl/sharedStrings.xml").decode("utf-8", "ignore")
            for si in re.findall(r"<si>(.*?)</si>", sx, re.S):
                shared.append(re.sub(r"<[^>]+>", "", si).replace("&amp;", "&"))
        lines = []
        sheets = sorted(n for n in z.namelist()
                        if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
        for n in sheets:
            sx = z.read(n).decode("utf-8", "ignore")
            lines.append("---- %s ----" % n)
            for rowm in re.finditer(r"<row[^>]*>(.*?)</row>", sx, re.S):
                cells = []
                for c in re.finditer(r"<c([^>]*)>(.*?)</c>", rowm.group(1), re.S):
                    attrs, body = c.group(1), c.group(2)
                    vm = re.search(r'<v>(.*?)</v>', body, re.S)
                    val = vm.group(1) if vm else ""
                    if 't="s"' in attrs and val.isdigit():
                        idx = int(val)
                        val = shared[idx] if idx < len(shared) else val
                    else:
                        val = re.sub(r"<[^>]+>", "", val)
                    cells.append(val)
                if any(cells):
                    lines.append("\t".join(cells))
        return "\n".join(lines)


def extract_pdf(path):
    try:
        import pymupdf  # noqa
    except Exception:
        extra = extra_site_packages()
        if extra and os.path.isdir(extra) and extra not in sys.path:
            sys.path.insert(0, extra)
        try:
            import pymupdf
        except Exception:
            return None
    parts = []
    doc = pymupdf.open(path)
    try:
        for i, page in enumerate(doc):
            parts.append("---- 第%d页 ----" % (i + 1))
            parts.append(page.get_text("text"))
    finally:
        doc.close()
    return "\n".join(parts)


def extract_doc(path):
    """旧版 .doc 二进制：尽力而为地抽出可见文本（低置信度）。"""
    raw = open(path, "rb").read()
    try:
        txt = raw.decode("utf-16-le", "ignore")
    except Exception:
        txt = raw.decode("gbk", "ignore")
    chunks = re.findall(r"[\u4e00-\u9fff\uff00-\uffef0-9A-Za-z，。、；：（）()\-%．.,:;/\\s]{6,}", txt)
    chunks = [c.strip() for c in chunks if len(c.strip()) >= 6]
    return "\n".join(chunks)


def extract_text(path):
    """返回 (文本, 说明)。文本为 None 表示无法抽取。"""
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".docx":
            return extract_docx(path), "docx"
        if ext == ".xlsx":
            return extract_xlsx(path), "xlsx"
        if ext == ".pdf":
            t = extract_pdf(path)
            if t is None:
                return None, "pdf(缺少 PyMuPDF)"
            if len(t.strip()) < 40:
                return t, "pdf(文本极少，疑为扫描件，请改用 Read 工具读图)"
            return t, "pdf"
        if ext == ".doc":
            return extract_doc(path), "doc(二进制，低置信度)"
        if ext in (".txt", ".md", ".json", ".csv", ".htm", ".html"):
            return io.open(path, "r", encoding="utf-8", errors="ignore").read(), ext.lstrip(".")
    except Exception as exc:  # noqa
        return None, "抽取失败: %s" % exc
    return None, "不支持的格式 %s" % ext


# ---------------------------------------------------------------- 命令实现

def cmd_status(argv):
    con = connect()
    try:
        st = {"db": db_path(), "pending": pending_count(con), "done": done_count(con),
              "total": con.execute("SELECT COUNT(*) FROM %s" % TABLE).fetchone()[0]}
    finally:
        con.close()
    lk = read_lock()
    st["locked"] = lk
    st["strategy"] = strategy_summary()
    st["strategy_gate"] = strategy_gate()
    try:
        dbp = db_path()
        try:
            sd = state_dir()
        except Exception:
            sd = os.path.join(state_root(), "ztb-analyzer")
        st["io"] = {
            "work_root": work_root(), "work_root_drive": _drive_kind(work_root()),
            "db": dbp, "db_exists": os.path.isfile(dbp), "db_drive": _drive_kind(dbp),
            "state_dir": sd, "state_dir_drive": _drive_kind(sd),
            "has_network_path": any(_is_network_path(p) for p in (work_root(), dbp, sd)),
            "pending_resync": len(pending_resync_items()),
            "last_io_alert": (_read_json(io_alert_file()) or {}).get("last_alert_iso"),
            "hint": "运行 python ztb.py check-io 体检写入路径（网络映射盘）是否可用",
        }
    except Exception as exc:
        st["io"] = {"error": str(exc)}
    out(json.dumps(st, ensure_ascii=False, indent=2))
    return EXIT_OK


def cmd_next(argv):
    # 策略闸门：未提供《投标策略》时拒绝发放项目（避免用包内占位模板跑出无效结论）
    gate = strategy_gate(force=getattr(argv, "ignore_strategy", False))
    if gate["blocked"] and not getattr(argv, "ignore_strategy", False):
        out(json.dumps({
            "ok": False, "error": "strategy_required",
            "message": "未提供《投标策略》，已阻止分析执行。",
            "gate": gate,
            "escaping": "确需强行放行（应急/调试）可加 --ignore-strategy",
        }, ensure_ascii=False, indent=2))
        return EXIT_STRATEGY_REQUIRED
    con = connect()
    try:
        if argv.id:
            row = fetch_one(con, "SELECT * FROM %s WHERE ztb_rpa_prjs_id=?" % TABLE, (argv.id,))
        else:
            row = fetch_one(
                con,
                "SELECT * FROM %s WHERE pre_add=1 AND (summary_json IS NULL OR summary_json='') "
                "ORDER BY ztb_rpa_prjs_id ASC LIMIT 1" % TABLE,
            )
        if not row:
            out(json.dumps({"ok": True, "pending": 0, "message": "没有待处理的项目"},
                           ensure_ascii=False))
            return EXIT_OK

        # 只要存在未失效的锁，就说明已有另一轮分析在进行中 —— 一律跳过。
        # 注意：不能只比较「锁里的 id 是否等于当前待处理 id」，因为正在分析的项目
        # 此时仍是 pre_add=1（最早待处理），两者恒等，会导致同一项目被每分钟重复分析。
        cur = read_lock()
        if cur:
            out(json.dumps({"ok": False, "locked_by": cur,
                            "message": "已有另一轮分析在进行中（项目 %s，开始于 %s），本轮跳过"
                                       % (cur.get("id"), cur.get("started_at"))},
                           ensure_ascii=False, indent=2))
            return EXIT_LOCKED

        pid = row["ztb_rpa_prjs_id"]
        try:
            acquire_lock(pid)
        except WriteFailure as exc:
            return emit_write_failure(exc, {
                "id": pid, "what": "分析锁",
                "note": "状态目录不可写，无法保证串行，本轮已放弃（未加锁）。"})
        pdir = row.get("openclaw_file_path") or ""
        files = scan_project(pdir)
        payload = {
            "ok": True,
            "pending": pending_count(con),
            "id": pid,
            "name": row.get("xmmc"),
            "dir": pdir,
            "dir_exists": files["exists"],
            "belong_type": row.get("belong_type"),
            "ztb_type": row.get("ztb_type"),
            "aera_name": row.get("aera_name"),
            "zbys": row.get("zbys"),
            "press_date": row.get("press_date"),
            "make_date": row.get("make_date"),
            "bmjzsj": row.get("bmjzsj"),
            "tbjzsj": row.get("tbjzsj"),
            "deadline": deadline_info(row),
            "strategy": strategy_summary(),
            "files": {
                "announcements": files["announcements"],
                "markdown": files["markdown"],
                "basic_info": files["basic_info"],
                "attachments": files["attachments"],
                "attachments_meta": files["attachments_meta"],
                "images": files["images"],
            },
        }
        out(json.dumps(payload, ensure_ascii=False, indent=2))
        return EXIT_OK
    finally:
        con.close()


def cmd_bundle(argv):
    con = connect()
    try:
        row = fetch_one(con, "SELECT * FROM %s WHERE ztb_rpa_prjs_id=?" % TABLE, (argv.id,))
        if not row:
            err("未找到 id=%s 的记录" % argv.id)
            return EXIT_ERROR
        pdir = row.get("openclaw_file_path") or ""
        files = scan_project(pdir)

        buf = []
        buf.append("# 项目分析素材包")
        buf.append("")
        buf.append("- 项目主键ID: %s" % row["ztb_rpa_prjs_id"])
        buf.append("- 项目名称: %s" % row.get("xmmc"))
        buf.append("- 项目目录: %s" % pdir)
        buf.append("- 采集时间: %s" % row.get("make_date"))
        fields = (("项目编号", "batch_id"), ("招标类型", "ztb_type"),
                  ("地区", "aera_name"), ("招标预算", "zbys"),
                  ("业主单位", "yzdh"), ("联系方式", "dldh"),
                  ("报名截止时间", "bmjzsj"), ("投标截止时间", "tbjzsj"),
                  ("在线地址", "source_link"))
        for label, key in fields:
            val = row.get(key)
            if val:
                buf.append("- %s: %s" % (label, val))
        bt = (row.get("belong_type") or "").strip()
        if bt:
            buf.append("- 订阅板块/标签: %s" % bt.replace("\n", " / "))
        pd = row.get("press_date") or ""
        if pd and not pd.startswith("0001"):
            buf.append("- 发布时间: %s" % pd)
        if row.get("download_error"):
            buf.append("- 附件下载异常: %s" % row.get("download_error"))
        dl = deadline_info(row)
        if dl["expired"] is True:
            buf.append("- ⚠️ 截止时间: **已过期**（%s %s，依据字段 %s）"
                       % (dl["basis"], dl["deadline"], dl["field"]))
        elif dl["expired"] is False:
            buf.append("- 截止时间: %s %s（未过期，剩余约 %s 天）"
                       % (dl["basis"], dl["deadline"], dl["days_left"]))
        else:
            buf.append("- 截止时间: 未采集到（报名/投标截止均为空，无法判定）")
        buf.append("- 采集记录(announcements.json): %s" % (files["announcements"] or "无"))
        buf.append("")

        # ── 已过期 → 产出精简素材包：不做附件抽取、不列图片 OCR，直接判「不参加」
        if dl["expired"] is True:
            buf.append("")
            buf.append("=" * 70)
            buf.append("## ⚠️ 本项目截止时间已过 —— 按规则放弃深度分析")
            buf.append("-" * 70)
            buf.append("判定依据: %s = %s" % (dl["basis"], dl["raw"]))
            buf.append("截止时间: %s（已过去约 %s 天）" % (dl["deadline"], abs(dl["days_left"])))
            buf.append("")
            buf.append("请**直接**产出结论，不要读附件、不要做图片 OCR：")
            buf.append("- 是否参加 = 不参加")
            buf.append("- 否决规则 = [\"截止时间已过：%s %s\"]" % (dl["basis"], dl["deadline"]))
            buf.append("- 投标策略 = 放弃投标")
            text = "\n".join(buf)
            bp = argv.out or bundle_file(row["ztb_rpa_prjs_id"])
            try:
                safe_write_text(bp, text, "写素材包")
            except WriteFailure as exc:
                return emit_write_failure(exc, {"id": row["ztb_rpa_prjs_id"], "what": "素材包"})
            out(json.dumps({
                "ok": True, "id": row["ztb_rpa_prjs_id"], "bundle": bp,
                "chars": len(text), "expired": True, "slim": True,
                "deadline": dl, "images_to_ocr": [], "attachments": [],
            }, ensure_ascii=False, indent=2))
            return EXIT_OK

        def add_file(title, path, cap=MAX_ATTACH_CHARS):
            buf.append("")
            buf.append("=" * 70)
            buf.append("## %s" % title)
            buf.append("路径: %s" % path)
            buf.append("-" * 70)
            t, note = extract_text(path)
            if t is None:
                buf.append("[无法自动抽取文本] %s" % note)
            else:
                t = t.strip()
                if len(t) > cap:
                    t = t[:cap] + "\n...[已截断]..."
                buf.append(t if t else "[内容为空]")
                buf.append("[抽取方式: %s]" % note)

        for p in files["markdown"]:
            add_file("markdown: " + os.path.basename(p), p)
        for p in files["basic_info"]:
            add_file("basic_info: " + os.path.basename(p), p)
        if files["announcements"]:
            add_file("announcements.json", files["announcements"])
        if not files["markdown"] and row.get("source_html"):
            buf.append("")
            buf.append("=" * 70)
            buf.append("## 公告正文（数据库 source_html 兜底）")
            buf.append("-" * 70)
            buf.append(str(row["source_html"])[:MAX_ATTACH_CHARS])
        for p in files["attachments"]:
            add_file("附件: " + os.path.basename(p), p)

        if files["images"]:
            buf.append("")
            buf.append("=" * 70)
            buf.append("## 需要 OCR 的图片清单")
            buf.append("以下图片需用 Read 工具逐一识图，提取其中的文字内容：")
            for p in files["images"]:
                buf.append("  - %s" % p)
        else:
            buf.append("")
            buf.append("## 图片：无")

        if files["attachments_meta"]:
            buf.append("")
            buf.append("=" * 70)
            buf.append("## 附件下载状态（_attachments.json）")
            for p in files["attachments_meta"]:
                try:
                    meta = json.load(io.open(p, "r", encoding="utf-8"))
                    for m in meta:
                        buf.append("  - %s | status=%s | %s" % (
                            m.get("name"), m.get("status"), m.get("message", "")))
                except Exception as exc:
                    buf.append("  - [解析失败] %s: %s" % (p, exc))

        text = "\n".join(buf)
        if len(text) > MAX_BUNDLE_CHARS:
            text = text[:MAX_BUNDLE_CHARS] + "\n...[素材包已截断]..."
        bp = argv.out or bundle_file(row["ztb_rpa_prjs_id"])
        try:
            safe_write_text(bp, text, "写素材包")
        except WriteFailure as exc:
            return emit_write_failure(exc, {"id": row["ztb_rpa_prjs_id"], "what": "素材包"})
        out(json.dumps({
            "ok": True, "id": row["ztb_rpa_prjs_id"], "bundle": bp,
            "chars": len(text),
            "expired": dl["expired"],
            "deadline": dl,
            "images_to_ocr": files["images"],
            "attachments": files["attachments"],
        }, ensure_ascii=False, indent=2))
        return EXIT_OK
    finally:
        con.close()


def cmd_save(argv):
    if not os.path.isfile(argv.summary):
        err("找不到 summary 文件: %s" % argv.summary)
        return EXIT_ERROR
    raw = io.open(argv.summary, "r", encoding="utf-8").read()
    try:
        obj = json.loads(raw)
    except Exception as exc:
        err("JSON 校验失败: %s" % exc)
        return EXIT_ERROR
    if not isinstance(obj, dict):
        err("summary 必须是 JSON 对象")
        return EXIT_ERROR

    con = connect()
    try:
        row = fetch_one(con, "SELECT * FROM %s WHERE ztb_rpa_prjs_id=?" % TABLE, (argv.id,))
        if not row:
            err("未找到 id=%s 的记录" % argv.id)
            return EXIT_ERROR
        pdir = row.get("openclaw_file_path") or ""
        compact = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))

        # ── 1) 项目目录 summary.json（很可能就在网络映射盘上）
        #    失败**不阻断落库**（数据库才是权威），但记入待补写清单并告警。
        written = None
        failures = []
        if pdir and os.path.isdir(pdir):
            written = os.path.join(pdir, "summary.json")
            try:
                safe_write_text(written, json.dumps(obj, ensure_ascii=False, indent=2),
                                "写项目目录 summary.json")
            except WriteFailure as exc:
                failures.append(exc)
                add_pending_resync(argv.id, exc.error)
        elif pdir:
            exc = WriteFailure("写项目目录 summary.json", pdir,
                               "项目目录不存在（驱动器可能未连接/未映射，或路径已变更）")
            failures.append(exc)
            add_pending_resync(argv.id, exc.error)

        # ── 2) 写数据库：结果以数据库为准，这一步失败则整体判失败
        #    （保持 pre_add=1 以便重试，并**必须释放锁**，否则会死锁 20 分钟）
        try:
            con.execute(
                "UPDATE %s SET summary_json=?, pre_add=0 WHERE ztb_rpa_prjs_id=?" % TABLE,
                (compact, argv.id),
            )
            con.commit()
        except Exception as exc:
            release_lock()
            return emit_write_failure(
                WriteFailure("写数据库 summary_json", db_path(), exc),
                {"id": argv.id, "what": "数据库", "pre_add": 1,
                 "note": "结论未落库，已释放锁；本条仍为待处理，修复后会自动重试。"})

        release_lock()
        if written and not failures:
            clear_pending_resync(argv.id)

        # ── 3) 项目目录写入失败：已落库即视为完成，但必须告警 + 记待补写
        if failures:
            f = failures[0]
            suppressed = note_io_alert("%s|%s" % (f.stage, f.path), f.error)
            out(json.dumps({
                "ok": True, "id": argv.id, "partial": True,
                "alert": True, "alert_level": "error", "kind": "io_write_failure",
                "db_field": "summary_json 已写入（数据库为准）",
                "project_file": written or "(项目目录不存在)",
                "project_file_written": False,
                "failures": [x.as_dict() for x in failures],
                "suppressed": suppressed,
                "pending_resync": [i.get("id") for i in pending_resync_items()],
                "pre_add": 0,
                "summary_keys": sorted(obj.keys()),
                "hint": ("结论已落库（本条按已完成处理），但项目目录 summary.json 写入失败；"
                         "请检查该磁盘/共享/权限，恢复后运行 `python ztb.py resync` 补写。"),
            }, ensure_ascii=False, indent=2))
            return EXIT_OK

        out(json.dumps({
            "ok": True, "id": argv.id,
            "db_field": "summary_json 已写入",
            "project_file": written or "(项目目录不存在，仅写库)",
            "project_file_written": bool(written),
            "pre_add": 0,
            "summary_keys": sorted(obj.keys()),
        }, ensure_ascii=False, indent=2))
        return EXIT_OK
    finally:
        con.close()


def cmd_check_io(argv):
    """体检关键写入路径：真实可写性 + 网络盘识别 + 耗时。"""
    probes = [
        probe_writable(state_dir(), "状态目录（锁/素材包/策略）", "dir", create=True),
        probe_writable(work_root(), "项目根目录（爬虫与数据库所在）", "dir", create=False),
        probe_writable(db_path(), "数据库文件 buzdata.db", "file", create=False),
    ]

    # 样本项目目录：真正写 summary.json 的位置（多为映射盘）
    dbp = db_path()
    if os.path.isfile(dbp):
        try:
            con = connect()
            try:
                row = fetch_one(con, "SELECT openclaw_file_path FROM %s WHERE pre_add=1 "
                                     "ORDER BY ztb_rpa_prjs_id ASC LIMIT 1" % TABLE)
            finally:
                con.close()
            if row and (row.get("openclaw_file_path") or "").strip():
                probes.append(probe_writable(row["openclaw_file_path"],
                                             "样本项目目录（写 summary.json 处）", "dir"))
        except SystemExit:
            pass
        except Exception as exc:
            probes.append({"name": "样本项目目录（写 summary.json 处）", "path": dbp,
                           "kind": "dir", "drive_kind": _drive_kind(dbp),
                           "is_network": _is_network_path(dbp), "parent_exists": True,
                           "writable": False, "latency_ms": None, "slow": False,
                           "error": "读取数据库失败: %s" % exc})

    bad = [p for p in probes if not p["writable"]]
    slow = [p for p in probes if p["writable"] and p.get("slow")]
    net = [p for p in probes if p.get("is_network")]
    payload = {
        "ok": not bad,
        "alert": bool(bad),
        "alert_level": "error" if bad else ("warning" if slow else "none"),
        "kind": "io_probe",
        "checked_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "paths": probes,
        "unwritable": [p["name"] for p in bad],
        "slow_paths": [p["name"] for p in slow],
        "network_paths": [p["name"] for p in net],
    }
    if bad:
        payload["suppressed"] = note_io_alert(
            "check-io|" + ",".join(sorted(p["name"] for p in bad)),
            "; ".join("%s: %s" % (p["path"], p["error"]) for p in bad))
        payload["hint"] = ("检测到写入不可用：多为网络映射盘掉线/未映射、无写权限或磁盘已满。"
                           "请恢复后重试；期间分析结论可能无法写回项目目录。")
    elif slow:
        payload["hint"] = "路径可写，但写入耗时偏高，疑似网络盘不稳定，建议留意。"
    elif net:
        payload["hint"] = "路径可写（存在网络盘，写入耗时正常）。"
    else:
        payload["hint"] = "全部关键路径本地可写。"
    out(json.dumps(payload, ensure_ascii=False, indent=2))
    return EXIT_OK if not bad else EXIT_ERROR


def cmd_resync(argv):
    """把数据库里的结论补写成项目目录 summary.json（网络盘恢复后修复用）。"""
    if argv.id:
        targets = [argv.id]
    elif argv.all:
        targets = None
    else:
        targets = [i.get("id") for i in pending_resync_items()]
        if not targets:
            out(json.dumps({"ok": True, "resynced": [], "failed": [], "checked": 0,
                            "message": "没有待补写的项目（pending_resync 为空）"},
                           ensure_ascii=False, indent=2))
            return EXIT_OK

    con = connect()
    resolved, failed = [], []
    try:
        if targets is None:
            cur = con.execute("SELECT ztb_rpa_prjs_id FROM %s WHERE summary_json IS NOT NULL "
                              "AND summary_json<>'' ORDER BY ztb_rpa_prjs_id" % TABLE)
            targets = [r[0] for r in cur.fetchall()]
        for pid in targets:
            row = fetch_one(con, "SELECT * FROM %s WHERE ztb_rpa_prjs_id=?" % TABLE, (pid,))
            if not row:
                failed.append({"id": pid, "error": "记录不存在"})
                continue
            raw = (row.get("summary_json") or "").strip()
            if not raw:
                failed.append({"id": pid, "error": "summary_json 为空，无法补写"})
                continue
            try:
                obj = json.loads(raw)
            except Exception as exc:
                failed.append({"id": pid, "error": "summary_json 解析失败: %s" % exc})
                continue
            pdir = row.get("openclaw_file_path") or ""
            if not os.path.isdir(pdir):
                failed.append({"id": pid, "path": pdir,
                               "error": "项目目录不存在（磁盘仍未连接？）"})
                continue
            fp = os.path.join(pdir, "summary.json")
            try:
                safe_write_text(fp, json.dumps(obj, ensure_ascii=False, indent=2),
                                "补写 summary.json")
                resolved.append(pid)
                clear_pending_resync(pid)
            except WriteFailure as exc:
                failed.append({"id": pid, "path": fp, "error": exc.error})
    finally:
        con.close()

    payload = {"ok": not failed, "checked": len(targets),
               "resynced": resolved, "failed": failed}
    if failed:
        payload.update({
            "alert": True, "alert_level": "error", "kind": "io_write_failure",
            "suppressed": note_io_alert("resync", str(failed[0].get("error"))),
            "remaining": [i.get("id") for i in pending_resync_items()],
            "hint": "仍有项目目录写入失败，请检查磁盘/共享连接与权限后重试。",
        })
    out(json.dumps(payload, ensure_ascii=False, indent=2))
    return EXIT_OK if not failed else EXIT_ERROR


def _fmt_time(s):
    """把 2026-10-14T09:00:00 规整为 2026-10-14 09:00（无时间则只留日期）。"""
    s = (s or "").strip()
    if not s or s.startswith("0001"):
        return ""
    s = s.replace("T", " ")
    m = re.match(r"(\d{4}-\d{2}-\d{2})(?:[ ](\d{2}:\d{2}))?", s)
    if m:
        return m.group(1) + ((" " + m.group(2)) if m.group(2) else "")
    return s


def _clean_link(u):
    """取在线公告地址；去掉站点附加的 key=标签过滤参数（含中文/逗号噪声）。"""
    u = (u or "").strip()
    if not u.startswith("http"):
        return ""
    if "?" in u:
        base, q = u.split("?", 1)
        if q.startswith("key=") or "," in q:
            return base
    return u


def _clean_body_text(text):
    """把公告正文压成纯文本：去图片/链接/HTML/表格线/markdown 标记，折叠空白。"""
    if not text:
        return ""
    t = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", text)      # 图片
    t = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", t)       # 链接保留文字
    t = re.sub(r"<[^>]+>", " ", t)                       # HTML 标签
    kept = []
    for ln in t.splitlines():
        s = ln.strip()
        if not s:
            continue
        if set(s) <= set("-|:— "):                       # 表格分隔行
            continue
        s = re.sub(r"^[#>\-\*\s]+", "", s).strip()       # 行首 markdown 标记
        if s:
            kept.append(s)
    return re.sub(r"\s+", " ", " ".join(kept)).strip()


def announcement_body(row):
    """读取项目原始公告正文（优先 announcements.json 的 markdown，其次 markdown/*.md 的「公告正文」段）。"""
    pdir = row.get("openclaw_file_path") or ""
    body = ""
    ann = os.path.join(pdir, "announcements.json")
    if os.path.isfile(ann):
        try:
            data = json.load(io.open(ann, "r", encoding="utf-8"))
            body = data.get("markdown") or ""
        except Exception:
            body = ""
    if not _clean_body_text(body):
        mdd = os.path.join(pdir, "markdown")
        if os.path.isdir(mdd):
            for f in sorted(os.listdir(mdd)):
                if not f.lower().endswith(".md"):
                    continue
                try:
                    raw = io.open(os.path.join(mdd, f), "r", encoding="utf-8", errors="ignore").read()
                except Exception:
                    continue
                m = re.search(r"##\s*公告正文\s*(.*?)(?:\n##\s|\Z)", raw, re.S)
                cand = m.group(1) if m else raw
                if _clean_body_text(cand):
                    body = cand
                    break
    return _clean_body_text(body)


def cmd_push(argv):
    """判断某条分析结论是否需要推送给用户，并生成推送文案。

    推送条件：summary 的「是否参加」属于「推荐参加 / 考虑 / 关注（后续参加）」。
    本命令只做判断与文案生成，实际发送由调用方通过推送通道（如企业微信）完成。
    """
    con = connect()
    try:
        row = fetch_one(con, "SELECT * FROM %s WHERE ztb_rpa_prjs_id=?" % TABLE, (argv.id,))
        if not row:
            err("未找到 id=%s 的记录" % argv.id)
            return EXIT_ERROR

        raw = (row.get("summary_json") or "").strip()
        if not raw:
            pdir = row.get("openclaw_file_path") or ""
            p = os.path.join(pdir, "summary.json")
            if os.path.isfile(p):
                raw = io.open(p, "r", encoding="utf-8").read().strip()
        if not raw:
            out(json.dumps({"ok": False, "id": argv.id, "qualify": False,
                            "reason": "尚未生成分析结论（summary_json 为空）"},
                           ensure_ascii=False, indent=2))
            return EXIT_OK

        try:
            obj = json.loads(raw)
        except Exception as exc:
            err("summary_json 解析失败: %s" % exc)
            return EXIT_ERROR

        state = str(obj.get("是否参加", "")).strip()
        qualify = any(state == s or state.startswith(s) for s in PUSH_STATES)

        def val(k):
            v = obj.get(k)
            s = "" if v is None else str(v).strip()
            return "" if s in ("", "未公开", "None") else s

        def base_lines():
            ls = ["【招投标提醒】%s" % (state or "分析完成")]
            if val("项目名称"):
                ls.append("项目：%s" % val("项目名称"))
            pair = []
            if val("地区"):
                pair.append("地区：%s" % val("地区"))
            if val("招标预算"):
                pair.append("预算：%s" % val("招标预算"))
            if pair:
                ls.append(" | ".join(pair))
            meta = []
            pno = (row.get("batch_id") or "").strip()
            if pno:
                meta.append("项目编号：%s" % pno)
            yz = (row.get("yzdh") or "").strip() or val("招采单位")
            if yz:
                meta.append("招采单位：%s" % yz[:40])
            if meta:
                ls.append(" | ".join(meta))
            ls.append("结论：%s" % (state or "未判定"))
            if val("理由"):
                ls.append("理由：%s" % val("理由"))
            bm = _fmt_time(row.get("bmjzsj"))
            if bm:
                ls.append("报名截止：%s" % bm)
            if val("投标截止时间"):
                ls.append("投标截止：%s" % val("投标截止时间"))
            return ls

        lines = base_lines()

        # 原始公告信息：自动截断成「公告摘要」，并附在线公告链接（用 --no-source 可关闭）
        if not getattr(argv, "no_source", False):
            link = _clean_link(row.get("source_link"))
            src = announcement_body(row) or _clean_body_text(row.get("source_html") or "")
            tail = []
            if link:
                tail.append("在线公告：%s" % link)
            if val("项目主键ID"):
                tail.append("ID：%s" % val("项目主键ID"))

            if src:
                # 用剩余额度决定摘要长度，保证整条消息不超过上限
                budget = PUSH_MAX_CHARS - len("\n".join(lines)) - len("\n".join(tail)) - 8
                cap = max(40, min(PUSH_SNIPPET_CHARS, budget))
                snip = src if len(src) <= cap else src[:cap].rstrip() + "…"
                lines.append("公告摘要：%s" % snip)
            else:
                # 正文为图片/未采集到文字时，回退用分析时人工补充的「公告摘要」（通常来自 OCR）
                manual = str(obj.get("公告摘要") or "").strip()
                if manual in ("", "未公开", "None"):
                    lines.append("公告摘要：（正文为图片/未采集到文字，详见在线公告）")
                else:
                    budget = PUSH_MAX_CHARS - len("\n".join(lines)) - len("\n".join(tail)) - 8
                    cap = max(40, min(PUSH_SNIPPET_CHARS, budget))
                    snip = manual if len(manual) <= cap else manual[:cap].rstrip() + "…"
                    lines.append("公告摘要：%s" % snip)
            lines.extend(tail)
        else:
            if val("项目主键ID"):
                lines.append("ID：%s" % val("项目主键ID"))

        result = {
            "ok": True,
            "id": argv.id,
            "qualify": qualify,
            "state": state,
            "action": "推送" if qualify else "跳过（不参加，不打扰）",
            "chars": len("\n".join(lines)),
            "message": "\n".join(lines),
        }
        # --send：达标即直接发到推送群（未配置群 / 群不可达时不算失败，只标记 not_sent）
        if qualify and getattr(argv, "send", False):
            result["send"] = wecom_send(result["message"], group=getattr(argv, "group", None))
        elif not qualify:
            result["send"] = {"ok": True, "sent": False, "skip": "not_qualify",
                              "detail": "结论为「%s」，按规则不推送" % (state or "未判定")}
        out(json.dumps(result, ensure_ascii=False, indent=2))
        return EXIT_OK
    finally:
        con.close()


def cmd_notify(argv):
    """把一段 markdown 直接发到推送群（进度简报 / 故障告警 / 临时通知）。

    非必填、非阻塞：未配置推送群或群不可达时只返回 not_sent，不影响分析流程。
    """
    text = (getattr(argv, "text", None) or "").strip()
    tf = getattr(argv, "text_file", None)
    if not text and tf:
        try:
            text = io.open(tf, "r", encoding="utf-8").read().strip()
        except OSError as exc:
            err("读取 --text-file 失败: %s" % exc)
            return EXIT_ERROR
    if not text:
        err("--text 与 --text-file 至少给一个")
        return EXIT_ERROR
    r = wecom_send(text, group=getattr(argv, "group", None),
                   dry_run=getattr(argv, "dry_run", False))
    if getattr(argv, "json", False):
        out(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        if r["ok"]:
            out("已发送到推送群：%s" % r["group"])
        else:
            out("未发送（%s）：%s" % (r["error"], r["detail"]))
    return EXIT_OK if r["ok"] else EXIT_ERROR


def cmd_abort(argv):
    lk = read_lock()
    release_lock()
    out(json.dumps({"ok": True, "released": lk}, ensure_ascii=False))
    return EXIT_OK


def cmd_reset(argv):
    con = connect()
    try:
        con.execute("UPDATE %s SET pre_add=1 WHERE ztb_rpa_prjs_id=?" % TABLE, (argv.id,))
        con.commit()
        out(json.dumps({"ok": True, "id": argv.id, "pre_add": 1}, ensure_ascii=False))
        return EXIT_OK
    finally:
        con.close()


# ---------------------------------------------------------------- 投标策略配置
#
# 《投标策略》是**客户自己的**业务规则——关系单位、对口业务、一票否决项、价格分取舍……
# 每家客户都不同，不能写死在技能里。本模块把它做成「结构化配置 + 安装向导 + 渲染」：
#
#   python ztb.py strategy                      向导报告（字段清单 + 当前值 + 是否需配置）
#   python ztb.py strategy --json               同上，JSON
#   python ztb.py strategy --template           输出空白模板 JSON（照着填）
#   python ztb.py strategy --set "键=值"         写标量；支持点路径 "价格分规则.可接受下限=30"
#                                              列表/分组字段可用 、, 分隔一次写多项
#   python ztb.py strategy --add "关系单位=XX公司"        向列表追加
#   python ztb.py strategy --remove "关系单位=XX公司"     从列表删除
#   python ztb.py strategy --set-json '{...}'            批量合并（对象按层合并）
#   python ztb.py strategy --set-file my.json            从文件批量合并（长文本推荐）
#   python ztb.py strategy --render [--out P]            渲染成《投标策略》markdown 并落盘
#   python ztb.py strategy --print                       渲染结果直接打印到 stdout
#   python ztb.py strategy --reset                       清除客户配置（回到包内默认）
#
# 配置文件默认 <state_dir>/strategy.json（环境变量 ZTB_STRATEGY 或共享配置键
# strategy_file 可指向别处）。未配置时回退到包内 references/投标策略.txt。

STRATEGY_ENV = "ZTB_STRATEGY"
RENDERED_NAME = "投标策略.md"

# 字段表：group=向导分组；level=core 必问 / advanced 按需；
# type=text 字符串 / list 列表 / kv 键值对 / map 分组列表
STRATEGY_FIELDS = [
    dict(key="公司名称", label="公司名称", group="基本信息", level="advanced", type="text",
         required=False, hint="用于研判结论与推送文案的抬头", example="XX数字科技有限公司"),
    dict(key="业务范围", label="对口的项目类型（业务范围）", group="业务对口", level="core",
         type="map", required=True,
         hint="按板块列出公司真正能做、有优势的项目类型；这是判断「业务是否对口」的唯一依据",
         example={"展馆展厅": ["政企展厅", "文博馆", "校史馆"], "数字影片": ["宣传片", "三维动画"]}),
    dict(key="优势", label="公司优势", group="业务对口", level="advanced", type="list",
         required=False, hint="投标时可转化为加分项的能力",
         example=["演示视频", "效果图", "3D演示视频", "汇报视频"]),
    dict(key="劣势", label="公司劣势", group="业务对口", level="advanced", type="list",
         required=False, hint="明显做不了/会被扣分的项，命中即倾向不参加",
         example=["施工图", "样品", "实物文本", "非常具体的专家职称/证书"]),
    dict(key="关系单位", label="关系单位名单", group="关系单位", level="core", type="list",
         required=True, hint="有关系、可放宽标准或优先参加的单位（含其下属公司/分支机构）",
         example=["XX市青少年活动中心", "XX集团及下属公司"]),
    dict(key="关系单位豁免项", label="对关系单位可放宽的规则", group="关系单位", level="advanced",
         type="list", required=False,
         hint="哪些否决项对关系单位不适用（例如价格分偏低、需要线下取标书）",
         example=["价格分低于下限", "线下取标书投标"]),
    dict(key="硬性否决规则", label="一票否决规则（不参加）", group="资质门槛", level="core",
         type="list", required=True, hint="命中任一即判「不参加」的情形",
         example=["纯设备或物资采购，无优势", "对团队成员有明显针对性（导演资质/奖项/工程师资格）"]),
    dict(key="门槛底线", label="资质/门槛底线", group="资质门槛", level="advanced", type="list",
         required=False, hint="可接受的最低资质要求；超出即不参加",
         example=["不接受必须提供施工图/样品/实物文本", "不接受极小众资质或证书"]),
    dict(key="价格分规则", label="价格分规则", group="采购方式与评分", level="core", type="kv",
         required=True, hint="价格分占比的取舍：可接受下限、低于多少不考虑",
         example={"可接受下限": "30", "不考虑低于": "20", "说明": "30% 可考虑，20% 以下不考虑"}),
    dict(key="期望评标结构", label="期望的评标结构（%）", group="采购方式与评分", level="advanced",
         type="kv", required=False,
         hint="你希望出现的商务分/价格分/主观分比例组合（评分越泛越好做）",
         example={"商务分": "20", "价格分": "30", "主观分": "50"}),
    dict(key="偏好规则", label="偏好规则（优先/加分）", group="采购方式与评分", level="advanced",
         type="list", required=False, hint="出现这些特征时倾向参加",
         example=["前期带策划设计类项目", "内容定制类服务", "演示类/视频类交付"]),
    dict(key="备注", label="其他说明", group="基本信息", level="advanced", type="text",
         required=False, hint="研判时需要一并考虑的其他背景", example=""),
]

FIELD_BY_KEY = {f["key"]: f for f in STRATEGY_FIELDS}
FIELD_GROUPS = ("基本信息", "业务对口", "关系单位", "资质门槛", "采购方式与评分")
# 列表字段的分隔符：**故意不含英文/中文逗号**——中文规则里「，」是正常断句
# （如「纯设备或物资采购，无优势」），不能当分隔符用。
_SPLIT_RE = re.compile(r"[、;；\n]+")


def strategy_file():
    """客户策略配置文件路径（可在 <state_dir>/strategy.json）。"""
    p = (os.environ.get(STRATEGY_ENV) or _cfg("strategy_file")
         or os.path.join(state_dir(), "strategy.json"))
    return _norm(p)


def default_strategy_txt():
    """包内默认《投标策略》（未配置客户策略时的回退）。"""
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(os.path.dirname(here), "references", "投标策略.txt")


def rendered_strategy_md():
    return os.path.join(state_dir(), RENDERED_NAME)


def _has_value(v):
    if v is None:
        return False
    if isinstance(v, str):
        return bool(v.strip())
    if isinstance(v, (list, tuple, set)):
        return len(v) > 0
    if isinstance(v, dict):
        return any(_has_value(x) for x in v.values())
    return True


def load_strategy():
    """读取客户策略配置；未配置/损坏返回 (None, None)。"""
    p = strategy_file()
    if not os.path.isfile(p):
        return None, None
    try:
        with io.open(p, "r", encoding="utf-8") as fh:
            d = json.load(fh)
    except Exception:
        return None, None
    if not isinstance(d, dict):
        return None, None
    d.pop("_字段说明", None)
    return (d, p) if _has_value(d) else (None, None)


def _read_text_file(path):
    try:
        return io.open(path, "r", encoding="utf-8", errors="ignore").read()
    except Exception:
        return ""


def render_strategy(cfg):
    """把客户策略配置渲染成《投标策略》markdown（供智能体阅读）。"""
    L = ["# 投标策略（客户配置）", ""]
    L.append("> 本文件由 `ztb.py strategy` 按客户配置自动渲染，请勿手工修改；"
             "改完配置后重跑 `ztb.py strategy --render`。")
    nm = str(cfg.get("公司名称") or "").strip()
    if nm:
        L.append("> 适用主体：%s" % nm)
    L.append("")

    def bullets(values, numbered=False):
        i = 0
        for v in values or []:
            s = str(v).strip()
            if not s:
                continue
            i += 1
            L.append(("%d. %s" % (i, s)) if numbered else ("- " + s))

    # 一、业务对口
    L.append("## 一、业务对口（我们做什么）")
    L.append("")
    br = cfg.get("业务范围")
    if isinstance(br, dict) and _has_value(br):
        L.append("**业务范围（对口项目类型）**：")
        for k, v in br.items():
            if isinstance(v, (list, tuple)):
                items = " / ".join(str(x).strip() for x in v if str(x).strip())
                L.append("- 【%s】%s" % (k, items))
            else:
                L.append("- 【%s】%s" % (k, str(v).strip()))
    else:
        L.append("**业务范围**：未配置")
    if _has_value(cfg.get("优势")):
        L.append("")
        L.append("**优势（可转为加分项）**：")
        bullets(cfg.get("优势"))
    if _has_value(cfg.get("劣势")):
        L.append("")
        L.append("**劣势（命中即倾向不参加）**：")
        bullets(cfg.get("劣势"))

    # 二、关系单位
    L.append("")
    L.append("## 二、关系单位")
    L.append("")
    rel = cfg.get("关系单位")
    if _has_value(rel):
        L.append("**关系单位名单（共 %d 家）**：" % len(rel))
        bullets(rel, numbered=True)
        L.append("")
        L.append("业主命中上述单位（含其下属/分支机构）→ **倾向参加**。")
    else:
        L.append("**关系单位**：未配置")
    if _has_value(cfg.get("关系单位豁免项")):
        L.append("")
        L.append("**对关系单位可放宽的规则**（命中这些否决项仍可参加）：")
        bullets(cfg.get("关系单位豁免项"))

    # 三、资质门槛
    L.append("")
    L.append("## 三、资质门槛 / 一票否决")
    L.append("")
    veto = cfg.get("硬性否决规则")
    if _has_value(veto):
        L.append("**命中以下任一 → 判「不参加」**：")
        for i, v in enumerate(veto, 1):
            L.append("%d. %s" % (i, str(v).strip()))
    else:
        L.append("**一票否决规则**：未配置")
    if _has_value(cfg.get("门槛底线")):
        L.append("")
        L.append("**门槛底线**：")
        bullets(cfg.get("门槛底线"))

    # 四、采购方式与评分
    L.append("")
    L.append("## 四、采购方式与评分")
    L.append("")
    kv = cfg.get("价格分规则")
    if isinstance(kv, dict) and _has_value(kv):
        L.append("**价格分规则**：")
        for k, v in kv.items():
            L.append("- %s：%s" % (k, v))
    else:
        L.append("**价格分规则**：未配置")
    ev = cfg.get("期望评标结构")
    if isinstance(ev, dict) and _has_value(ev):
        L.append("")
        L.append("**期望的评标结构**：" + " / ".join("%s %s%%" % (k, v) for k, v in ev.items()))
    if _has_value(cfg.get("偏好规则")):
        L.append("")
        L.append("**偏好规则（出现即倾向参加）**：")
        bullets(cfg.get("偏好规则"))

    nz = str(cfg.get("备注") or "").strip()
    if nz:
        L.append("")
        L.append("## 五、其他说明")
        L.append("")
        L.append(nz)
    return "\n".join(L) + "\n"


# 策略闸门：四维模型对应的四个核心字段。**至少一个必须有内容**才算「已提供策略」，
# 否则视为未配置 —— 防止「只填了公司名称」或空文件就被当作已配置。
# ⚠️ 与 jrzb-crawler 的 scripts/jrzb.py 中同名常量保持一致（那边也要读这个闸门）。
STRATEGY_CORE_KEYS = ("业务范围", "关系单位", "硬性否决规则", "价格分规则")


def strategy_gate(force=False):
    """判断是否允许开始分析：**未提供《投标策略》就拒绝发放待处理项目**。

    未配置时脚本会回退到包内占位模板，用它筛出来的结论对客户是无意义的错误结论，
    因此这里硬阻断（策略配置/查看类命令不受影响）。
    """
    cfg, path = load_strategy()
    exists = os.path.isfile(strategy_file())
    filled = [k for k in STRATEGY_CORE_KEYS if cfg and _has_value(cfg.get(k))]
    missing = [k for k in STRATEGY_CORE_KEYS if k not in filled]
    blocked = not (exists and filled)
    return {
        "require_strategy": True,
        "blocked": blocked,
        "config_file": path or strategy_file(),
        "config_exists": exists,
        "core_filled": filled,
        "core_missing": missing,
        "reason": ("未提供《投标策略》：策略配置不存在或核心字段为空。"
                   "未配置时脚本会用包内占位模板研判，结论对客户无效，故拒绝执行。") if blocked else "",
        "how_to_fix": [
            "python ztb.py strategy                    # 查看必问项与当前值",
            "python ztb.py strategy --template         # 取空白模板照着填",
            'python ztb.py strategy --set-file 我的策略.json   # 整体导入（推荐）',
            "python ztb.py strategy --render           # 渲染出《投标策略》",
        ],
        "forced": bool(force),
    }


def strategy_summary():
    """当前生效的策略概要（供 next / status 输出）。"""
    cfg, path = load_strategy()
    if cfg is None:
        return {
            "configured": False, "source": "default",
            "strategy_file": default_strategy_txt(),
            "config_file": strategy_file(),
            "hint": "尚未配置投标策略，当前使用包内默认《投标策略》。"
                    "请运行 `python ztb.py strategy` 按向导配置客户自己的策略。",
        }
    rp = rendered_strategy_md()
    try:
        os.makedirs(os.path.dirname(rp) or ".", exist_ok=True)
        with io.open(rp, "w", encoding="utf-8") as fh:
            fh.write(render_strategy(cfg))
    except OSError:
        pass
    return {"configured": True, "source": "config", "config_file": path,
            "strategy_file": rp, "hint": ""}


def build_strategy_report():
    cfg, path = load_strategy()
    exists = os.path.isfile(strategy_file())
    fields, reasons = [], []
    for f in STRATEGY_FIELDS:
        cur = (cfg or {}).get(f["key"])
        filled = _has_value(cur)
        missing = bool(f.get("required")) and not filled
        fields.append({
            "key": f["key"], "label": f["label"], "group": f["group"], "type": f["type"],
            "level": f["level"], "required": bool(f.get("required")),
            "hint": f["hint"], "example": f.get("example"),
            "current": cur, "filled": filled, "missing": missing,
        })
        if f["level"] == "core" and missing and exists:
            reasons.append("%s 未填写" % f["label"])
    if not exists:
        reasons.insert(0, "尚未配置投标策略（当前回退使用包内默认《投标策略》）")
    return {
        "config_file": strategy_file(),
        "config_exists": exists,
        "needs_setup": bool(reasons),
        "reasons": reasons,
        "fields": fields,
        "default_strategy": default_strategy_txt(),
        "default_strategy_exists": os.path.isfile(default_strategy_txt()),
        "rendered_file": rendered_strategy_md(),
        "how_to_write": 'python ztb.py strategy --set "键=值"（或 --add / --set-json / --set-file 我的策略.json）',
    }


def format_strategy_report(report):
    lines = ["投标策略配置（安装向导）", "配置文件: %s%s" % (
        report["config_file"], "" if report["config_exists"] else "（不存在）")]
    if report["needs_setup"]:
        lines.append("状态: 需要配置 —— " + "；".join(report["reasons"]))
    else:
        lines.append("状态: 已配置完成")
    if not report["config_exists"]:
        lines.append("回退默认: %s%s" % (report["default_strategy"],
                                    "" if report["default_strategy_exists"] else "（不存在）"))
    lines.append("")
    for g in FIELD_GROUPS:
        rows = [f for f in report["fields"] if f["group"] == g]
        if not rows:
            continue
        lines.append("【%s】" % g)
        for f in rows:
            need = "必填" if f["required"] else "可选"
            if f["filled"]:
                flag, cur = "✓", _fmt_field_value(f)
            elif f["missing"]:
                flag, cur = "✗ 未填", "（空）"
            else:
                flag, cur = "-", "（未配置）"
            lines.append("  %s %s（%s，%s）%s" % (flag, f["label"], need, f["type"], cur))
            lines.append("      说明: %s" % f["hint"])
            if f.get("example") not in (None, "", [], {}):
                lines.append("      示例: %s" % json.dumps(f["example"], ensure_ascii=False))
        lines.append("")
    if report["needs_setup"]:
        lines.append("写入方式: %s" % report["how_to_write"])
        lines.append("查看模板: python ztb.py strategy --template")
    return "\n".join(lines)


def _fmt_field_value(f):
    v = f["current"]
    if isinstance(v, list):
        if len(v) > 6:
            return "　" + "；".join(str(x) for x in v[:6]) + " …（共 %d 项）" % len(v)
        return "　" + "；".join(str(x) for x in v)
    if isinstance(v, dict):
        return "　" + "；".join("%s=%s" % (k, vv) for k, vv in v.items())
    return "　%s" % str(v)[:200]


def parse_kv_items(items, label):
    """--set 用：KEY=VALUE → dict（同名后者覆盖前者）。"""
    out = {}
    for it in items or []:
        if "=" not in it:
            raise ValueError("%s 需要 KEY=VALUE 形式，收到: %s" % (label, it))
        k, v = it.split("=", 1)
        out[k.strip()] = v
    return out


def parse_kv_pairs(items, label):
    """--add / --remove 用：保留重复键的顺序 → [(key, value), ...]。"""
    out = []
    for it in items or []:
        if "=" not in it:
            raise ValueError("%s 需要 KEY=VALUE 形式，收到: %s" % (label, it))
        k, v = it.split("=", 1)
        out.append((k.strip(), v))
    return out


def _coerce_value(key, value, depth):
    """按字段类型把命令行字符串转成合适结构（列表/分组字段按分隔符拆项）。"""
    f = FIELD_BY_KEY.get(key)
    if not f:
        return value
    t = f["type"]
    if t in ("list", "map") and (t == "list" and depth == 0 or t == "map" and depth >= 1):
        parts = [p.strip() for p in _SPLIT_RE.split(str(value)) if p.strip()]
        if not parts:
            return value
        return parts if len(parts) > 1 else parts[0] if t == "map" else parts
    return value


def _set_path(cfg, path, value):
    parts = [p for p in str(path).split(".") if p]
    if not parts:
        return
    cur = cfg
    for p in parts[:-1]:
        if not isinstance(cur.get(p), dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = _coerce_value(parts[0], value, len(parts) - 1)


def _deep_merge(dst, src):
    for k, v in (src or {}).items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _deep_merge(dst[k], v)
        else:
            dst[k] = v
    return dst


def _save_strategy(cfg):
    p = strategy_file()
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with io.open(p, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, ensure_ascii=False, indent=2)
    return p


def strategy_template():
    t = {}
    for f in STRATEGY_FIELDS:
        if f["type"] == "list":
            t[f["key"]] = []
        elif f["type"] in ("kv", "map"):
            t[f["key"]] = {}
        else:
            t[f["key"]] = ""
    t["_字段说明"] = {f["key"]: {"说明": f["hint"],
                              "必填": bool(f.get("required")),
                              "示例": f.get("example")} for f in STRATEGY_FIELDS}
    return t


def cmd_strategy(argv):
    """投标策略安装向导：查看 / 写入 / 渲染客户策略。"""
    if getattr(argv, "template", False):
        out(json.dumps(strategy_template(), ensure_ascii=False, indent=2))
        return EXIT_OK

    if getattr(argv, "reset", False):
        p = strategy_file()
        removed = False
        if os.path.isfile(p):
            os.remove(p)
            removed = True
        out(json.dumps({"ok": True, "removed": removed, "config_file": p,
                        "note": "已清除客户策略配置，恢复使用包内默认《投标策略》"},
                       ensure_ascii=False, indent=2))
        return EXIT_OK

    try:
        sets = parse_kv_items(getattr(argv, "set", None), "--set")
        adds = parse_kv_pairs(getattr(argv, "add", None), "--add")
        removes = parse_kv_pairs(getattr(argv, "remove", None), "--remove")
    except ValueError as exc:
        err("[错误] %s" % exc)
        return EXIT_ERROR

    merge = {}
    for attr in ("set_json", "set_file"):
        raw = getattr(argv, attr, None)
        if not raw:
            continue
        try:
            if attr == "set_file":
                if not os.path.isfile(raw):
                    err("[错误] 找不到文件: %s" % raw)
                    return EXIT_ERROR
                obj = json.load(io.open(raw, "r", encoding="utf-8"))
            else:
                obj = json.loads(raw)
        except Exception as exc:
            err("[错误] 解析 %s 失败: %s" % (attr, exc))
            return EXIT_ERROR
        if not isinstance(obj, dict):
            err("[错误] %s 必须是 JSON 对象" % attr)
            return EXIT_ERROR
        obj.pop("_字段说明", None)
        _deep_merge(merge, obj)

    changed = []
    if sets or merge or adds or removes:
        cfg, _ = load_strategy()
        cfg = dict(cfg or {})
        for k, v in sets.items():
            _set_path(cfg, k, v)
            changed.append(k)
        if merge:
            _deep_merge(cfg, merge)
            changed.append("（批量合并 %d 个键）" % len(merge))
        for k, v in adds:
            cur = cfg.get(k)
            cur = list(cur) if isinstance(cur, list) else ([cur] if _has_value(cur) else [])
            items = _coerce_value(k, v, 0)
            items = items if isinstance(items, list) else [items]
            for it in items:
                if it not in cur:
                    cur.append(it)
            cfg[k] = cur
            changed.append("%s += %s" % (k, v))
        for k, v in removes:
            cur = cfg.get(k)
            if isinstance(cur, list):
                cfg[k] = [x for x in cur if str(x) != str(v)]
                changed.append("%s -= %s" % (k, v))
        _save_strategy(cfg)

    if getattr(argv, "print", False) or getattr(argv, "render", False):
        cfg, path = load_strategy()
        if cfg is None:
            md = _read_text_file(default_strategy_txt())
            src, src_kind = default_strategy_txt(), "default"
        else:
            md = render_strategy(cfg)
            src, src_kind = path, "config"
        wrote = None
        if getattr(argv, "render", False):
            wrote = getattr(argv, "out", None) or rendered_strategy_md()
            os.makedirs(os.path.dirname(wrote) or ".", exist_ok=True)
            with io.open(wrote, "w", encoding="utf-8") as fh:
                fh.write(md)
        if getattr(argv, "print", False):
            out(md)
        if getattr(argv, "render", False):
            out(json.dumps({"ok": True, "rendered": wrote, "source": src_kind,
                            "source_file": src, "chars": len(md)},
                           ensure_ascii=False, indent=2))
        return EXIT_OK

    report = build_strategy_report()
    if changed:
        report["written"] = {"config_file": strategy_file(), "changed": changed}
    if getattr(argv, "json", False):
        out(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        if changed:
            out("[写入] %s" % strategy_file())
            out("[已更新] " + "；".join(changed))
            out("")
        out(format_strategy_report(report))
    return EXIT_OK


# ------------------------------------------------------------------ 企业微信发送
# 推送目标以「群名称」配置（wecom_push_group）。平台要求每次发送前重新解析会话，
# 缓存的 chat_id 不可复用，所以固定三步：sessions list → 按 chat_name 精确匹配 → send。
WECOM_GROUP_ENV = "ZB_WECOM_GROUP"     # 临时覆盖推送群（便于测试），优先级高于配置


def wecom_cli():
    """定位 wecom-cli 可执行文件；找不到返回 None。"""
    import shutil
    for name in ("wecom-cli", "wecom-cli.cmd", "wecom-cli.exe"):
        p = shutil.which(name)
        if p:
            return p
    for cand in (r"~\.workbuddy\binaries\node\cli-connector-packages\wecom-cli.cmd",
                 "~/.workbuddy/binaries/node/cli-connector-packages/wecom-cli"):
        c = os.path.expanduser(cand)
        if os.path.isfile(c):
            return c
    return None


def push_group():
    """当前生效的推送群名称：环境变量 > 共享配置。"""
    return ((os.environ.get(WECOM_GROUP_ENV) or "").strip()
            or (load_config().get("wecom_push_group") or "").strip())


def wecom_send(text, group=None, dry_run=False):
    """把 markdown 文本发到推送群。返回 dict（不抛异常）。

    dry_run=True 时只解析目标是否可达，**不实际发送**（用于体检推送通道）。

    `error` 取值：
        cli_missing           找不到 wecom-cli
        group_not_configured  未配置推送群
        list_failed           列会话失败（含未授权 / 服务不可用）
        group_not_in_sessions 目标群不在机器人最近会话里
        send_failed           发送失败
    """
    import subprocess
    grp = (group or "").strip() or push_group()
    res = {"ok": False, "sent": False, "group": grp, "error": "", "detail": ""}
    cli = wecom_cli()
    if not cli:
        res["error"] = "cli_missing"
        res["detail"] = "找不到 wecom-cli（请确认企业微信连接器已安装并授权）"
        return res
    if not grp:
        res["error"] = "group_not_configured"
        res["detail"] = ('未配置推送群，请先 python scripts/ztb.py config --push-group "群名称"')
        return res

    def run(args):
        try:
            p = subprocess.run([cli] + args, capture_output=True, timeout=120)
        except Exception as exc:
            return None, "%s: %s" % (type(exc).__name__, exc)
        o = (p.stdout or b"").decode("utf-8", "replace").strip()
        e = (p.stderr or b"").decode("utf-8", "replace").strip()
        return o, e

    raw, err = run(["message", "aibot", "sessions", "list"])
    if raw is None:
        res["error"], res["detail"] = "list_failed", err
        return res
    try:
        sess = json.loads(raw)
    except Exception as exc:
        res["error"], res["detail"] = "list_failed", "会话列表解析失败: %s（原文 %s）" % (exc, raw[:160])
        return res
    if not isinstance(sess, dict) or sess.get("errcode"):
        res["error"] = "list_failed"
        res["detail"] = ("拉取会话列表失败：%s"
                         % (sess.get("errmsg") if isinstance(sess, dict) else raw[:160]))
        return res

    chat_id = ""
    for x in sess.get("sessions") or []:
        if (x.get("chat_name") or "").strip() == grp:
            chat_id = x.get("chat_id") or ""
            break
    if not chat_id:
        names = "、".join((x.get("chat_name") or "").strip()
                          for x in (sess.get("sessions") or []))
        res["error"] = "group_not_in_sessions"
        res["detail"] = ("目标群「%s」不在机器人最近会话中（当前可发送：%s）。"
                         "请先把机器人拉进该群，并在群里发一条消息（或 @ 机器人）。"
                         % (grp, names or "无"))
        return res

    payload = {"chat_id": chat_id, "msg_type": "markdown",
               "markdown": {"content": text}}
    if dry_run:
        res["ok"] = True
        res["dry_run"] = True
        res["detail"] = "目标群可达（dry-run，未实际发送）"
        return res
    raw, err = run(["message", "aibot", "send", "--json",
                    json.dumps(payload, ensure_ascii=False)])
    if raw is None:
        res["error"], res["detail"] = "send_failed", err
        return res
    try:
        r = json.loads(raw)
    except Exception:
        res["error"], res["detail"] = "send_failed", raw[:300]
        return res
    if r.get("success"):
        res["ok"] = res["sent"] = True
        return res
    res["error"] = "send_failed"
    res["detail"] = str(r.get("errmsg") or r.get("error") or raw)[:300]
    return res


def push_target_info():
    """企业微信推送目标的配置摘要（供 config / status / 推送前自检）。

    只暴露**可读群名**，不暴露会话 ID：平台要求每次发送前现场解析会话，
    历史保存的 chat_id 不可复用。
    """
    cfg = load_config()
    group = (cfg.get("wecom_push_group") or "").strip()
    legacy = bool((cfg.get("wecom_chat_id") or "").strip())
    if group:
        hint = ("推送前先 `wecom-cli message aibot sessions list`，按 chat_name 精确匹配群名「%s」，"
                "把该会话的 chat_id 原样用于 send；不要复用历史保存的 chat_id。" % group)
    else:
        hint = ("尚未配置推送群名。问清用户「命中项目要发到企业微信的哪个群」，"
                "然后用 `python scripts/ztb.py config --push-group \"群名称\"` 保存。"
                "该群需包含机器人与收件人。")
    return {
        "group_name": group,
        "configured": bool(group),
        "legacy_chat_id_configured": legacy,
        "legacy_chat_id_usable": False,
        "how_to_send": hint,
    }


def cmd_config(argv):
    """查看 / 写入共享路径配置（~/.workbuddy/zb-tender.json）。"""
    cp = config_path()
    updates = {}
    for attr, key in (("work_root", "work_root"), ("state_root", "state_root"),
                      ("db", "db"), ("state_dir", "state_dir"),
                      ("site_packages", "site_packages"), ("strategy_file", "strategy_file"),
                      ("chat_id", "wecom_chat_id"), ("push_group", "wecom_push_group")):
        val = getattr(argv, attr, None)
        if val:
            updates[key] = (val.strip() if key in ("wecom_chat_id", "wecom_push_group")
                            else _norm(val))
        elif key == "wecom_push_group" and getattr(argv, "clear_push_group", False):
            updates[key] = ""

    if updates:
        try:
            with open(cp, "r", encoding="utf-8") as f:
                cfg = json.load(f) or {}
        except Exception:
            cfg = {}
        cfg.update(updates)
        os.makedirs(os.path.dirname(cp) or ".", exist_ok=True)
        with open(cp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)

    dbp = db_path()
    info = {
        "config_file": cp,
        "config_exists": os.path.isfile(cp),
        "config": load_config(),
        "resolved": {
            "work_root": work_root(),
            "state_root": state_root(),
            "workspace": workspace_dir(),
            "package_root": package_root(),
            "db": dbp,
            "db_exists": os.path.isfile(dbp),
            "state_dir": state_dir(),
            "strategy_file": strategy_file(),
            "strategy_exists": os.path.isfile(strategy_file()),
        },
        "push_target": push_target_info(),
        "env_overrides": {k: os.environ[k] for k in
                          ("ZB_CONFIG", "ZB_WORK_ROOT", "ZB_STATE_ROOT",
                           "ZTB_DB", "ZTB_STATE", "ZTB_SITE_PACKAGES", "ZTB_STRATEGY")
                          if os.environ.get(k)},
    }
    # 投标策略是否已按客户配置（未配置则用包内默认）
    report = build_strategy_report()
    info["strategy"] = {
        "configured": report["config_exists"],
        "needs_setup": report["needs_setup"],
        "pending_keys": [f["key"] for f in report["fields"] if f["missing"]],
        "hint": '运行 python ztb.py strategy 查看投标策略配置向导',
    }
    if updates:
        info["updated"] = updates
    out(json.dumps(info, ensure_ascii=False, indent=2))
    return EXIT_OK


# ---------------------------------------------------------------- 入口

def main(argv=None):
    ap = argparse.ArgumentParser(description="招投标项目分析助手")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("status").set_defaults(func=cmd_status)

    p_next = sub.add_parser("next")
    p_next.add_argument("--id", type=int, help="指定要处理的记录 id（默认取最早一条待处理）")
    p_next.add_argument("--ignore-strategy", dest="ignore_strategy", action="store_true",
                        help="应急/调试：未配置《投标策略》时也强行发放项目（默认拒绝）")
    p_next.set_defaults(func=cmd_next)

    p_b = sub.add_parser("bundle")
    p_b.add_argument("--id", type=int, required=True)
    p_b.add_argument("--out", help="素材包输出路径")
    p_b.set_defaults(func=cmd_bundle)

    p_s = sub.add_parser("save")
    p_s.add_argument("--id", type=int, required=True)
    p_s.add_argument("--summary", required=True, help="summary.json 路径")
    p_s.set_defaults(func=cmd_save)

    p_p = sub.add_parser("push")
    p_p.add_argument("--id", type=int, required=True)
    p_p.add_argument("--no-source", action="store_true",
                     help="不在推送里附带原始公告摘要与在线链接")
    p_p.add_argument("--send", action="store_true",
                     help="达标的结论直接发到推送群（企业微信）")
    p_p.add_argument("--group", help="临时覆盖推送群名称（默认取配置 wecom_push_group）")
    p_p.set_defaults(func=cmd_push)

    p_n = sub.add_parser("notify", help="把一段 markdown 直接发到推送群（简报/告警/通知）")
    p_n.add_argument("--text", help="要发送的 markdown 正文")
    p_n.add_argument("--text-file", dest="text_file", help="从文件读取正文（长文本推荐）")
    p_n.add_argument("--group", help="临时覆盖推送群名称")
    p_n.add_argument("--dry-run", dest="dry_run", action="store_true",
                     help="只检查推送群是否可达，不实际发送")
    p_n.add_argument("--json", action="store_true")
    p_n.set_defaults(func=cmd_notify)

    sub.add_parser("abort").set_defaults(func=cmd_abort)

    p_io = sub.add_parser("check-io",
                          help="体检关键写入路径（网络映射盘的可写性/耗时）")
    p_io.set_defaults(func=cmd_check_io)

    p_rs = sub.add_parser("resync",
                          help="把数据库结论补写成项目目录 summary.json（写入故障恢复用）")
    p_rs.add_argument("--id", type=int, help="只补写指定 id")
    p_rs.add_argument("--all", action="store_true",
                      help="补写全部已有结论的项目（默认只补写记录在案的失败项）")
    p_rs.set_defaults(func=cmd_resync)

    p_r = sub.add_parser("reset")
    p_r.add_argument("--id", type=int, required=True)
    p_r.set_defaults(func=cmd_reset)

    p_st = sub.add_parser("strategy", help="投标策略配置向导（查看/写入/渲染客户策略）")
    p_st.add_argument("--json", action="store_true", help="向导报告以 JSON 输出")
    p_st.add_argument("--template", action="store_true", help="输出空白模板 JSON")
    p_st.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                      help="写入单个值（支持点路径，如 价格分规则.可接受下限=30），可重复")
    p_st.add_argument("--add", action="append", default=[], metavar="KEY=VALUE",
                      help="向列表字段追加一项，可重复")
    p_st.add_argument("--remove", action="append", default=[], metavar="KEY=VALUE",
                      help="从列表字段删除一项，可重复")
    p_st.add_argument("--set-json", dest="set_json", metavar="JSON",
                      help="以 JSON 对象批量合并写入")
    p_st.add_argument("--set-file", dest="set_file", metavar="PATH",
                      help="从 JSON 文件批量合并写入（长文本推荐）")
    p_st.add_argument("--render", action="store_true",
                      help="渲染《投标策略》并落盘（默认到状态目录，可用 --out 指定）")
    p_st.add_argument("--print", action="store_true", help="把渲染结果打印到 stdout")
    p_st.add_argument("--out", help="--render 的输出路径")
    p_st.add_argument("--reset", action="store_true", help="清除客户策略配置（回到包内默认）")
    p_st.set_defaults(func=cmd_strategy)

    p_cfg = sub.add_parser("config", help="查看/设置路径配置（迁移到新机器时用）")
    p_cfg.add_argument("--work-root", dest="work_root",
                       help="项目根目录（内含 buzdata.db 与爬虫程序）")
    p_cfg.add_argument("--state-root", dest="state_root",
                       help="状态根目录（锁/素材包/日志）")
    p_cfg.add_argument("--db", help="直接指定 buzdata.db 完整路径")
    p_cfg.add_argument("--state-dir", dest="state_dir", help="直接指定本技能状态目录")
    p_cfg.add_argument("--site-packages", dest="site_packages", help="额外 site-packages")
    p_cfg.add_argument("--strategy-file", dest="strategy_file",
                       help="客户投标策略配置文件路径（默认 <state_dir>/strategy.json）")
    p_cfg.add_argument("--chat-id", dest="chat_id",
                       help="企业微信推送目标 chat_id（仅作记录参考，**不能**用于发送）")
    p_cfg.add_argument("--push-group", dest="push_group",
                       help="企业微信推送目标**群名称**（推荐；每次发送前按群名现场解析会话）")
    p_cfg.add_argument("--clear-push-group", dest="clear_push_group", action="store_true",
                       help="清空已配置的推送群名称")
    p_cfg.set_defaults(func=cmd_config)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
